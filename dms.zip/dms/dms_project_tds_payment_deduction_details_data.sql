-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: dms-project.cdcuaa7mp0jm.us-east-2.rds.amazonaws.com    Database: dms_project
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `tds_payment_deduction_details_data`
--

DROP TABLE IF EXISTS `tds_payment_deduction_details_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tds_payment_deduction_details_data` (
  `tds_payment_deduction_details_id` int NOT NULL AUTO_INCREMENT,
  `pan_no` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `name_of_deductee` varchar(255) NOT NULL,
  `section` varchar(255) NOT NULL,
  `status_of_deduction` varchar(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `bill_amount` varchar(255) NOT NULL,
  `tds_amount` varchar(255) NOT NULL,
  `pan_available` varchar(255) NOT NULL,
  `total_amount` varchar(255) NOT NULL,
  `uploading_track_details_id` int NOT NULL,
  `last_update_id` int NOT NULL,
  `last_update_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`tds_payment_deduction_details_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tds_payment_deduction_details_data`
--

LOCK TABLES `tds_payment_deduction_details_data` WRITE;
/*!40000 ALTER TABLE `tds_payment_deduction_details_data` DISABLE KEYS */;
INSERT INTO `tds_payment_deduction_details_data` VALUES (1,'AAACQ1656K','43951','QUALITY MAINTENANCE VENTURE LIMITED','194C','Company','0.02','8833','176.66','','10.5996',19,6,'2022-09-08 14:26:36'),(2,'AABCF2006M','43928','FUTURE MARKET NETWORKS LIMITED','194C','Company','0.02','7349','146.98','','8.8188',19,6,'2022-09-08 14:26:36'),(3,'AABCF2006M','43922','FUTURE MARKET NETWORKS LIMITED','194C','Company','0.02','34650','693','','41.58',19,6,'2022-09-08 14:26:37'),(4,'AABCF2006M','43928','FUTURE MARKET NETWORKS LIMITED','194C','Company','0.02','1957','39.14','','2.3484',19,6,'2022-09-08 14:26:37'),(5,'','','','','','','','','','',19,6,'2022-09-08 14:26:37'),(6,'','','','','','','','1055.78','','',19,6,'2022-09-08 14:26:38'),(7,'','','T O T A L','','','','','1055.78','','',19,6,'2022-09-08 14:26:38'),(8,'AADHJ1543G','43922','JODHRAJ ARUN KUMAR LADDHA HUF','194I','Non Company','0.1','44000','4400','','264',19,6,'2022-09-08 14:26:38'),(9,'','','T O T A L','','','','','4400','','',19,6,'2022-09-08 14:26:39'),(10,'','','','','','','','','','',19,6,'2022-09-08 14:26:39'),(11,'','','T O T A L','','','','','4400','','',19,6,'2022-09-08 14:26:39'),(12,'AKYPB4844K','43951','KISHAN BHUTRA','194J','Non Company','0.1','15000','1500','','90',19,6,'2022-09-08 14:26:39'),(13,'','','','','','','','1500','','',19,6,'2022-09-08 14:26:40'),(14,'AACCP7457K','43951','PINE LABS PRIVATE LIMITED','194J','Company','0.1','31146','2020','','121.2',19,6,'2022-09-08 14:26:40'),(15,'','','','','','','','','','',19,6,'2022-09-08 14:26:40'),(16,'','','','','','','31146','2020','','538.5468',19,6,'2022-09-08 14:26:41');
/*!40000 ALTER TABLE `tds_payment_deduction_details_data` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-01 16:38:24
