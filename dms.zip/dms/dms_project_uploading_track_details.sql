-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: dms-project.cdcuaa7mp0jm.us-east-2.rds.amazonaws.com    Database: dms_project
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `uploading_track_details`
--

DROP TABLE IF EXISTS `uploading_track_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `uploading_track_details` (
  `uploading_track_details_id` int NOT NULL AUTO_INCREMENT,
  `request_no` int NOT NULL,
  `uploadig_file_name` varchar(255) NOT NULL,
  `job_id` text NOT NULL,
  `get_key` int NOT NULL,
  `uploading_file_type` varchar(255) NOT NULL,
  `uploading_into_s3_bucket` int NOT NULL,
  `s3_bucket_file_path` text NOT NULL,
  `converting_json_from_upoading_file` int NOT NULL,
  `create_text_file` int NOT NULL,
  `uploading_data_into_database` int NOT NULL,
  `last_update_id` int NOT NULL,
  `last_update_ts` timestamp NOT NULL,
  PRIMARY KEY (`uploading_track_details_id`),
  KEY `uploading_track_details_fk0` (`request_no`),
  KEY `uploading_track_details_fk1` (`last_update_id`),
  CONSTRAINT `uploading_track_details_fk0` FOREIGN KEY (`request_no`) REFERENCES `uploading_track` (`request_no`),
  CONSTRAINT `uploading_track_details_fk1` FOREIGN KEY (`last_update_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uploading_track_details`
--

LOCK TABLES `uploading_track_details` WRITE;
/*!40000 ALTER TABLE `uploading_track_details` DISABLE KEYS */;
INSERT INTO `uploading_track_details` VALUES (1,163,'ESI_CHALLAN-MAY-20.pdf','99bcd6effd08ce63b0e39ccb42498045c3ba5bf19dd2a8819c0b623c0100357d',1,'pdf',1,'6/ESI_CHALLAN-MAY-20.pdf',1,1,1,6,'2022-08-09 07:27:46'),(2,164,'ESI_PAYMENT-MAY-20.pdf','ffa8362dce488ba108017a81dd05ba1cc0d29259319d3a7a365c10650ee0b8c8',1,'pdf',1,'6/ESI_PAYMENT-MAY-20.pdf',1,1,1,6,'2022-08-09 07:28:17'),(3,165,'P_TAX_Challan_-_Dec-20.pdf','456ca2e8731ccfd413668303d9ade905cd1b8ce6c10cdf7fac7ca9404655b8ae',1,'pdf',1,'6/P_TAX_Challan_-_Dec-20.pdf',1,1,1,6,'2022-08-09 07:29:07'),(4,166,'P_TAX_PAYMENT_MAY20.pdf','78976a1b2bf540eeb4a23eaaa0288b285bc696382157e67ad11a933c82861440',1,'pdf',1,'6/P_TAX_PAYMENT_MAY20.pdf',1,1,1,6,'2022-08-09 07:29:30'),(5,167,'P_TAX_Challan_-_Jan-21.pdf','88ab3f2198e3205cb348aeb641ffb960d65b53ea1b50860b0d675294700ba2bb',1,'pdf',1,'6/P_TAX_Challan_-_Jan-21.pdf',1,1,1,6,'2022-08-09 07:44:09'),(6,168,'P_TAX_Challan_-_Nov-20.pdf','684f86bf3967e3b0f9a87da5b9712f617aed66eca65cfbbc51a5937a175d6933',1,'pdf',1,'6/P_TAX_Challan_-_Nov-20.pdf',1,1,1,6,'2022-08-09 08:06:54'),(7,169,'P_TAX_Payment-march21.pdf','56402fce7eb31e1db666b4d57dc3b1bb4718b68cf0cef1a7401d77c6837ff43c',1,'pdf',1,'6/P_TAX_Payment-march21.pdf',1,1,1,6,'2022-08-09 08:08:10'),(8,170,'P_TAX_Challan_-_Sep-20.pdf','73b0af14e8e1ce49d0032f9aade06ef7868b1c3e732c8d822078c899fa311cf6',1,'pdf',1,'6/P_TAX_Challan_-_Sep-20.pdf',1,1,1,6,'2022-08-09 08:20:11'),(9,171,'P_TAX_Payment-march21.pdf','0428d0bdc194eec54b35f85d3f7b1d82f67751aa21af32bbf8e33d84ae558edb',1,'pdf',1,'6/P_TAX_Payment-march21.pdf',1,1,1,6,'2022-08-09 08:20:30'),(11,173,'PF_CHALLAN-_MAY-20..pdf','55685acce739378ad314f89add1032165b186b495e21cb99eb92474165ae955a',1,'',1,'6/PF_CHALLAN-_MAY-20..pdf',1,1,1,6,'2022-08-25 17:07:21'),(12,174,'PF_PAYMENT.pdf','fb346f0c306d824c9322fa24c05d439a428f9f76c4525778cc2b1639af9bcb31',1,'pdf',1,'6/PF_PAYMENT.pdf',1,1,1,6,'2022-09-01 15:01:19'),(13,175,'ECR_PF_Challan-SEPT20.pdf','4c6b802aede7a85baf45ddbf75552c5a13d13ba7098dc58a7b2df99ac7882d97',1,'pdf',1,'6/ECR_PF_Challan-SEPT20.pdf',1,1,1,6,'2022-09-01 16:17:29'),(15,180,'PF_CHALLAN-_MAY-20..pdf','992a8ca7f8cd35912aa4192322c45f3e480fbb5a1b4c53b6a36b8a09c596497b',1,'',1,'6/PF_CHALLAN-_MAY-20..pdf',1,1,1,6,'2022-09-01 16:53:12'),(16,181,'PF_PAYMENT.pdf','b058defb064577550207b920fa54eb0bc743a87d873fc91605a9f82e1d05c335',1,'pdf',1,'6/PF_PAYMENT.pdf',1,1,1,6,'2022-09-02 07:47:20'),(17,182,'PF_CHALLAN-_MAY-20..pdf','9aaa684ba54ad028019bea84e0e7e036743bae33a640279050c834b9e5c98ea3',1,'',1,'6/PF_CHALLAN-_MAY-20..pdf',1,1,1,6,'2022-09-02 08:10:19'),(18,183,'051001107012162396_1610034392703_194J_AMMF_Non_company.pdf','f7d2d190c321c7a86b18918f40b47be30d04a3640df102c86bf5d40ef4b55d2d',1,'pdf',1,'6/051001107012162396_1610034392703_194J_AMMF_Non_company.pdf',1,1,1,6,'2022-09-02 19:08:22'),(19,184,'TDS_STATEMENT-_APR-20__FINAL.xls','465bb7c6b0d304c989777177214222039db39869f814c1c7b19f3d3006d8bac7',0,'xls',1,'6/TDS_STATEMENT-_APR-20__FINAL.xls',1,0,1,6,'2022-09-07 18:15:51');
/*!40000 ALTER TABLE `uploading_track_details` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-01 16:38:08
