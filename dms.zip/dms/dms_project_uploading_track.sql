-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: dms-project.cdcuaa7mp0jm.us-east-2.rds.amazonaws.com    Database: dms_project
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `uploading_track`
--

DROP TABLE IF EXISTS `uploading_track`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `uploading_track` (
  `request_no` int NOT NULL AUTO_INCREMENT,
  `uploading_file_count` int NOT NULL,
  `file_type` varchar(255) NOT NULL,
  `content_type` varchar(255) NOT NULL,
  `status` int NOT NULL,
  `uploading_type` varchar(255) NOT NULL DEFAULT 'esic',
  `last_update_id` int NOT NULL,
  `last_update_ts` timestamp NOT NULL,
  PRIMARY KEY (`request_no`),
  KEY `uploading_track_fk0` (`last_update_id`),
  CONSTRAINT `uploading_track_fk0` FOREIGN KEY (`last_update_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=185 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uploading_track`
--

LOCK TABLES `uploading_track` WRITE;
/*!40000 ALTER TABLE `uploading_track` DISABLE KEYS */;
INSERT INTO `uploading_track` VALUES (163,1,'pdf','challan',1,'esic',6,'2022-08-09 07:27:45'),(164,1,'pdf','payment',1,'esic',6,'2022-08-09 07:28:16'),(165,1,'pdf','challan',1,'p-tax',6,'2022-08-09 07:29:06'),(166,1,'pdf','payment',1,'p-tax',6,'2022-08-09 07:29:29'),(167,1,'pdf','challan',1,'p-tax',6,'2022-08-09 07:44:09'),(168,1,'pdf','challan',1,'p-tax',6,'2022-08-09 08:06:53'),(169,1,'pdf','payment',1,'p-tax',6,'2022-08-09 08:08:10'),(170,1,'pdf','challan',1,'p-tax',6,'2022-08-09 08:20:10'),(171,1,'pdf','payment',1,'p-tax',6,'2022-08-09 08:20:30'),(173,1,'pdf','challan',1,'pf',6,'2022-08-25 17:06:43'),(174,1,'pdf','payment',1,'pf',6,'2022-09-01 14:28:46'),(175,1,'pdf','challan',1,'p-tax',6,'2022-09-01 16:17:27'),(180,1,'pdf','challan',1,'pf',6,'2022-09-01 16:53:09'),(181,1,'pdf','payment',1,'pf',6,'2022-09-02 07:47:19'),(182,1,'pdf','challan',1,'pf',6,'2022-09-02 08:10:18'),(183,1,'pdf','challan',1,'tds',6,'2022-09-02 19:07:21'),(184,1,'excel','payment',1,'tds',6,'2022-09-07 18:14:29');
/*!40000 ALTER TABLE `uploading_track` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-01 16:38:54
