-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: dms-project.cdcuaa7mp0jm.us-east-2.rds.amazonaws.com    Database: dms_project
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `pf_challan_data`
--

DROP TABLE IF EXISTS `pf_challan_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pf_challan_data` (
  `pf_challan_id` int NOT NULL AUTO_INCREMENT,
  `trn` varchar(255) NOT NULL,
  `establishment_code` varchar(255) NOT NULL,
  `establishment_name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `total_subscribers_epf` varchar(255) NOT NULL,
  `total_subscribers_eps` varchar(255) NOT NULL,
  `total_subscribers_edli` varchar(255) NOT NULL,
  `total_wages_epf` varchar(255) NOT NULL,
  `total_wages_eps` varchar(255) NOT NULL,
  `total_wages_edli` varchar(255) NOT NULL,
  `administration_charges_ac_01` varchar(255) NOT NULL,
  `administration_charges_ac_02` varchar(255) NOT NULL,
  `administration_charges_ac_10` varchar(255) NOT NULL,
  `administration_charges_ac_21` varchar(255) NOT NULL,
  `administration_charges_ac_22` varchar(255) NOT NULL,
  `administration_charges_ac_total` varchar(255) NOT NULL,
  `employers_share_of_ac_01` varchar(255) NOT NULL,
  `employers_share_of_ac_02` varchar(255) NOT NULL,
  `employers_share_of_ac_10` varchar(255) NOT NULL,
  `employers_share_of_ac_21` varchar(255) NOT NULL,
  `employers_share_of_ac_22` varchar(255) NOT NULL,
  `employers_share_of_ac_total` varchar(255) NOT NULL,
  `employees_share_of_ac_01` varchar(255) NOT NULL,
  `employees_share_of_ac_02` varchar(255) NOT NULL,
  `employees_share_of_ac_10` varchar(255) NOT NULL,
  `employees_share_of_ac_21` varchar(255) NOT NULL,
  `employees_share_of_ac_22` varchar(255) NOT NULL,
  `employees_share_of_ac_total` varchar(255) NOT NULL,
  `ac_no_1_employer_share_rs_pmrpy_data` varchar(255) NOT NULL,
  `ac_no_1_employers_share_rs_pmgky_data` varchar(255) NOT NULL,
  `ac_no_10_Pension_fund_rs_pmrpy_data` varchar(255) NOT NULL,
  `ac_no_10_Pension_fund_rs_pmgky_data` varchar(255) NOT NULL,
  `ac_no_1_employee_share_rs_pmrpy_data` varchar(255) NOT NULL,
  `ac_no_1_employee_share_rs_pmgky_data` varchar(255) NOT NULL,
  `total_a_b_c_rs_pmrpy_data` varchar(255) NOT NULL,
  `total_a_b_c_rs_pmgky_data` varchar(255) NOT NULL,
  `grand_total` varchar(255) NOT NULL,
  `total_remittance_by_employer_rs` varchar(255) NOT NULL,
  `total_remittance_by_employer_rs_pmgky` varchar(255) NOT NULL,
  `total_amount_of_uploaded_ECR` varchar(255) NOT NULL,
  `due_for_the_wages_month_of_data` varchar(255) NOT NULL,
  `due_for_the_wages_year_of_data` varchar(255) NOT NULL,
  `uploading_track_details_id` varchar(255) NOT NULL,
  `last_update_id` varchar(255) NOT NULL,
  `last_update_ts` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pf_challan_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pf_challan_data`
--

LOCK TABLES `pf_challan_data` WRITE;
/*!40000 ALTER TABLE `pf_challan_data` DISABLE KEYS */;
INSERT INTO `pf_challan_data` VALUES (1,'4782007004528\n','WBPRB0042249000','A.M. MOBILE TELECOM PRIVATE LIMITED\n',' 33A, JAWAHARLAL NEHRU ROAD,, 11TH FLOOR, UNIT-9A, KOLKATA, KOLKATA, WEST BENGAL\n','15\n','15\n','15\n','99,615\n','99,615\n','99,615\n','0\n','648\n','0\n','0\n','0\n','648\n','3,658\n','0\n','8,297\n','498\n','0\n','12,453\n','11,955\n','0\n','0\n','0\n','0\n','11,955\n','0\n','0\n','0\n','0\n','0\n','0\n','0\n','0\n','25,056\n','25,056\n','','25,056\n','May\n','2020\n','11','6','2022-08-31 16:00:39'),(2,'4782007004528\n','WBPRB0042249000','A.M. MOBILE TELECOM PRIVATE LIMITED\n',' 33A, JAWAHARLAL NEHRU ROAD,, 11TH FLOOR, UNIT-9A, KOLKATA, KOLKATA, WEST BENGAL\n','15\n','15\n','15\n','99,615\n','99,615\n','99,615\n','0\n','648\n','0\n','0\n','0\n','648\n','3,658\n','0\n','8,297\n','498\n','0\n','12,453\n','11,955\n','0\n','0\n','0\n','0\n','11,955\n','0\n','0\n','0\n','0\n','0\n','0\n','0\n','0\n','25,056\n','25,056\n','','25,056\n','May\n','2020\n','15','6','2022-09-01 17:01:49'),(3,'4782007004528\n','WBPRB0042249000','A.M. MOBILE TELECOM PRIVATE LIMITED\n',' 33A, JAWAHARLAL NEHRU ROAD,, 11TH FLOOR, UNIT-9A, KOLKATA, KOLKATA, WEST BENGAL\n','15\n','15\n','15\n','99,615\n','99,615\n','99,615\n','0\n','648\n','0\n','0\n','0\n','648\n','3,658\n','0\n','8,297\n','498\n','0\n','12,453\n','11,955\n','0\n','0\n','0\n','0\n','11,955\n','0\n','0\n','0\n','0\n','0\n','0\n','0\n','0\n','25,056\n','25,056\n','','25,056\n','May\n','2020\n','17','6','2022-09-02 08:11:05');
/*!40000 ALTER TABLE `pf_challan_data` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-01 16:38:33
