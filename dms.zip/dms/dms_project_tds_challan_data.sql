-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: dms-project.cdcuaa7mp0jm.us-east-2.rds.amazonaws.com    Database: dms_project
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `tds_challan_data`
--

DROP TABLE IF EXISTS `tds_challan_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tds_challan_data` (
  `tds_challan_id` int NOT NULL AUTO_INCREMENT,
  `name_of_the_assessee_data` varchar(255) NOT NULL,
  `complete_address` varchar(255) NOT NULL,
  `tan_data` varchar(255) NOT NULL,
  `major_head_data` varchar(255) NOT NULL,
  `minor_head_data` varchar(255) NOT NULL,
  `nature_of_the_payment_data` varchar(255) NOT NULL,
  `basic_tax_data` varchar(255) NOT NULL,
  `surcharge_data` varchar(255) NOT NULL,
  `education_cess_data` varchar(255) NOT NULL,
  `penalty_data` varchar(255) NOT NULL,
  `oters_data` varchar(255) NOT NULL,
  `interest_data` varchar(255) NOT NULL,
  `fee_under_Sec_e_data` varchar(255) NOT NULL,
  `total_data` varchar(255) NOT NULL,
  `challan_no_data` varchar(255) NOT NULL,
  `bsr_code_data` varchar(255) NOT NULL,
  `date_of_receipt_data` varchar(255) NOT NULL,
  `challan_serial_no_data` varchar(255) NOT NULL,
  `assessment_year_data` varchar(255) NOT NULL,
  `bank_reference_data` varchar(255) NOT NULL,
  `drawn_on_data` varchar(255) NOT NULL,
  `rupees_in_words_data` varchar(255) NOT NULL,
  `cin_data` varchar(255) NOT NULL,
  `debit_acount_no_data` varchar(255) NOT NULL,
  `payment_realization_date_data` varchar(255) NOT NULL,
  `uploading_track_details_id` int NOT NULL,
  `last_update_id` int NOT NULL,
  `last_update_ts` datetime NOT NULL,
  PRIMARY KEY (`tds_challan_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tds_challan_data`
--

LOCK TABLES `tds_challan_data` WRITE;
/*!40000 ALTER TABLE `tds_challan_data` DISABLE KEYS */;
INSERT INTO `tds_challan_data` VALUES (1,'AM MXXXXE TELECOM PRIVATE LIMITED','33A CHATTERJEE INTERNATIONALJL NEHRU ROADKOLKATA WEST BENGAL 700071','CALA03803C','0021 - NON-COMPANY DEDUCTEES','200 - TDS/TCS Payable by Taxpayer\n','94J - Fees for Professional or Technical Services','75,000.00','0.00','0.00','0.00','0.00','0.00','0.00','75,000.00','281','0510011','07/01/2021','62396','2021-22','62396','HDFC Bank Netbanking','INR SEVENTY FIVE THOUSAND ONLY','051001107012162396','06932560000928','07/01/2021 21:16:23',18,6,'0000-00-00 00:00:00');
/*!40000 ALTER TABLE `tds_challan_data` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-01 16:37:46
