<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

if ( ! function_exists('test_method'))
{
    function registration_mail($params){
       $params['config']=email_settings();
       sendmail($params);
       return 1;
    } 
    function forgotpassword_mail($params){
       $params['config']=email_settings();
       sendmail($params);
       return 1; 
    } 
    function email_settings(){
      	$config['protocol']    = 'smtp';
        $config['smtp_host']    = 'mail.met-technologies.com';
        $config['smtp_port']    = '25';        
        $config['smtp_user']    = 'developer.net@met-technologies.com';
        $config['smtp_pass']    = 'Dot123@#$%';
        $config['charset']    = 'utf-8';
        $config['newline']    = "\r\n";
        $config['mailtype'] = 'html'; // or html
        $config['validation'] = TRUE; // bool whether to validate email or not     
        return $config; 
    } 
    function sendmail($params){
    	  $obj =get_object();
    	  $obj->load->library('email');
        $obj->email->initialize($params['config']);
        $obj->email->from('developer.net@met-technologies.com',$params['name']); 
        $obj->email->to($params['to']); 
        $obj->email->subject($params['subject']);
        $obj->email->message($params['message']);  
        return $obj->email->send();
    }
    function get_user_role_type(){
      $user_role=get_object()->session->userdata('user_role');
      return $user_role;
    } 
    function get_object(){
      $obj =& get_instance();
      return $obj;
    }
}