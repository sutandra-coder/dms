<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'index';
$route['about-us'] = 'aboutus';
$route['signup/create-user'] = 'signup/create_user';
$route['signup/activate-account/(:any)'] = 'signup/activate_account/$1'; 
$route['login/check-email'] = 'login/check_email_existence';
$route['login/recover-password/(:any)'] = 'login/recover_password/$1';
$route['login/recover-change-password'] = 'login/recover_change_password';
$route['profile/profile-detail'] = 'profile/profile_details';
$route['profile/set-profile'] = 'profile/set_profile';
$route['profile/switch-role'] = 'profile/switch_role';
$route['profile/update-profile'] = 'profile/update_profile';
$route['profile/change-password'] = 'profile/change_password';
$route['profile/update-password'] = 'profile/update_password';
$route['profile/set-available-day'] = 'profile/set_available_day';
$route['space/host-space'] = 'space/save_space';
$route['space/space-list'] = 'space/space_list';
$route['space/space-list/(:num)'] = 'space/space_list/$1';
$route['space/edit-space/(:num)'] = 'space/edit_space/$1';
$route['space/update-space'] = 'space/update_space';
$route['space/view-space/(:num)'] = 'space/view_space/$1';
$route['space/all-space-list'] = 'space/all_space_list';
$route['admin/settings/recover']='admin/settings/changepassword';
$route['admin/settings/profile']='admin/settings/changeprofile';
$route['admin/metakey/details/(:any)']='admin/metakey/edit/$1';
$route['admin/metakeyvalue/details/(:any)']='admin/metakeyvalue/edit/$1';
$route['admin/product/details/(:any)']='admin/product/edit/$1';
$route['admin/enquierytype/details/(:any)']='admin/enquierytype/edit/$1';
$route['admin/referalloyalty/details/(:any)']='admin/referalloyalty/edit/$1';
$route['admin/offer/details/(:any)']='admin/offer/edit/$1';
$route['admin/newarrival/details/(:any)']='admin/newarrival/edit/$1';
$route['admin/discount/details/(:any)']='admin/discount/edit/$1';
$route['admin/gallery/content']='admin/gallery/add';
$route['admin/gallery/contenta']='admin/gallery/add_content';
$route['admin/campaign/details/(:any)']='admin/campaign/edit/$1';
$route['admin/audience/details/(:any)']='admin/audience/edit/$1';
$route['admin/offersection/details/(:any)']='admin/offersection/edit/$1';
$route['admin/catalog/details/(:any)']='admin/catalog/edit/$1';

$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
$route['(:any)']='admin/index';

