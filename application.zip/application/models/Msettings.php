<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Msettings extends CI_Model {
    public function __construct() {
        parent::__construct();
    }
	public function get_details($table,$condition){
        $this->db->from($table);        
        $this->db->where($condition);
        $query=$this->db->get();
        return $query->row_array();
    }
	public function update($condition,$data,$table){
		$this->db->where($condition);
		$this->db->update($table,$data);
		return 1;
	}
}