<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Moffer extends CI_Model {
	public function getDetails($table,$condition){
        $this->db->where($condition);
        $query=$this->db->get($table);
        return $query->result_array(); 
    }
	
	public function insert($table,$data){
        $this->db->insert($table,$data);
        return $this->db->insert_id();
    }
	
	 public function update($table,$condition,$data){
        $this->db->where($condition);
        $this->db->update($table,$data);       
        return 1;
    }
	
	public function deviceList(){
        $this->db->select('*');
        $this->db->from('devices');				
        $query=$this->db->get();
        return $query->result_array(); 
    }
	
	public function getDetail($table,$condition){
        $this->db->where($condition);
        $query=$this->db->get($table);
        return $query->row_array(); 
    }
}