<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Menquery extends CI_Model {
	public function getDetail($table,$condition){
        $this->db->where($condition);
        $query=$this->db->get($table);
        return $query->row_array(); 
    }
}