<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends MY_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->model('mday');
		if(!$this->is_logged_in_user()){
			redirect('login','refresh');
		}
	}
	public function index(){
		$data=array();
		$user_role=$this->session->userdata('user_role');
		if($user_role){
			redirect('profile/profile-detail');
		}else{
			$data['title']='Set Role';
			$data['message']='';
			$data['content'] = 'front/set_role'; 
			$this->_load_view($data);
		}
	}
	public function profile_details(){
		$data=array();
		$user_role=$this->session->userdata('user_role');
		$user_details=$this->session->userdata('front_end_user');
		$condition=array('user_id'=>$user_details['user_id']);
		if($user_role=='guest'){
			$data['title']='Guest Profile';
		}else{
			$data['title']='Host Profile';
		}
		$data['user_details']=$this->mcommon->getRow('users',$condition);
		$data['content']='front/profile_dashboard';
		$this->_load_view($data);
	}
	public function set_profile(){
		$user_role=$this->input->post('role_type');
		$this->session->set_userdata('user_role',$user_role);
		$response=array('status'=>1,'message'=>'success');
		echo json_encode($response);
	}
	public function switch_role(){
		$user_role=$this->session->userdata('user_role');
		if($user_role=='guest'){
			$this->session->set_userdata('user_role','host');
		}else{
			$this->session->set_userdata('user_role','guest');
		}
		redirect('profile/profile-detail');
	}
	public function update_profile(){
		$data=array();
		$user_role=$this->session->userdata('user_role');
		if($this->input->post()){
			$this->form_validation->set_rules('name','Name','required|trim');
			$this->form_validation->set_rules('email','Email','required|trim');
			$this->form_validation->set_rules('phoneno','Phone','required|trim');
			if($this->form_validation->run()==FALSE){
				$user_details=$this->session->userdata('front_end_user');
				$condition=array('user_id'=>$user_details['user_id']);
				if($user_role=='guest'){
					$data['title']='Guest Profile';
				}else{
					$data['title']='Host Profile';
				}
				$data['user_details']=$this->mcommon->getRow('users',$condition);
				$data['content']='front/profile_dashboard';
				$this->_load_view($data);
			}else{
				$data['name']=$this->input->post('name');
				$data['email']=$this->input->post('email');
				$data['phoneno']=$this->input->post('phoneno');
				$data['gender']=$this->input->post('gender');
				$data['neighborhood_subdivision']=$this->input->post('neighborhood_subdivision');
				$user_details=$this->session->userdata('front_end_user');
				$condition=array('user_id'=>$user_details['user_id']);
				if($user_role=='guest'){
					$data['emergency_phone_no']=$this->input->post('emergency_phone_no');
				}else{
					$data['property_manager_contact_info']=$this->input->post('property_manager_contact_info');
					$data['property_address']=$this->input->post('property_address');
					$data['amenities']=$this->input->post('amenities');
				}
				$this->mcommon->update('users',$condition,$data);
				$this->session->set_flashdata('success_message','Profile update successfully');
				redirect('profile/profile-detail');	
			}
		}else{
			$this->session->set_flashdata('error_message','Please fill up required fields');
			redirect('profile/profile-detail');
		}
	}
	public function change_password(){
		$data=array();
		$data['title']='Change Password';
		$data['content'] = 'front/change_password'; 
		$this->_load_view($data);
	}
	public function update_password(){
		$data=array();
		$condition=array();
		if($this->input->post()){
			$this->form_validation->set_rules('old_password','Old password','required|trim');
			$this->form_validation->set_rules('new_password','New password','required|trim');
			$this->form_validation->set_rules('confirm_password','Confirm password','required|trim');
			if($this->form_validation->run()==FALSE){
				$data['title']='Change Password';
				$data['content'] = 'front/change_password'; 
				$this->_load_view($data);
			}else{
				$user_details=$this->session->userdata('front_end_user');
				$old_password=$this->input->post('old_password');
				$new_password=$this->input->post('new_password');
				$confirm_password=$this->input->post('confirm_password');
				if($user_details['org_password']==$old_password){
					if($new_password==$confirm_password){
						$data['password']=md5($new_password);
						$data['org_password']=$new_password;
						$condition['user_id']=$user_details['user_id'];
						$this->mcommon->update('users',$condition,$data);
						$this->session->set_flashdata('success_message','Success! your password successfully changed');
						redirect('profile/change-password');
					}else{
						$this->session->set_flashdata('error_message','New password not matched with confirm password');
						redirect('profile/change-password');
					}
				}else{
						$this->session->set_flashdata('error_message','Old password is wrong.please try again');
						redirect('profile/change-password');
				}
			}
		}else{
			$this->session->set_flashdata('error_message','Please fill up required fields');
			redirect('profile/change-password');
		}
	}
	public function set_available_day(){
		$data=array();
		$condition=array();
		$available_days=array();
		$user_role=get_user_role_type();
		if($user_role=='host'){
			$user_details=$this->session->userdata('front_end_user');
			$condition=array('user_id'=>$user_details['user_id']);
			$all_available_days=$this->mday->get_available_days('user_day_availability',$condition);
			foreach($all_available_days as $day){
				$available_days[]=$day['available_day'];
			}
			$data['spaces']=$this->mcommon->getRow('space_timing',$condition);
			$data['available_days']=$available_days;
			$data['title']='Set Available Day';
			$data['content'] = 'front/set_available_day'; 
			$this->_load_view($data);
		}else{
			$this->session->set_flashdata('error_message','Please continue as host to avail this');
			redirect('profile/profile-detail');
		}
	}
	public function save_available_day(){
		$spc=array();
		$data=array();
		$dy=array();
		$user_details=$this->session->userdata('front_end_user');
		$condition=array('user_id'=>$user_details['user_id']);
		if($this->input->post()){
			$this->form_validation->set_rules('days[]','Day','required|trim');
			$this->form_validation->set_rules('open_time','Open time','required|trim');
			$this->form_validation->set_rules('close_time','Close time','required|trim');
			if($this->form_validation->run()==FALSE){
				$all_available_days=$this->mday->get_available_days('user_day_availability',$condition);
				foreach($all_available_days as $day){
					$available_days[]=$day['available_day'];
				}
				$data['spaces']=$this->mcommon->getRow('space_timing',$condition);
				$data['available_days']=$available_days;
				$data['title']='Set Available Day';
				$data['content'] = 'front/set_available_day'; 
				$this->_load_view($data);
			}else{
				$this->mcommon->delete('user_day_availability',$condition);
				$days=$this->input->post('days');
				foreach($days as $day){
					$dy['available_day']=$day;
					$dy['user_id']=$user_details['user_id'];
					$dy['date_of_creation']=date('Y-m-d');
					$data[]=$dy;
				}
				$this->mcommon->batch_insert('user_day_availability',$data);
				$check_existing_time=$this->mcommon->getRow('space_timing',$condition);
				if(empty($check_existing_time)){
					$spc['user_id']=$user_details['user_id'];
					$spc['open_time']=$this->input->post('open_time');
					$spc['close_time']=$this->input->post('close_time');
					$spc['date_of_creation']=date('Y-m-d');
					$this->mcommon->insert('space_timing',$spc);
				}else{
					$spc['open_time']=$this->input->post('open_time');
					$spc['close_time']=$this->input->post('close_time');
					$spc['date_of_update']=date('Y-m-d');
					$this->mcommon->update('space_timing',$condition,$spc);
				}
				$this->session->set_flashdata('success_message','Success! setings done');
				redirect('profile/set-available-day');
			}
		}else{
			$this->session->set_flashdata('error_message','Please set day availability');
			redirect('profile/set-available-day');
		}
	}
	private function _load_view($data) { 
		$this->load->view('front/layouts/index', $data);
	}
}
