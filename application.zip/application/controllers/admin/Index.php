<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Index extends MY_Controller {

	public function __construct() {
		parent::__construct();
		$this->base_url = "http://ec2-18-221-89-14.us-east-2.compute.amazonaws.com/flaskapp/dms_section/DmsSection/";
	}
	public function index() { 
		if ($this->input->post()) { 
			/* Set the validation rules */
			//$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
			//$this->form_validation->set_rules('password', 'Password', 'trim|required');
			//if ($this->form_validation->run() == FALSE) {
				//$this->_load_login_view();
			//} else {
				$phone = $this->input->post('phone', true);
				$password = $this->input->post('password', true);
				//$url = $this->base_url."Login";
				$url = $this->base_url."LoginUser";
				$data['phoneno'] = $phone;
				$data['password'] = $password;
				
				$make_call = $this->callAPI('POST', $url,json_encode($data));
				$response = json_decode($make_call, true);
				$userdata = $response['responseList'];	
				if (empty($userdata)) {
					$this->session->set_flashdata('error_msg', 'Invalid credential');
					$this->_load_login_view();
				} else { 
					$this->session->set_userdata('admin', $userdata);
					redirect('admin/dashboard','refresh');
				}	
			//}
		} else {
			if($this->is_logged_in()){
				redirect('admin/dashboard','refresh');	
			}else{
				$this->_load_login_view();	
			}
		}
	}
	public function _load_login_view() {
		$data = array();
		$data['content'] = 'admin/login';
		$this->load->view('admin/layouts/login', $data);
	}
	
	public function callAPI($method, $url, $data){
	   $curl = curl_init();
	   switch ($method){
		  case "POST":
			 curl_setopt($curl, CURLOPT_POST, 1);
			 curl_setopt($curl,CURLOPT_SSL_VERIFYPEER, false);
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
			 break;
		  case "PUT":
			 curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);			 					
			 break;
		  default:
			 if ($data)
				$url = sprintf("%s?%s", $url, http_build_query($data));
	   }
	   // OPTIONS:
	   curl_setopt($curl, CURLOPT_URL, $url);
	   curl_setopt($curl, CURLOPT_HTTPHEADER,array(
		'Content-Type: application/json',
		));
	   curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
	   curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
	   // EXECUTE:
	   $result = curl_exec($curl);
	   if(!$result){die("Connection Failure");}
	   curl_close($curl);
	   return $result;
	}
}
