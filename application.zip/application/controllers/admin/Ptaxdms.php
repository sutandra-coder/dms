<?php
ini_set('max_execution_time', 36000);
defined('BASEPATH') OR exit('No direct script access allowed');

class Ptaxdms extends MY_Controller {
	public function __construct() {
		parent::__construct();
		$this->redirect_guest();
		$this->admin=$this->session->userdata('admin');
		$this->base_url = "http://ec2-18-221-89-14.us-east-2.compute.amazonaws.com/flaskapp/dms_section/DmsSection/";
		$this->local_base_url = "http://127.0.0.1:5000/dms_section/DmsSection/";
		$this->payment_base_url = "http://ec2-18-221-89-14.us-east-2.compute.amazonaws.com/flaskapp/p_tax_payment/pTaxPayment/";
		$this->challan_base_url = "http://ec2-18-221-89-14.us-east-2.compute.amazonaws.com/flaskapp/p_tax_challan/pTaxChallan/";
	}
	public function index() {		
		$this->_load_list_view();
	}
	
	private function _load_list_view() {
		if($this->input->post()){
			$start_date = $this->input->post('start_date');
			$end_date = $this->input->post('end_date');
			$content_type = $this->input->post('content_type');
			$user = $this->admin;
			if($start_date == '' && $end_date == '' && $content_type == '')
			{
				$start_date = 'NA';
				$end_date = 'NA';
				$content_type = 'NA';
			}else{
				if($start_date == '' && $end_date == '')
				{
					$start_date = 'NA';
					$end_date = 'NA';
					$content_type = $content_type;
				}else if ($content_type == ''){
					$start_date = $start_date;
					$end_date = $end_date;
				}else{
					$start_date = $start_date;
					$end_date = $end_date;
					$content_type = $content_type;
				}
			}
			$url = $this->base_url."UploadingTrackList/".$user['user_id']."/".$start_date."/".$end_date."/".$content_type."/p-tax";
			$data = array();
			$make_call = $this->callAPI('GET', $url,$data);
			$response = json_decode($make_call, true);
			$list = $response['responseList'];
			
			$data = array(
				"status"	=> false,
				"message"  	=> "",
				"post_data"	=>	$list
			);
			
			if($start_date == '' && $end_date == '' && $content_type == '')
			{
				$data['start_date'] = '';
				$data['end_date'] = '';
				$data['content_type'] = '';
			}else{				
				$data['start_date'] =  $this->input->post('start_date');
				$data['end_date'] = $this->input->post('end_date');
				$data['content_type'] = $this->input->post('content_type');
			}			
				
			$data['admin'] = $this->admin;	
			
		}else{
			$start_date = 'NA';
			$end_date = 'NA';
			$content_type = 'NA';
			$user = $this->admin;
			$url = $this->base_url."UploadingTrackList/".$user['user_id']."/".$start_date."/".$end_date."/".$content_type."/p-tax";
			$data = array();
			$make_call = $this->callAPI('GET', $url,$data);
			$response = json_decode($make_call, true);
			$list = $response['responseList'];
			
			$data = array(
				"status"	=> false,
				"message"  	=> "",
				"post_data"	=>	$list
			);
			
			$data['start_date'] = '';
			$data['end_date'] = '';		
			$data['content_type'] = '';
			$data['admin'] = $this->admin;	
		}
		
		$data['content'] = 'admin/ptax/list';
		$this->load->view('admin/layouts/index', $data);
		
	}
	
	public function uploading_track_details_list($request_no)
	{
		$url = $this->base_url."UploadingTrackDetailsList/".$request_no;
		$this->_load_track_deatils_list_view($url);
	}
	
	private function _load_track_deatils_list_view($url) {
		$data = array();
		$make_call = $this->callAPI('GET', $url,$data);
		$response = json_decode($make_call, true);
		$list = $response['responseList'];
		
		$data = array(
			"status"	=> false,
			"message"  	=> "",
			"post_data"	=>	$list
		);
		
		$data['admin'] = $this->admin;
		$data['content_type'] = $response['attributes']['content_type'];
		$data['content'] = 'admin/ptax/detailslist';
		$this->load->view('admin/layouts/index', $data);
	}
	public function ptax_details($uploading_track_details_id)
	{
		$data = array();
		$UploadingTrackurl = $this->base_url."uploadingTrackByUploadingTrackDetailsId/".$uploading_track_details_id;
		$make_call = $this->callAPI('GET', $UploadingTrackurl,$data);
		$UploadingTrackresponse = json_decode($make_call, true);
		$uploading_track_data = $UploadingTrackresponse['responseList'];
		
		if ($uploading_track_data['content_type'] == "challan"){	
			$url = $this->base_url."ptaxChallanDetails/".$uploading_track_details_id;
			$make_call = $this->callAPI('GET', $url,$data);
			$response = json_decode($make_call, true);
			$data['p_tax_challan_data'] = $response['responseList'];			
			$data['uploadig_file_name'] =  str_replace('_', ' ', $uploading_track_data['uploadig_file_name']);
			$this->_load_p_tax_challan_deatils_view($data);
		}else{
			$url = $this->base_url."ptaxPaymentDetails/".$uploading_track_details_id;
			$make_call = $this->callAPI('GET', $url,$data);
			$response = json_decode($make_call, true);
			$data['p_tax_payment_data'] = $response['responseList'];	
			$data['uploadig_file_name'] =  str_replace('_', ' ', $uploading_track_data['uploadig_file_name']);	
			$this->_load_p_tax_payment_deatils_view($data);
		}
	}
	
	public function _load_p_tax_challan_deatils_view($parms)
	{
		$data['cms']=$parms['p_tax_challan_data'];	
		$data['uploadig_file_name'] = $parms['uploadig_file_name'];
		$data['content'] = 'admin/ptax/p_tax_challan_details';
		$this->load->view('admin/layouts/index', $data);
	}
	
	public function _load_p_tax_payment_deatils_view($parms)
	{
		$data['cms']=$parms['p_tax_payment_data'];		
		$data['uploadig_file_name'] = $parms['uploadig_file_name'];	
		$data['content'] = 'admin/ptax/p_tax_payment_details';
		$this->load->view('admin/layouts/index', $data);
	}
	
	public function p_tax_challan_data_update()
	{		
		$p_tax_challan_id = $this->input->post('p_tax_challan_id');
		$uploading_track_details_id = $this->input->post('uploading_track_details_id');
		$data['grn'] = $this->input->post('grn');
		$data['payment_mode'] = $this->input->post('payment_mode');
		$data['grn_date'] = $this->input->post('grn_date');
		$data['bank_gateway'] = $this->input->post('bank_gateway');
		$data['brn'] = $this->input->post('brn');
		$data['brn_date'] = $this->input->post('brn_date');
		$data['payment_status'] = $this->input->post('payment_status');
		$data['payment_ref_no'] = $this->input->post('payment_ref_no');
		$data['depositors_name'] = $this->input->post('depositors_name');
		$data['adress'] = $this->input->post('adress');
		$data['mobile'] = $this->input->post('mobile');
		$data['email'] = $this->input->post('email');
		$data['depositor_status'] = $this->input->post('depositor_status');
		$data['period_from'] = $this->input->post('period_from');
		$data['period_to'] = $this->input->post('period_to');
		$data['payment_id'] = $this->input->post('payment_id');
		$data['payment_ref_id'] = $this->input->post('payment_ref_id');
		$data['slNo'] = $this->input->post('sl.No');
		$data['paymnet_id'] = $this->input->post('paymnet_id');
		$data['head_of_a/c_description'] = $this->input->post('head_of_a/c_description');
		$data['head_of_ac'] = $this->input->post('head_of_ac');
		$data['amount'] = $this->input->post('amount');		
		$url = $this->base_url."updatePtaxChallanData/".$p_tax_challan_id;		
		$make_call = $this->callAPI('PUT', $url,json_encode($data));
		$response = json_decode($make_call, true);		
		
		if($response['attributes']['status'] == 'success')
		{
			$this->session->set_flashdata('success_msg',$response['attributes']['status_desc']);
		}else{
			$this->session->set_flashdata('error_msg',$response['responseList']);			
		}
		redirect('admin/ptaxdms/ptax_details/'.$uploading_track_details_id);
	}
	
	public function p_tax_payment_data_update()
	{
		$p_tax_payment_id = $this->input->post('p_tax_pyment_data_id');
		$uploading_track_details_id = $this->input->post('uploading_track_details_id');
		$data['name_of_the_depositor'] = $this->input->post('name_of_the_depositor');
		$data['challan_amount'] = $this->input->post('challan_amount');
		$data['goverment_ref_no'] = $this->input->post('goverment_ref_no');
		$data['bank_ref_no'] = $this->input->post('bank_ref_no');
		$data['transaction_date_time'] = $this->input->post('transaction_date_and_time');		
		
		$url = $this->base_url."updatePtaxPaymentData/".$p_tax_payment_id;		
		$make_call = $this->callAPI('PUT', $url,json_encode($data));
		$response = json_decode($make_call, true);			
		
		if($response['attributes']['status'] == 'success')
		{
			$this->session->set_flashdata('success_msg',$response['attributes']['status_desc']);
		}else{
			$this->session->set_flashdata('error_msg',$response['responseList']);			
		}
		redirect('admin/ptaxdms/ptax_details/'.$uploading_track_details_id);
	}
	
	public function add(){
		$this->_load_add_view();
	}
	
	private function _load_add_view(){
		$data['content']='admin/ptax/add';
		$this->load->view('admin/layouts/index',$data);
	}
	
	public function add_content(){	
		$file_type = $this->input->post('file_type');
		$content_type = $this->input->post('content_type');		
		
		$user = $this->admin;
		$user_id = $user['user_id'];
		$total = count($_FILES['files']['name']);
		$uploading_track_url = $this->base_url."UploadingTrack";
		$uploading_track_data['uploading_file_count'] = $total;
		$uploading_track_data['last_update_id'] = $user_id;
		$uploading_track_data['file_type'] = $file_type;
		$uploading_track_data['content_type'] = $content_type;
		$uploading_track_data['uploading_type'] = 'p-tax';
		$uploading_track_call = $this->callAPI('POST', $uploading_track_url,json_encode($uploading_track_data));
		$uploading_track_response = json_decode($uploading_track_call, true);
		$request_no = $uploading_track_response['responseList']['request_no'];
		
		for( $i=0 ; $i < $total ; $i++ ) {
			$tmpFilePath = $_FILES['files']['tmp_name'][$i];
			$filename = $_FILES['files']['name'][$i];
			$filedata = $_FILES['files']['tmp_name'][$i];
			$filesize = $_FILES['files']['size'][$i];
			$type = $_FILES['files']['type'][$i];			
			
			if ($tmpFilePath != ''){
				$upload_s3_bucket_url =  $this->base_url.'uploadToS3Bucket/'.$user_id."/".$request_no;
				$upload_s3_bucket_call = $this->callAPIUpload($upload_s3_bucket_url,$filedata,$type,$filename);
				$upload_s3_bucket_response = json_decode($upload_s3_bucket_call, true);				
				$convetJsonFromUploadinFiledata['document_name'] = $upload_s3_bucket_response['responseList'][0]['FilePath'];
				$convetJsonFromUploadinFiledata['request_no'] = $upload_s3_bucket_response['responseList'][0]['request_no'];
				$convetJsonFromUploadinFiledata['user_id'] = $user_id;
				$convetJsonFromUploadinFileUrl = $this->base_url.'ConvetJsonFromUploadinFile';
				$convetJsonFromUploadinFile_call = $this->callAPI('POST', $convetJsonFromUploadinFileUrl,json_encode($convetJsonFromUploadinFiledata));
				$convetJsonFromUploadinFile_response = json_decode($convetJsonFromUploadinFile_call, true);
			}
			
			$uploads_dir = './public/images/';
			$tmp_name = $_FILES["files"]["tmp_name"][$i];
			$name = basename($_FILES["files"]["name"][$i]);
			
			if( move_uploaded_file($tmp_name, "$uploads_dir/$name")) {
				$is_upload = 1;
			} else {
				$is_upload = 0;
			}
		}
		redirect('admin/ptaxdms');
	}
	
	public function repeat_process()
	{
		$request_no = $this->input->post('request_no');
		$content_type = $this->input->post('content_type');
		$get_track_details_data = array();
		$get_track_details_url = $this->base_url.'UploadingTrackDetailsList/'.$request_no;
		$get_track_details_call = $this->callAPI('GET', $get_track_details_url,$get_track_details_data);
		$track_details_response = json_decode($get_track_details_call, true);
		$track_details = $track_details_response['responseList'];
		
		foreach ($track_details as $track_detail) {
			$checkKeyIsExsitsdata['job_id'] = $track_detail['job_id'];
			$checkKeyIsExsitsUrl = $this->base_url.'checkKeyIsExsits';
			$checkKeyIsExsits_call = $this->callAPI('POST', $checkKeyIsExsitsUrl,json_encode($checkKeyIsExsitsdata));
			$checkKeyIsExsits_response = json_decode($checkKeyIsExsits_call, true);		
				
			if ($checkKeyIsExsits_response['responseList']['get_key'] == 1){
				$createTextFileData['request_no'] = $request_no;
				$createTextFileData['documentName'] = $track_detail['s3_bucket_file_path'];
				$createTextFileData['key'] = "textract_output/".$track_detail['job_id']."/1";
				$createTextFileData['job_id'] = $track_detail['job_id'];
				
				$createTextFileUrl = $this->base_url.'CreateTextFile';
				$createTextFile_call = $this->callAPI('POST', $createTextFileUrl,json_encode($createTextFileData));			
				$createTextFile_response = json_decode($createTextFile_call, true);	
					
				$readFileAndSaveData['request_no'] = $request_no;
				$readFileAndSaveData['documentName'] = $track_detail['s3_bucket_file_path'];
				$readFileAndSaveData['file_path'] = $createTextFile_response['responseList']['text_file_path'];
					
				if($content_type == 'challan'){					
					$readFileAndSaveDataUrl = $this->challan_base_url.'readFromFileDataAndSave';
					$readFileAndSaveData_call = $this->callAPI('POST', $readFileAndSaveDataUrl,json_encode($readFileAndSaveData));
					$readFileAndSaveData_response = json_decode($readFileAndSaveData_call, true);
				}else if($content_type == 'payment'){
					$readFileAndSaveDataUrl = $this->payment_base_url.'readFromFileDataAndSave';
					$readFileAndSaveData_call = $this->callAPI('POST', $readFileAndSaveDataUrl,json_encode($readFileAndSaveData));
					$readFileAndSaveData_response = json_decode($readFileAndSaveData_call, true);
				}				
				
			}
		}
		$response['responseList'] = "success";
		echo json_encode($response);
	}
	
	
	public function callAPI($method, $url, $data){
	   $curl = curl_init();
	   switch ($method){
		  case "POST":
			 curl_setopt($curl, CURLOPT_POST, 1);
			 curl_setopt($curl,CURLOPT_SSL_VERIFYPEER, false);
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
			 break;
		  case "PUT":
			 curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);			 					
			 break;
		  case "DELETE":
			 curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "DELETE");
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);			 					
			 break;
		  default:
			 if ($data)
				$url = sprintf("%s?%s", $url, http_build_query($data));
	   }
	   // OPTIONS:
	   curl_setopt($curl, CURLOPT_URL, $url);
	   curl_setopt($curl, CURLOPT_HTTPHEADER,array(
		'Content-Type: application/json',
		));
	   curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
	   curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
	   // EXECUTE:
	   $result = curl_exec($curl);
	   if(!$result){die("Connection Failure");}
	   curl_close($curl);
	   return $result;
	}	
	
	public function callAPIUpload($url, $filedata, $type,$filename){
	  $fields = [
			'file' => new \CurlFile(realpath($filedata), $type, $filename)
		];
		
			// Generated by curl-to-PHP: http://incarnate.github.io/curl-to-php/
		$ch = curl_init();
		
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_URL, $url);
		
		curl_setopt($ch, CURLOPT_HTTPHEADER,array(
			'Accept: application/json',
			'Content-Type: multipart/form-data'
		));
		
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);			
		
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		
		

		$result = curl_exec($ch);
		//$info = curl_getinfo($ch);
		//print_r($info['request_header']);exit;
		if(!$result){die("Connection Failure");}
		curl_close($curl);
		
		return $result;
	}
}