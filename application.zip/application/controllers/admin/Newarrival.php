<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Newarrival extends MY_Controller {
	public function __construct() {
		parent::__construct();
		$this->redirect_guest();
		$this->admin=$this->session->userdata('admin');
		$this->load->model('admin/mnewarrival');
		$this->base_url = "http://ec2-18-221-89-14.us-east-2.compute.amazonaws.com/flaskapp/ecommerce_product/EcommerceProduct/";
	}
		
	public function index() { 
		$this->_load_list_view();		
	}
	
	private function _load_list_view() {
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$url = $this->base_url."getNewArrivalList/".$organisation_id;
		$data = array();
		$make_call = $this->callAPI('GET', $url,$data);
		$response = json_decode($make_call, true);
		$list = $response['responseList'];
		
		$data = array(
			"status"	=> false,
			"message"  	=> "",
			"post_data"	=>	$list
		);
		$data['admin'] = $this->admin;
		$data['content'] = 'admin/newarrival/list';
		$this->load->view('admin/layouts/index', $data);
	}
	
	public function add(){
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$category_id = 0;
		$url = $this->base_url."productList/".$organisation_id."/".$category_id;
		$this->_load_add_view($url);
	}
	
	private function _load_add_view($url){	
		$product_data = array();
		$make_call = $this->callAPI('GET', $url,$product_data);
		$response = json_decode($make_call, true);
		$list = $response['responseList'];
		$data['product_list'] = $response['responseList'];
		$data['content']='admin/newarrival/add';
		$this->load->view('admin/layouts/index',$data);
	}
	
	public function add_content(){
		if($this->input->post()){
			$this->form_validation->set_rules('product_id','Product','required');			
			
			if($this->form_validation->run()==FALSE){	
				$this->_load_add_view();
			}else{
				if(is_uploaded_file($_FILES['imgInp']['tmp_name']))
				{
					$img=$this->image_upload();
					if($img['status']==1){
						$udata['new_arrival_image']=base_url()."public/admin_assets/images/new_arrival/".$img['result'];						
					}else{
						$this->session->set_flashdata('error_msg',$img['result']);
						redirect('admin/newarrival/','refersh'); 	
					}				
				}
				$udata['product_id'] = $this->input->post('product_id');
				$organisation = $this->admin;
				$organisation_id = $organisation['organisation_id'];
				$udata['organisation_id'] = $organisation_id;
				$udata['last_update_id'] = $organisation_id;	
				$url = $this->base_url."addNewArrival";
				$make_call = $this->callAPI('POST', $url,json_encode($udata));
				$response = json_decode($make_call, true);
				if($response['attributes']['status'] == 'error')
				{
					$this->session->set_flashdata('error_msg',$response['responseList']);
				}else{
					$this->session->set_flashdata('success_msg','New Arrival Saved successfully');
				}
				redirect('admin/newarrival');
			}
		}else{
			$this->_load_list_view();
		}
	}
	
	public function edit($new_arrival_id)
	{
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$url = $this->base_url."getNewArrivalDetails/".$new_arrival_id;
		$data = array();
		$make_call = $this->callAPI('GET', $url,$data);
		$response = json_decode($make_call, true);
		$data['cms'] = $response['responseList'];
		if(empty($data['cms'])){
			$this->_load_list_view();
		}else{			
			$this->_load_details_view($data);
		}
	}
	
	public function delete_new_arrival()
	{		
		$new_arrival_id = $this->input->post('new_arrival_id');
		$url = $this->base_url."deleteNewArrivale/".$new_arrival_id;
		$data = array();
		$make_call = $this->callAPI('DELETE', $url,$data);
		$response = json_decode($make_call, true);
		echo json_encode($response);
	}

	
	public function update()
	{
		if($this->input->post()){
			$new_arrival_id = $this->input->post('new_arrival_id');
			$this->form_validation->set_rules('discount_percentage','Discount Percentage','required');
			
			if($this->form_validation->run()==FALSE){
				$url = $this->base_url."getNewArrivalDetails/".$new_arrival_id;
				$data = array();
				$make_call = $this->callAPI('GET', $url,$data);
				$response = json_decode($make_call, true);
				$data['cms'] = $response['responseList'];	
				$this->_load_details_view($data);
			}else{
				if(is_uploaded_file($_FILES['imgInp']['tmp_name']))
				{
					$img=$this->image_upload();
					if($img['status']==1){
						$udata['new_arrival_image']=base_url()."public/admin_assets/images/new_arrival/".$img['result'];						
					}else{
						$this->session->set_flashdata('error_msg',$img['result']);
						redirect('admin/newarrival/','refersh'); 	
					}				
				}
				$udata['discount_percentage'] = $this->input->post('discount_percentage');
				$condition = array("new_arrival_id"=>$new_arrival_id);
				$this->mnewarrival->update('new_arrival',$condition,$udata);
				redirect('admin/newarrival');
			}
		}else{
			$this->_load_list_view();
		}
	}
	
	
	public function _load_details_view($parms)
	{
		$data['cms']=$parms['cms'];	
		$data['content'] = 'admin/newarrival/detail';
		$this->load->view('admin/layouts/index', $data);
	}
	
	private function image_upload(){ 
		$img='imgInp';
		$config['upload_path'] = './public/admin_assets/images/new_arrival';
		$config['allowed_types'] = 'gif|jpg|png|jpeg|GIF';
		$config['encrypt_name']  = true;
		$this->load->library('upload', $config);
		if ( ! $this->upload->do_upload($img)){
			$message = array('result' => $this->upload->display_errors(),'status'=>0);
		}else{ 
			$data = array('upload_data' => $this->upload->data());
			$message = array('result' => $data['upload_data']['file_name'],'status'=>1);
		}
		return $message;
	}

	
	public function callAPI($method, $url, $data){
	   $curl = curl_init();
	   switch ($method){
		  case "POST":
			 curl_setopt($curl, CURLOPT_POST, 1);
			 curl_setopt($curl,CURLOPT_SSL_VERIFYPEER, false);
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
			 break;
		  case "PUT":
			 curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);			 					
			 break;
		  case "DELETE":
			 curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "DELETE");
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);			 					
			 break;
		  default:
			 if ($data)
				$url = sprintf("%s?%s", $url, http_build_query($data));
	   }
	   // OPTIONS:
	   curl_setopt($curl, CURLOPT_URL, $url);
	   curl_setopt($curl, CURLOPT_HTTPHEADER,array(
		'Content-Type: application/json',
		));
	   curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
	   curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
	   // EXECUTE:
	   $result = curl_exec($curl);
	   if(!$result){die("Connection Failure");}
	   curl_close($curl);
	   return $result;
	}
}