<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Enquierytype extends MY_Controller {
	public function __construct() {
		parent::__construct();
		$this->redirect_guest();
		$this->admin=$this->session->userdata('admin');		
		$this->base_url = "http://ec2-18-221-89-14.us-east-2.compute.amazonaws.com/flaskapp/ecommerce_customer/EcommerceCustomer/";
	}
	public function index() { 
		$this->_load_list_view();		
	}
	
	private function _load_list_view() {
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$url = $this->base_url."getEnquiryTypeList/".$organisation_id;
		$data = array();
		$make_call = $this->callAPI('GET', $url,$data);
		$response = json_decode($make_call, true);
		$list = $response['responseList'];
		
		$data = array(
			"status"	=> false,
			"message"  	=> "",
			"post_data"	=>	$list
		);
		$data['admin'] = $this->admin;
		$data['content'] = 'admin/enquierytype/list';
		$this->load->view('admin/layouts/index', $data);
	}
	
	public function edit($enquiry_type_id)
	{
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$url = "http://ec2-3-19-228-138.us-east-2.compute.amazonaws.com/flaskapp/ecommerce_product/EcommerceProduct/getEnquiryTypeDetails/".$organisation_id."/".$enquiry_type_id;
		$data = array();
		$make_call = $this->callAPI('GET', $url,$data);
		$response = json_decode($make_call, true);
		$data['cms'] = $response['responseList'];	
		if(empty($data['cms'])){
			$this->_load_list_view();
		}else{			
			$this->_load_details_view($data);
		}
	}
	
	public function update()
	{
		if($this->input->post()){
			$enquiry_type_id = $this->input->post('enquiry_type_id');
			$this->form_validation->set_rules('enquiry_type','Enquiry Type','required');
			
			if($this->form_validation->run()==FALSE){
				$organisation = $this->admin;
				$organisation_id = $organisation['organisation_id'];
				$url = "http://ec2-3-19-228-138.us-east-2.compute.amazonaws.com/flaskapp/ecommerce_product/EcommerceProduct/getEnquiryTypeDetails/".$organisation_id."/".$meta_key_id;
				$data = array();
				$make_call = $this->callAPI('GET', $url,$data);
				$response = json_decode($make_call, true);
				$data['cms'] = $response['responseList'];
				$this->_load_details_view($data);
			}else{
				$udata['enquiry_type'] = $this->input->post('enquiry_type');				
				$url = "http://ec2-3-19-228-138.us-east-2.compute.amazonaws.com/flaskapp/ecommerce_product/EcommerceProduct/UpdateEnquieryType/".$enquiry_type_id;
				$make_call = $this->callAPI('PUT', $url,json_encode($udata));
				$response = json_decode($make_call, true);
				
				if($response['attributes']['status'] == 'error')
				{
					$this->session->set_flashdata('error_msg',$response['responseList']);
				}else{
					$this->session->set_flashdata('success_msg',$response['responseList']);
				}
				redirect('admin/enquierytype');
			}
		}else{
			$this->_load_list_view();
		}
	}
	
	public function _load_details_view($parms)
	{
		$data['cms']=$parms['cms'];	
		$data['content'] = 'admin/enquierytype/detail';
		$this->load->view('admin/layouts/index', $data);
	}
	
	public function add(){
		$this->_load_add_view();
	}
	
	private function _load_add_view(){		
		$data['content']='admin/enquierytype/add';
		$this->load->view('admin/layouts/index',$data);
	}
	
	public function add_content()
	{
		if($this->input->post()){
			$this->form_validation->set_rules('enquiry_type','Enquiry Type','required');
			
			if($this->form_validation->run()==FALSE){			
				$this->_load_add_view();
			}else{
				$organisation = $this->admin;
				$organisation_id = $organisation['organisation_id'];
				$url = "http://ec2-3-19-228-138.us-east-2.compute.amazonaws.com/flaskapp/ecommerce_product/EcommerceProduct/AddEnquieryType";
				$udata['enquiry_type'] = $this->input->post('enquiry_type');
				$udata['organisation_id'] = $organisation_id;
				$udata['enquiery_type_status'] = 1;
				$udata['last_update_id'] = $organisation_id;				
				$make_call = $this->callAPI('POST', $url,json_encode($udata));
				$response = json_decode($make_call, true);
				if($response['attributes']['status'] == 'error')
				{
					$this->session->set_flashdata('error_msg',$response['responseList']);
				}else{
					$this->session->set_flashdata('success_msg','Tag Saved successfully');
				}
				redirect('admin/enquierytype');
			}
		}else{
			$this->_load_list_view();
		}
		
	}
	
	public function callAPI($method, $url, $data){
	   $curl = curl_init();
	   switch ($method){
		  case "POST":
			 curl_setopt($curl, CURLOPT_POST, 1);
			 curl_setopt($curl,CURLOPT_SSL_VERIFYPEER, false);
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
			 break;
		  case "PUT":
			 curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);			 					
			 break;
		  default:
			 if ($data)
				$url = sprintf("%s?%s", $url, http_build_query($data));
	   }
	   // OPTIONS:
	   curl_setopt($curl, CURLOPT_URL, $url);
	   curl_setopt($curl, CURLOPT_HTTPHEADER,array(
		'Content-Type: application/json',
		));
	   curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
	   curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
	   // EXECUTE:
	   $result = curl_exec($curl);
	   if(!$result){die("Connection Failure");}
	   curl_close($curl);
	   return $result;
	}
}