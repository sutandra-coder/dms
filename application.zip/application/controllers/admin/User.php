<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cms extends MY_Controller {

	public function __construct() {
		parent::__construct();
		$this->redirect_guest();
		$this->load->model('admin/mcms');
	}
	public function index() { 
		$this->_load_list_view();
	}
	public function all_content_list(){
		$list = $this->mcms->get_datatables();
        $data = array();
        $no = $_POST['start'];
		$i=1;
        foreach ($list as $person) {
            $no++;
            $row = array();
			$row[]=$i;
            $row[] = $person->page_name;
            $row[] = ($person->status==1?'<span style="color:green">Active</span>':'<span style="color:red">Inactive</span>');
            $row[] = date('d-m-Y',strtotime($person->date_of_creation));
            $row[] = '<a class="cstm_view" href="'.base_url('admin/cms/details/'.$person->cms_id).'" title="Edit"><i class="glyphicon glyphicon-edit"></i></a><a class="cstm_view" id="delete" style="padding-left:5px" href="javascript:void(0)" title="'.$person->cms_id.'"><i class="glyphicon glyphicon-remove"></i></a>';
            $data[] = $row;
			$i++;
        }
        $output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" => $this->mcms->count_all(),
                        "recordsFiltered" => $this->mcms->count_filtered(),
                        "data" => $data,
                );
        echo json_encode($output);
	}
	public function edit($cms_id){
		$data['cms']=$this->mcms->get_details($cms_id);
		if(empty($data['cms'])){
			$this->_load_list_view();
		}else{
			$this->_load_details_view($data);
		}
	}
	public function update(){
		if($this->input->post()){
			$cms_id=$this->input->post('cms_id');
			$this->form_validation->set_rules('title','Title','required');
			$this->form_validation->set_rules('description','Description','required');
			$this->form_validation->set_rules('content','Content','required');
			if($this->form_validation->run()==FALSE){
				$data['cms']=$this->mcms->get_details($cms_id);
				$this->_load_details_view($data);
			}else{
				if(!empty($_FILES['imgInp']['name'])){
					$file=$this->image_upload();
					if($file['status']==1){
						$udata['image']=$file['result'];
					}else{
						$this->session->set_flashdata('error_msg',$file['result']);
						redirect('admin/cms/details/'.$cms_id,'refersh');
					}
				}
				$condition=array('cms_id'=>$cms_id);
				$udata['title']=$this->input->post('title');
				$udata['description']=$this->input->post('description');
				$udata['content']=$this->input->post('content');
				$udata['status']=$this->input->post('status');
				$udata['date_of_update']=date('Y-m-d H:i:s');
				$this->mcms->update($condition,$udata);
				$this->session->set_flashdata('success_msg','Page updated successfully');
				redirect('admin/cms');
			}
		}else{
			$this->_load_list_view();
		}
	}
	public function add(){
		$this->_load_add_view();
	}
	public function add_content(){
		if($this->input->post()){
			$this->form_validation->set_rules('title','Title','required');
			$this->form_validation->set_rules('description','Description','required');
			$this->form_validation->set_rules('content','Content','required');
			if($this->form_validation->run()==FALSE){
				$this->_load_add_view();
			}else{
				if(!empty($_FILES['imgInp']['name'])){
					$file=$this->image_upload();
					if($file['status']==1){
						$udata['image']=$file['result'];
					}else{
						$this->session->set_flashdata('error_msg',$file['result']);
						redirect('admin/cms/content');
					}
				}
				$udata['title']=$this->input->post('title');
				$udata['page_name']=$udata['title'];
				$udata['description']=$this->input->post('description');
				$udata['content']=$this->input->post('content');
				$udata['status']=$this->input->post('status');
				$udata['date_of_creation']=date('Y-m-d H:i:s');
				$this->mcms->add($udata);
				$this->session->set_flashdata('success_msg','Page added successfully');
				redirect('admin/cms');
			}
		}else{
			$this->session->set_flashdata('error_msg','Please fill up all fields');
			redirect('admin/cms/content');
		}
	}
	private function image_upload(){ 
		$img='imgInp';
		$config['upload_path'] = './public/images/cms';
		$config['allowed_types'] = 'gif|jpg|png';
		$config['max_size']	= '100';
		$config['max_width']  = '1024';
		$config['max_height']  = '768';
		$config['encrypt_name']  = true;
		$this->load->library('upload', $config);
		if ( ! $this->upload->do_upload($img)){
			$message = array('result' => $this->upload->display_errors(),'status'=>0);
		}else{ 
			$data = array('upload_data' => $this->upload->data());
			$message = array('result' => $data['upload_data']['file_name'],'status'=>1);
		}
		return $message;
	}
	public function delete_content(){
		$condition['cms_id']=$this->input->post('cms_id');
		$this->mcms->delete($condition);
		$response=array('status'=>1,'message'=>'Success');
		echo header('Content-Type: application/json');
		echo json_encode($response);
	}
	private function _load_list_view() {
		$data['content'] = 'admin/cms/list';
		$this->load->view('admin/layouts/index', $data);
	}
	private function _load_details_view($parms){
		$data['cms']=$parms['cms'];
		$data['content'] = 'admin/cms/detail';
		$this->load->view('admin/layouts/index', $data);
	}
	private function _load_add_view(){
		$data['content']='admin/cms/add';
		$this->load->view('admin/layouts/index',$data);
	}
}