<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customerorder extends MY_Controller {
	public function __construct() {
		parent::__construct();
		$this->redirect_guest();
		$this->admin=$this->session->userdata('admin');
		$this->base_url = "http://ec2-18-221-89-14.us-east-2.compute.amazonaws.com/flaskapp/ecommerce_product/EcommerceProduct/";
	}
	
	public function index() { 
		$this->_load_list_view();		
	}
	
	private function _load_list_view() {
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$brand_list_url = $this->base_url."getMetaKeyValueListMetaId/2/".$organisation_id;
		$brand_data = array();
		$make_call_brand = $this->callAPI('GET', $brand_list_url,$brand_data);
		$response_brand = json_decode($make_call_brand, true);
		$data['brand_list'] = $response_brand['responseList'];
		$data['content'] = 'admin/customerorder/list';
		$this->load->view('admin/layouts/index', $data);
	}
	
	public function all_content_list($start_date,$end_date,$status) {		
		$organisation = $this->admin;	
		$organisation_id = $organisation['organisation_id'];
		$product_data = array();
		$url = $this->base_url."orderHistory/0/".$status."/".$start_date."/".$end_date."/".$organisation_id;
		$make_call = $this->callAPI('GET', $url,$product_data);
		$response = json_decode($make_call, true);
		$orderHistorylist = $response['responseList'];
		foreach($orderHistorylist as $key=>$list)
		{
			if(!empty($list['invoice_url']))
			{
				$orderHistorylist[$key]['invoice_url'] = "<a href=".$list['invoice_url']." download><span class='glyphicon glyphicon-download-alt'></span></a>";
			}else{
				$orderHistorylist[$key]['invoice_url'] = "";
			}
			$orderHistorylist[$key]['upload_invoice'] = '<a class="cstm_view" id="view" style="padding-left:5px" href="javascript:void(0)" title="'.$list['transaction_id'].'"><i class="fa fa-paperclip"></i></a>';
		}
		$data = array(
			"data"	=> $orderHistorylist
		);
		echo json_encode($data);	
	}
	
	public function all_content_list_with_brand($start_date,$end_date,$status,$brand){
		$organisation = $this->admin;	
		$organisation_id = $organisation['organisation_id'];
		$product_data = array();
		$url = $this->base_url."orderHistory/".$brand."/".$status."/".$start_date."/".$end_date."/".$organisation_id;
		$make_call = $this->callAPI('GET', $url,$product_data);
		$response = json_decode($make_call, true);
		$list = $response['responseList'];	
		
		$data = array(
			"data"	=> $list
		);
		echo json_encode($data);	
	}

	public function invoice_upload()
	{
		$transaction_id = $this->input->post('transaction_id');	
		$tmpFilePath = $_FILES['files']['tmp_name'];
		$newFilePath = "./public/admin_assets/images/invoice/" . $_FILES['files']['name'];
		if(move_uploaded_file($tmpFilePath, $newFilePath)) {
			$data['invoice_url'] = base_url()."public/admin_assets/images/invoice/".$_FILES['files']['name'];
		}else{
			$data['invoice_url'] = "";
		}
		$url = $this->base_url."uploadInvoice/".$transaction_id;
		$make_call = $this->callAPI('PUT', $url,json_encode($data));
		$response = json_decode($make_call, true);
		echo json_encode($response);
	}
	
	
	public function callAPI($method, $url, $data){
	   $curl = curl_init();
	   switch ($method){
		  case "POST":
			 curl_setopt($curl, CURLOPT_POST, 1);
			 curl_setopt($curl,CURLOPT_SSL_VERIFYPEER, false);
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
			 break;
		  case "PUT":
			 curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);			 					
			 break;
		  case "DELETE":
			 curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "DELETE");
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);			 					
			 break;
		  default:
			 if ($data)
				$url = sprintf("%s?%s", $url, http_build_query($data));
	   }
	   // OPTIONS:
	   curl_setopt($curl, CURLOPT_URL, $url);
	   curl_setopt($curl, CURLOPT_HTTPHEADER,array(
		'Content-Type: application/json',
		));
	   curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
	   curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
	   // EXECUTE:
	   $result = curl_exec($curl);
	   if(!$result){die("Connection Failure");}
	   curl_close($curl);
	   return $result;
	}
}