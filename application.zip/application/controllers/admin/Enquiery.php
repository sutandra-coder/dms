<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Enquiery extends MY_Controller {
	public function __construct() {
		parent::__construct();
		$this->redirect_guest();
		$this->admin=$this->session->userdata('admin');		
		$this->load->model('admin/menquery');
		$this->base_url = "http://ec2-18-221-89-14.us-east-2.compute.amazonaws.com/flaskapp/ecommerce_product/EcommerceProduct/";
	}
	public function index() { 
		$this->_load_list_view();		
	}
	
	private function _load_list_view() {
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$url = $this->base_url."getEnquiryList/".$organisation_id;
		$data = array();
		$make_call = $this->callAPI('GET', $url,$data);
		$response = json_decode($make_call, true);
		$list = $response['responseList'];
		
		$data = array(
			"status"	=> false,
			"message"  	=> "",
			"post_data"	=>	$list
		);
		$data['admin'] = $this->admin;
		$data['content'] = 'admin/enquiery/list';
		$this->load->view('admin/layouts/index', $data);
	}
	
	public function communication($enquiry_id,$user_id)
	{
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$url = "http://ec2-3-19-228-138.us-east-2.compute.amazonaws.com/flaskapp/ecommerce_customer/EcommerceCustomer/getCommunicationList/".$organisation_id."/".$user_id."/".$enquiry_id;
		$data = array();
		$make_call = $this->callAPI('GET', $url,$data);
		$response = json_decode($make_call, true);
		$data['enquiry_id'] = $enquiry_id;
		$data['user_id'] = $user_id;
		$data['post_data'] = $response['responseList'];	
		$data['user'] = $response['user'];					
		$this->_load_details_view($data);		
	}
	
	public function _load_details_view($parms)
	{
		$data['user'] = $parms['user'];
		$data['enquiry_id'] = $parms['enquiry_id'];
		$data['user_id'] = $parms['user_id'];
		$data['post_data']=$parms['post_data'];
		$data['content'] = 'admin/enquiery/detail';
		$this->load->view('admin/layouts/index', $data);
	}
	
	public function create_enquiry_communication()
	{
		$user_id = $this->input->post('user_id');	
		$enquiry_id = $this->input->post('enquiry_id');
		$communication_text = $this->input->post('communication_text');
		$data['text'] = $communication_text;
		$data['enquiry_id'] = $enquiry_id;
		$data['user_id'] = $user_id;
		$tmpFilePath = $_FILES['files']['tmp_name'];
		$newFilePath = "./public/admin_assets/images/enquiery/" . $_FILES['files']['name'];
		if(move_uploaded_file($tmpFilePath, $newFilePath)) {
			$data['image'] = base_url()."public/admin_assets/images/enquiery/".$_FILES['files']['name'];
		}else{
			$data['image'] = "";
		}
		$url = $this->base_url."createEnquiryCommunicationAdmin";
		$make_call = $this->callAPI('POST', $url,json_encode($data));
		$response = json_decode($make_call, true);
		if($response['attributes']['status'] == 'success')
		{
			$condition = array("user_id"=>$user_id);
			$device = $this->menquery->getDetail('devices',$condition);	
			
			$condition = array("organisation_id"=>$organisation_id);
			$firebase_details = $this->moffer->getDetail('organisation_firebase_details',$condition);
					
			$push['image-url'] = base_url()."public/admin_assets/images/enquiery/".$_FILES['files']['name'];
			$push['title'] = "enquiery";
			$push['message'] =  $communication_text;
			if(!empty($device)){
				if($device['device_type']==2 && $device['device_token'] != ''){
					$this->send_android_notification($device['device_token'],$push,$firebase_details['firebase_key']);
				}
			}
		}
		echo json_encode($response);
	}
	
	public function send_android_notification($registration_ids, $data,$firebase_key) {
		$fields = array(
		'registration_ids' => array($registration_ids),
		'data'=> $data,
		);
		$headers = array(
		'Authorization: key='.$firebase_key, // FIREBASE_API_KEY_FOR_ANDROID_NOTIFICATION
		'Content-Type: application/json'
		);
		// Open connection
		$ch = curl_init();
		 
		// Set the url, number of POST vars, POST data
		curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
		curl_setopt( $ch,CURLOPT_POST, true );
		curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
		curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
		 
		// Disabling SSL Certificate support temporarly
		curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
		curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
		 
		// Execute post
		$result = curl_exec($ch );
		if($result === false){
		//die('Curl failed:' .curl_errno($ch));
			return 0;
		}
		 
		// Close connection
		curl_close( $ch );
		return $result;
	}
	
	public function callAPI($method, $url, $data){
	   $curl = curl_init();
	   switch ($method){
		  case "POST":
			 curl_setopt($curl, CURLOPT_POST, 1);
			 curl_setopt($curl,CURLOPT_SSL_VERIFYPEER, false);
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
			 break;
		  case "PUT":
			 curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);			 					
			 break;
		  default:
			 if ($data)
				$url = sprintf("%s?%s", $url, http_build_query($data));
	   }
	   // OPTIONS:
	   curl_setopt($curl, CURLOPT_URL, $url);
	   curl_setopt($curl, CURLOPT_HTTPHEADER,array(
		'Content-Type: application/json',
		));
	   curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
	   curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
	   // EXECUTE:
	   $result = curl_exec($curl);
	   if(!$result){die("Connection Failure");}
	   curl_close($curl);
	   return $result;
	}
}