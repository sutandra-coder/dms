<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Gallery extends MY_Controller {
	public function __construct() {
		parent::__construct();
		$this->redirect_guest();
		$this->admin=$this->session->userdata('admin');
	}
	
	public function add(){					
		$this->_load_add_view();
	}
	
	private function _load_add_view(){
		$data['content']='admin/gallery/add';				
		$this->load->view('admin/layouts/index',$data);
	}
	
	public function add_content(){
		
			$total = count($_FILES['files']['name']);
				// Loop through each file
				for( $i=0 ; $i < $total ; $i++ ) {

				  //Get the temp file path
				  $tmpFilePath = $_FILES['files']['tmp_name'][$i];

				  //Make sure we have a file path
				  if ($tmpFilePath != ""){
					//Setup our new file path
					$newFilePath = "./public/admin_assets/images/content/" . $_FILES['files']['name'][$i];

					//Upload the file into the temp dir
					if(move_uploaded_file($tmpFilePath, $newFilePath)) {

					  $udata['content_filepath'] = base_url()."public/admin_assets/images/content/".$_FILES['files']['name'][$i];
					  $path_parts = pathinfo($_FILES['files']['name'][$i]);
					  $extension = $path_parts['extension'];
					  $udata['content_filetype'] = $extension;
					  $udata['content_name'] =  $_FILES['files']['name'][$i];
					  $udata['course_id'] = $this->input->post('course_id');
					  $udata['teacher_id'] = 37726;
					$url = "http://ec2-18-218-68-83.us-east-2.compute.amazonaws.com/flaskapp/myelsa_course/MyelsaCourse/CreateCourseContent";
					
					$data = array();
					
					$make_call = $this->callAPI('POST', $url,json_encode($udata));
					
					$response = json_decode($make_call, true);

					}
				  }
				}
				
				$success_message = 'Added successfully';
				$this->session->set_flashdata('success_msg',$success_message);
				redirect('admin/gallery/content');	
				
			
	}
	
	private function callAPI($method, $url, $data){
	   $curl = curl_init();
	   switch ($method){
		  case "POST":
			 curl_setopt($curl, CURLOPT_POST, 1);
			 curl_setopt($curl,CURLOPT_SSL_VERIFYPEER, false);
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
			 break;
		  case "PUT":
			 curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);			 					
			 break;
		  default:
			 if ($data)
				$url = sprintf("%s?%s", $url, http_build_query($data));
	   }
	   // OPTIONS:
	   curl_setopt($curl, CURLOPT_URL, $url);
	   curl_setopt($curl, CURLOPT_HTTPHEADER,array(
		'Content-Type: application/json',
		));
	   curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
	   curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
	   // EXECUTE:
	   $result = curl_exec($curl);
	   if(!$result){die("Connection Failure");}
	   curl_close($curl);
	   return $result;
	}
	
}