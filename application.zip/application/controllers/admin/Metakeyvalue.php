<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Metakeyvalue extends MY_Controller {
	public function __construct() {
		parent::__construct();
		$this->redirect_guest();
		$this->admin=$this->session->userdata('admin');
		$this->base_url = "http://ec2-18-221-89-14.us-east-2.compute.amazonaws.com/flaskapp/ecommerce_product/EcommerceProduct/";
	}
		
	public function index() { 
		$this->_load_list_view();		
	}
	
	private function _load_list_view() {
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$url = $this->base_url."getMetaKeyValueList/".$organisation_id;
		$data = array();
		$make_call = $this->callAPI('GET', $url,$data);
		$response = json_decode($make_call, true);
		$list = $response['responseList'];
		
		$data = array(
			"status"	=> false,
			"message"  	=> "",
			"post_data"	=>	$list
		);
		
		$data['admin'] = $this->admin;
		$data['content'] = 'admin/metakeyvalue/list';
		$this->load->view('admin/layouts/index', $data);
	}
	
	public function add(){
		$this->_load_add_view();
	}
	
	private function _load_add_view(){	
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$url = $this->base_url."getMetaKeyList/".$organisation_id;
		$data = array();
		$make_call = $this->callAPI('GET', $url,$data);
		$response = json_decode($make_call, true);
		$list = $response['responseList'];
		$data['meta_key_list'] = $list;
		$data['content']='admin/metakeyvalue/add';
		$this->load->view('admin/layouts/index',$data);
	}
	
	public function add_content(){
		if($this->input->post()){
			$this->form_validation->set_rules('meta_key_id','Tag','required');
			$this->form_validation->set_rules('meta_key_value','Tag Value','required');
			
			if($this->form_validation->run()==FALSE){			
				$this->_load_add_view();
			}else{
				$url = $this->base_url."AddMetaKeyValue";
				$udata['meta_key_id'] = $this->input->post('meta_key_id');
				$udata['meta_key_value']=$this->input->post('meta_key_value');
				if(is_uploaded_file($_FILES['imgInp']['tmp_name']))
				{
					$img=$this->image_upload();
					if($img['status']==1){
						$udata['image']=base_url()."public/admin_assets/images/meta_key_values/".$img['result'];						
					}else{
						$this->session->set_flashdata('error_msg',$img['result']);
						redirect('admin/metakeyvalue/','refersh'); 	
					}				
				}else{
					$udata['image']= "";
				}					
				
				$udata['last_update_id'] = 1;
				$organisation = $this->admin;
				$organisation_id = $organisation['organisation_id'];
				$udata['organisation_id'] = $organisation_id;
				$udata['last_update_id'] = $organisation_id;
				$make_call = $this->callAPI('POST', $url,json_encode($udata));
				$response = json_decode($make_call, true);
				
				if($response['attributes']['status'] == 'error')
				{
					$this->session->set_flashdata('error_msg',$response['responseList']);
				}else{
					$this->session->set_flashdata('success_msg','Meta Key Saved successfully');
				}
				redirect('admin/metakeyvalue');
				
			}
		}else{
			$this->_load_list_view();
		}
	}
	
	private function image_upload(){ 
		$img='imgInp';
		$config['upload_path'] = './public/admin_assets/images/meta_key_values';
		$config['allowed_types'] = 'gif|jpg|png|jpeg|GIF';
		$config['encrypt_name']  = true;
		$this->load->library('upload', $config);
		if ( ! $this->upload->do_upload($img)){
			$message = array('result' => $this->upload->display_errors(),'status'=>0);
		}else{ 
			$data = array('upload_data' => $this->upload->data());
			$message = array('result' => $data['upload_data']['file_name'],'status'=>1);
		}
		return $message;
	}
	
	public function edit($meta_key_value_id)
	{
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		
		$url = "http://ec2-18-223-212-150.us-east-2.compute.amazonaws.com/flaskapp/ecommerce_product/EcommerceProduct/getMetaKeyList/".$organisation_id;
		$data = array();
		$make_call = $this->callAPI('GET', $url,$data);
		$response = json_decode($make_call, true);
		$list = $response['responseList'];
		$data['meta_key_list'] = $list;
		
		$udata = array();
		$url_m = "http://ec2-18-223-212-150.us-east-2.compute.amazonaws.com/flaskapp/ecommerce_product/EcommerceProduct/getMetaKeyValueDetails/".$organisation_id."/".$meta_key_value_id;
		$make_call = $this->callAPI('GET', $url_m,$udata);
		$response = json_decode($make_call, true);
		
		$data['cms'] = $response['responseList'];	
		
		if(empty($data['cms'])){
			$this->_load_list_view();
		}else{			
			$this->_load_details_view($data);
		}
	}
	
	public function _load_details_view($parms)
	{
		$data['cms']=$parms['cms'];
		$data['meta_key_list'] = $parms['meta_key_list'];
		$data['content'] = 'admin/metakeyvalue/detail';
		$this->load->view('admin/layouts/index', $data);
	}
	
	public function update()
	{
		if($this->input->post()){
			$meta_key_value_id = $this->input->post('meta_key_value_id');
			$this->form_validation->set_rules('meta_key_id','Tag','required');
			$this->form_validation->set_rules('meta_key_value','Tag Value','required');
			if($this->form_validation->run()==FALSE){
				$organisation = $this->admin;
				$organisation_id = $organisation['organisation_id'];	
				$url = "http://ec2-18-223-212-150.us-east-2.compute.amazonaws.com/flaskapp/ecommerce_product/EcommerceProduct/getMetaKeyList/".$organisation_id;
				$data = array();
				$make_call = $this->callAPI('GET', $url,$data);
				$response = json_decode($make_call, true);
				$list = $response['responseList'];
				$data['meta_key_list'] = $list;
				
				$url = "http://ec2-18-223-212-150.us-east-2.compute.amazonaws.com/flaskapp/ecommerce_product/EcommerceProduct/getMetaKeyValueDetails/".$organisation_id."/".$meta_key_value_id;
				$make_call = $this->callAPI('GET', $url,$data);
				$response = json_decode($make_call, true);
				$data['cms'] = $response['responseList'];
				
				$this->_load_details_view($data);
			}else{
				$udata['meta_key_id'] = $this->input->post('meta_key_id');
				$udata['meta_key_value'] = $this->input->post('meta_key_value');
				
				if(is_uploaded_file($_FILES['imgInp']['tmp_name']))
				{
					$img=$this->image_upload();
					if($img['status']==1){
						$udata['image']=base_url()."public/admin_assets/images/meta_key_values/".$img['result'];						
					}else{
						$this->session->set_flashdata('error_msg',$img['result']);
						redirect('admin/metakeyvalue/','refersh'); 	
					}				
				}
				
				$organisation = $this->admin;
				$organisation_id = $organisation['organisation_id'];	
				
				$udata['organisation_id'] = $organisation_id;
				$udata['last_updated_id'] = $organisation_id;
				$url = $this->base_url."UpdateMetaKeyValue/".$meta_key_value_id;
				$make_call = $this->callAPI('PUT', $url,json_encode($udata));
				$response = json_decode($make_call, true);
				
				if($response['attributes']['status'] == 'error')
				{
					$this->session->set_flashdata('error_msg',$response['responseList']);
				}else{
					$this->session->set_flashdata('success_msg',$response['responseList']);
				}
				redirect('admin/metakeyvalue');
			}
		}else{
			$this->_load_list_view();
		}
	}
	
	public function delete_meta_key_value()
	{		
		$meta_key_value_id = $this->input->post('meta_key_value_id');
		$url = $this->base_url."deleteMetaKeyValue/".$meta_key_value_id;
		$data = array();
		$make_call = $this->callAPI('DELETE', $url,$data);
		$response = json_decode($make_call, true);
		echo json_encode($response);
	}
	
	public function callAPI($method, $url, $data){
	   $curl = curl_init();
	   switch ($method){
		  case "POST":
			 curl_setopt($curl, CURLOPT_POST, 1);
			 curl_setopt($curl,CURLOPT_SSL_VERIFYPEER, false);
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
			 break;
		  case "PUT":
			 curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);			 					
			 break;
		  case "DELETE":
			 curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "DELETE");
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);			 					
			 break;
		  default:
			 if ($data)
				$url = sprintf("%s?%s", $url, http_build_query($data));
	   }
	   // OPTIONS:
	   curl_setopt($curl, CURLOPT_URL, $url);
	   curl_setopt($curl, CURLOPT_HTTPHEADER,array(
		'Content-Type: application/json',
		));
	   curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
	   curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
	   // EXECUTE:
	   $result = curl_exec($curl);
	   if(!$result){die("Connection Failure");}
	   curl_close($curl);
	   return $result;
	}
}