<?php
ini_set('max_execution_time', 36000);
defined('BASEPATH') OR exit('No direct script access allowed');

class Pfdms extends MY_Controller {
	public function __construct() {
		parent::__construct();
		$this->redirect_guest();
		$this->admin=$this->session->userdata('admin');
		$this->base_url = "http://ec2-18-221-89-14.us-east-2.compute.amazonaws.com/flaskapp/dms_section/DmsSection/";
		$this->local_base_url = "http://127.0.0.1:5000/dms_section/DmsSection/";
		$this->payment_base_url = "http://ec2-18-221-89-14.us-east-2.compute.amazonaws.com/flaskapp/p_tax_payment/pTaxPayment/";
		$this->challan_base_url = "http://ec2-18-221-89-14.us-east-2.compute.amazonaws.com/flaskapp/p_tax_challan/pTaxChallan/";
	}
	public function index() {		
		$this->_load_list_view();
	}
	
	private function _load_list_view() {
		if($this->input->post()){
			$start_date = $this->input->post('start_date');
			$end_date = $this->input->post('end_date');
			$content_type = $this->input->post('content_type');
			$user = $this->admin;
			if($start_date == '' && $end_date == '' && $content_type == '')
			{
				$start_date = 'NA';
				$end_date = 'NA';
				$content_type = 'NA';
			}else{
				if($start_date == '' && $end_date == '')
				{
					$start_date = 'NA';
					$end_date = 'NA';
					$content_type = $content_type;
				}else if ($content_type == ''){
					$start_date = $start_date;
					$end_date = $end_date;
				}else{
					$start_date = $start_date;
					$end_date = $end_date;
					$content_type = $content_type;
				}
			}
			$url = $this->base_url."UploadingTrackList/".$user['user_id']."/".$start_date."/".$end_date."/".$content_type."/pf";
			$data = array();
			$make_call = $this->callAPI('GET', $url,$data);
			$response = json_decode($make_call, true);
			$list = $response['responseList'];
			
			$data = array(
				"status"	=> false,
				"message"  	=> "",
				"post_data"	=>	$list
			);
			
			if($start_date == '' && $end_date == '' && $content_type == '')
			{
				$data['start_date'] = '';
				$data['end_date'] = '';
				$data['content_type'] = '';
			}else{				
				$data['start_date'] =  $this->input->post('start_date');
				$data['end_date'] = $this->input->post('end_date');
				$data['content_type'] = $this->input->post('content_type');
			}			
				
			$data['admin'] = $this->admin;	
			
		}else{
			$start_date = 'NA';
			$end_date = 'NA';
			$content_type = 'NA';
			$user = $this->admin;
			$url = $this->base_url."UploadingTrackList/".$user['user_id']."/".$start_date."/".$end_date."/".$content_type."/pf";
			$data = array();
			$make_call = $this->callAPI('GET', $url,$data);
			$response = json_decode($make_call, true);
			$list = $response['responseList'];
			
			$data = array(
				"status"	=> false,
				"message"  	=> "",
				"post_data"	=>	$list
			);
			
			$data['start_date'] = '';
			$data['end_date'] = '';		
			$data['content_type'] = '';
			$data['admin'] = $this->admin;	
		}
		
		$data['content'] = 'admin/pf/list';
		$this->load->view('admin/layouts/index', $data);		
	}
	public function uploading_track_details_list($request_no)
	{
		$url = $this->base_url."UploadingTrackDetailsList/".$request_no;
		$this->_load_track_deatils_list_view($url);
	}
	
	private function _load_track_deatils_list_view($url) {
		$data = array();
		$make_call = $this->callAPI('GET', $url,$data);
		$response = json_decode($make_call, true);
		$list = $response['responseList'];
		
		$data = array(
			"status"	=> false,
			"message"  	=> "",
			"post_data"	=>	$list
		);
		
		$data['admin'] = $this->admin;
		$data['content_type'] = $response['attributes']['content_type'];
		$data['content'] = 'admin/pf/detailslist';
		$this->load->view('admin/layouts/index', $data);
	}
	
	public function pf_details($uploading_track_details_id)
	{
		$data = array();
		$UploadingTrackurl = $this->base_url."uploadingTrackByUploadingTrackDetailsId/".$uploading_track_details_id;
		$make_call = $this->callAPI('GET', $UploadingTrackurl,$data);
		$UploadingTrackresponse = json_decode($make_call, true);
		$uploading_track_data = $UploadingTrackresponse['responseList'];
		
		if ($uploading_track_data['content_type'] == "challan"){	
			$url = $this->base_url."pfChallanDetails/".$uploading_track_details_id;
			$make_call = $this->callAPI('GET', $url,$data);
			$response = json_decode($make_call, true);
			$data['pf_challan_data'] = $response['responseList'];			
			$data['uploadig_file_name'] =  str_replace('_', ' ', $uploading_track_data['uploadig_file_name']);
			$this->_load_pf_challan_deatils_view($data);
		}else{
			$url = $this->base_url."pfPaymentDetails/".$uploading_track_details_id;
			$make_call = $this->callAPI('GET', $url,$data);
			$response = json_decode($make_call, true);
			$data['p_tax_payment_data'] = $response['responseList'];	
			$data['uploadig_file_name'] =  str_replace('_', ' ', $uploading_track_data['uploadig_file_name']);	
			$this->_load_pf_payment_deatils_view($data);
		}
	}
	
	public function _load_pf_challan_deatils_view($parms)
	{
		$data['cms']=$parms['pf_challan_data'];	
		$data['uploadig_file_name'] = $parms['uploadig_file_name'];
		$data['content'] = 'admin/pf/pf_challan_details';
		$this->load->view('admin/layouts/index', $data);
	}
	
	public function _load_pf_payment_deatils_view($parms)
	{
		$data['cms']=$parms['p_tax_payment_data'];		
		$data['uploadig_file_name'] = $parms['uploadig_file_name'];	
		$data['content'] = 'admin/pf/pf_payment_details';
		$this->load->view('admin/layouts/index', $data);
	}
	
	public function pf_challan_data_update()
	{	
		$pf_challan_id = $this->input->post('pf_challan_id');
		$uploading_track_details_id = $this->input->post('uploading_track_details_id');
		$data['trn'] = $this->input->post('trn');
		$data['establishment_code'] = $this->input->post('establishment_code');
		$data['establishment_name'] = $this->input->post('establishment_name');
		$data['due_for_the_wages_month_of_data'] = $this->input->post('due_for_the_wages_month_of_data');
		$data['due_for_the_wages_year_of_data'] = $this->input->post('due_for_the_wages_year_of_data');
		$data['total_subscribers_epf'] = $this->input->post('total_subscribers_epf');
		$data['total_subscribers_eps'] = $this->input->post('total_subscribers_eps');
		$data['total_subscribers_edli'] = $this->input->post('total_subscribers_edli');
		$data['total_wages_epf'] = $this->input->post('total_wages_epf');
		$data['total_wages_eps'] = $this->input->post('total_wages_eps');
		$data['total_wages_edli'] = $this->input->post('total_wages_edli');
		$data['administration_charges_ac_01'] = $this->input->post('administration_charges_ac_01');
		$data['administration_charges_ac_02'] = $this->input->post('administration_charges_ac_02');
		$data['administration_charges_ac_10'] = $this->input->post('administration_charges_ac_10');
		$data['administration_charges_ac_21'] = $this->input->post('administration_charges_ac_21');
		$data['administration_charges_ac_22'] = $this->input->post('administration_charges_ac_22');
		$data['administration_charges_ac_total'] = $this->input->post('administration_charges_ac_total');
		$data['employers_share_of_ac_01'] = $this->input->post('employers_share_of_ac_01');
		$data['employers_share_of_ac_02'] = $this->input->post('employers_share_of_ac_02');
		$data['employers_share_of_ac_10'] = $this->input->post('employers_share_of_ac_10');
		$data['employers_share_of_ac_21'] = $this->input->post('employers_share_of_ac_21');
		$data['employers_share_of_ac_22'] = $this->input->post('employers_share_of_ac_22');	
		$data['employers_share_of_ac_total'] = $this->input->post('employers_share_of_ac_total');	
		$data['employees_share_of_ac_01'] = $this->input->post('employees_share_of_ac_01');
		$data['employees_share_of_ac_02'] = $this->input->post('employees_share_of_ac_02');
		$data['employees_share_of_ac_10'] = $this->input->post('employees_share_of_ac_10');
		$data['employees_share_of_ac_21'] = $this->input->post('employees_share_of_ac_21');
		$data['employees_share_of_ac_22'] = $this->input->post('employees_share_of_ac_22');
		$data['employees_share_of_ac_total'] = $this->input->post('employees_share_of_ac_total');
		$data['ac_no_1_employer_share_rs_pmrpy_data'] = $this->input->post('ac_no_1_employer_share_rs_pmrpy_data');
		$data['ac_no_1_employers_share_rs_pmgky_data'] = $this->input->post('ac_no_1_employers_share_rs_pmgky_data');
		$data['ac_no_10_Pension_fund_rs_pmrpy_data'] = $this->input->post('ac_no_10_Pension_fund_rs_pmrpy_data');
		$data['ac_no_10_Pension_fund_rs_pmgky_data'] = $this->input->post('ac_no_10_Pension_fund_rs_pmgky_data');
		$data['ac_no_1_employee_share_rs_pmrpy_data'] = $this->input->post('ac_no_1_employee_share_rs_pmrpy_data');
		$data['ac_no_1_employee_share_rs_pmgky_data'] = $this->input->post('ac_no_1_employee_share_rs_pmgky_data');
		$data['total_a_b_c_rs_pmrpy_data'] = $this->input->post('total_a_b_c_rs_pmrpy_data');
		$data['total_a_b_c_rs_pmgky_data'] = $this->input->post('total_a_b_c_rs_pmgky_data');
		$data['grand_total'] = $this->input->post('grand_total');
		$data['total_remittance_by_employer_rs'] = $this->input->post('total_remittance_by_employer_rs');
		$data['total_amount_of_uploaded_ECR'] = $this->input->post('total_amount_of_uploaded_ECR');
		$data['due_for_the_wages_month_of_data'] = $this->input->post('due_for_the_wages_month_of_data');
		$data['due_for_the_wages_year_of_data'] = $this->input->post('due_for_the_wages_year_of_data');
		
		//print_r($data);exit;
		
		$url = $this->base_url."updatePfChallanData/".$pf_challan_id;		
		$make_call = $this->callAPI('PUT', $url,json_encode($data));
		$response = json_decode($make_call, true);		
		
		if($response['attributes']['status'] == 'success')
		{
			$this->session->set_flashdata('success_msg',$response['attributes']['status_desc']);
		}else{
			$this->session->set_flashdata('error_msg',$response['responseList']);			
		}
		redirect('admin/pfdms/pf_details/'.$uploading_track_details_id);
	}
	public function pf_payment_data_update()
	{		
		$pf_payment_id = $this->input->post('pf_payment_id');
		$uploading_track_details_id = $this->input->post('uploading_track_details_id');
		$data['grn'] = $this->input->post('grn');
		$data['challan_status_data'] = $this->input->post('challan_status_data');
		$data['challan_generated_on_data'] = $this->input->post('challan_generated_on_data');
		$data['establishment_id_data'] = $this->input->post('establishment_id_data');
		$data['challan_type_data'] = $this->input->post('challan_type_data');
		$data['wages_month_data'] = $this->input->post('wages_month_data');
		$data['total_amount_rs_data'] = $this->input->post('total_amount_rs_data');
		$data['account_1_amount_rs_data'] = $this->input->post('account_1_amount_rs_data');
		$data['account_2_amount_rs_data'] = $this->input->post('account_2_amount_rs_data');
		$data['account_10_amount_rs_data'] = $this->input->post('account_10_amount_rs_data');
		$data['account_21_amount_rs_data'] = $this->input->post('account_21_amount_rs_data');
		$data['account_22_amount_rs_data'] = $this->input->post('account_22_amount_rs_data');
		$data['payment_confirmation_bank_data'] = $this->input->post('payment_confirmation_bank_data');
		$data['crn_data'] = $this->input->post('crn_data');
		$data['payment_date_data'] = $this->input->post('payment_date_data');
		$data['payment_confirmation_date_data'] = $this->input->post('payment_confirmation_date_data');
		$data['total_pmrpy_benefit_data'] = $this->input->post('total_pmrpy_benefit_data');
		
		$url = $this->local_base_url."updatePfPaymentData/".$pf_payment_id;		
		$make_call = $this->callAPI('PUT', $url,json_encode($data));
		$response = json_decode($make_call, true);		
		
		if($response['attributes']['status'] == 'success')
		{
			$this->session->set_flashdata('success_msg',$response['attributes']['status_desc']);
		}else{
			$this->session->set_flashdata('error_msg',$response['responseList']);			
		}
		redirect('admin/pfdms/pf_details/'.$uploading_track_details_id);
	}
	
	public function add(){
		$this->_load_add_view();
	}
	
	private function _load_add_view(){
		$data['content']='admin/pf/add';
		$this->load->view('admin/layouts/index',$data);
	}
	
	public function add_content(){	
		$file_type = $this->input->post('file_type');
		$content_type = $this->input->post('content_type');		
		
		$user = $this->admin;
		$user_id = $user['user_id'];
		$total = count($_FILES['files']['name']);
		$uploading_track_url = $this->base_url."UploadingTrack";
		$uploading_track_data['uploading_file_count'] = $total;
		$uploading_track_data['last_update_id'] = $user_id;
		$uploading_track_data['file_type'] = $file_type;
		$uploading_track_data['content_type'] = $content_type;
		$uploading_track_data['uploading_type'] = 'pf';
		$uploading_track_call = $this->callAPI('POST', $uploading_track_url,json_encode($uploading_track_data));
		$uploading_track_response = json_decode($uploading_track_call, true);
		$request_no = $uploading_track_response['responseList']['request_no'];
		
		for( $i=0 ; $i < $total ; $i++ ) {
			$tmpFilePath = $_FILES['files']['tmp_name'][$i];
			$filename = $_FILES['files']['name'][$i];
			$filedata = $_FILES['files']['tmp_name'][$i];
			$filesize = $_FILES['files']['size'][$i];
			$type = $_FILES['files']['type'][$i];			
			
			if ($tmpFilePath != ''){
				$upload_s3_bucket_url =  $this->base_url.'uploadToS3Bucket/'.$user_id."/".$request_no;
				$upload_s3_bucket_call = $this->callAPIUpload($upload_s3_bucket_url,$filedata,$type,$filename);
				$upload_s3_bucket_response = json_decode($upload_s3_bucket_call, true);				
				$convetJsonFromUploadinFiledata['document_name'] = $upload_s3_bucket_response['responseList'][0]['FilePath'];
				$convetJsonFromUploadinFiledata['request_no'] = $upload_s3_bucket_response['responseList'][0]['request_no'];
				$convetJsonFromUploadinFiledata['user_id'] = $user_id;
				$convetJsonFromUploadinFileUrl = $this->base_url.'ConvetJsonFromUploadinFile';
				$convetJsonFromUploadinFile_call = $this->callAPI('POST', $convetJsonFromUploadinFileUrl,json_encode($convetJsonFromUploadinFiledata));
				$convetJsonFromUploadinFile_response = json_decode($convetJsonFromUploadinFile_call, true);
			}
			
			$uploads_dir = './public/images/';
			$tmp_name = $_FILES["files"]["tmp_name"][$i];
			$name = basename($_FILES["files"]["name"][$i]);
			
			if( move_uploaded_file($tmp_name, "$uploads_dir/$name")) {
				$is_upload = 1;
			} else {
				$is_upload = 0;
			}
		}
		redirect('admin/pfdms');
	}
	
	public function callAPI($method, $url, $data){
	   $curl = curl_init();
	   switch ($method){
		  case "POST":
			 curl_setopt($curl, CURLOPT_POST, 1);
			 curl_setopt($curl,CURLOPT_SSL_VERIFYPEER, false);
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
			 break;
		  case "PUT":
			 curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);			 					
			 break;
		  case "DELETE":
			 curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "DELETE");
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);			 					
			 break;
		  default:
			 if ($data)
				$url = sprintf("%s?%s", $url, http_build_query($data));
	   }
	   // OPTIONS:
	   curl_setopt($curl, CURLOPT_URL, $url);
	   curl_setopt($curl, CURLOPT_HTTPHEADER,array(
		'Content-Type: application/json',
		));
	   curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
	   curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
	   // EXECUTE:
	   $result = curl_exec($curl);
	   if(!$result){die("Connection Failure");}
	   curl_close($curl);
	   return $result;
	}	
	
	public function callAPIUpload($url, $filedata, $type,$filename){
	  $fields = [
			'file' => new \CurlFile(realpath($filedata), $type, $filename)
		];
		
			// Generated by curl-to-PHP: http://incarnate.github.io/curl-to-php/
		$ch = curl_init();
		
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_URL, $url);
		
		curl_setopt($ch, CURLOPT_HTTPHEADER,array(
			'Accept: application/json',
			'Content-Type: multipart/form-data'
		));
		
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);			
		
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		
		

		$result = curl_exec($ch);
		//$info = curl_getinfo($ch);
		//print_r($info['request_header']);exit;
		if(!$result){die("Connection Failure");}
		curl_close($curl);
		
		return $result;
	}
}