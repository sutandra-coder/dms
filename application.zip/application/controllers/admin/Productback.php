<?php
ini_set('max_execution_time', 36000);
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends MY_Controller {
	public function __construct() {
		parent::__construct();
		$this->redirect_guest();
		$this->admin=$this->session->userdata('admin');
		$this->load->model('admin/mproduct');
		$this->base_url = "http://ec2-3-19-228-138.us-east-2.compute.amazonaws.com/flaskapp/ecommerce_product/EcommerceProduct/";
	}
		
	public function index() { 
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		if($this->input->post()){			
			$category_id = $this->input->post('meta_key_id');
			if(!empty($category_id))
			{
				$url = $this->base_url."productList/".$organisation_id."/".$category_id;
			}else{
				$category_id = 0;
				$url = $this->base_url."productList/".$organisation_id."/".$category_id;
			}
		}else{			
			$category_id = 0;
			$url = $this->base_url."productList/".$organisation_id."/".$category_id;
		}	
		$this->_load_list_view($url);		
	}
	
	private function _load_list_view($url) {
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$product_data = array();
		$make_call = $this->callAPI('GET', $url,$product_data);
		$response = json_decode($make_call, true);
		$list = $response['responseList'];
		
		$data = array(
			"status"	=> false,
			"message"  	=> "",
			"post_data"	=>	$list
		);
		$meta_key_list_url = $this->base_url."getMetaKeyList/".$organisation_id;
		$meta_key_data = array();
		$make_call_meta_key = $this->callAPI('GET', $meta_key_list_url,$meta_key_data);
		$response_meta_key = json_decode($make_call_meta_key, true);
		$data['meta_key_list'] = $response_meta_key['responseList'];		
		
		$discount_list_url = $this->base_url."discountList/".$organisation_id;
		$discount_data = array();
		$make_call_discount = $this->callAPI('GET', $discount_list_url,$discount_data);
		$response_discount = json_decode($make_call_discount, true);
		$data['discount_list'] = $response_discount['responseList'];
		
		$offer_list_url = $this->base_url."getOfferList/".$organisation_id;
		$offer_data = array();
		$make_call_offer = $this->callAPI('GET', $offer_list_url,$offer_data);
		$response_offer = json_decode($make_call_offer, true);
		$data['offer_list'] = $response_offer['responseList'];
		
		$new_arrival_list_url = $this->base_url."getNewArrivalList/".$organisation_id;
		$new_arrival_data = array();
		$make_call_new_arrival = $this->callAPI('GET', $new_arrival_list_url,$new_arrival_data);
		$response_new_arrival = json_decode($make_call_new_arrival, true);
		$data['new_arrival_list'] = $response_new_arrival['responseList'];
		
		$brand_list_url = $this->base_url."getMetaKeyValueListMetaId/2/".$organisation_id;
		$brand_data = array();
		$make_call_brand = $this->callAPI('GET', $brand_list_url,$brand_data);
		$response_brand = json_decode($make_call_brand, true);
		$data['brand_list'] = $response_brand['responseList'];
		
		$category_list_url = $this->base_url."getMetaKeyValueListMetaId/1/".$organisation_id;
		$category_data = array();
		$make_call_category = $this->callAPI('GET', $category_list_url,$category_data);
		$response_category = json_decode($make_call_category, true);
		$data['category_list'] = $response_category['responseList'];
		
		$data['admin'] = $this->admin;				
		$data['content'] = 'admin/product/list';
		$this->load->view('admin/layouts/index', $data);
	}
	
	public function meta_list(){
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$product_id = $this->input->post('product_id');	
		$url = $this->base_url."productMetaList/".$product_id."/".$organisation_id;
		$data = array();
		$make_call = $this->callAPI('GET', $url,$data);
		$response = json_decode($make_call, true);
		
		$url_product_details = $this->base_url."productDetails/".$product_id."/".$organisation_id;
		$product_details_data = array();
		$make_product_details_call = $this->callAPI('GET', $url_product_details,$product_details_data);
		$response_product_details = json_decode($make_product_details_call, true);
		$response['productDetails'] = $response_product_details['responseList'];
		
		echo json_encode($response);
	}
	
	public function meta_details(){
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$product_meta_id = $this->input->post('product_meta_id');	
		$url = $this->base_url."getProductMetaDetails/".$product_meta_id."/".$organisation_id;
		$data = array();
		$make_call = $this->callAPI('GET', $url,$data);
		$response = json_decode($make_call, true);		
		echo json_encode($response);
	}
	
	public function meta_key_valuelist(){
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$meta_key_id = $this->input->post('meta_key_id');
		$url = $this->base_url."getMetaKeyValueListMetaId/".$meta_key_id."/".$organisation_id;
		$data = array();
		$make_call = $this->callAPI('GET', $url,$data);
		$response = json_decode($make_call, true);
		echo json_encode($response);
	}
	
	public function save_product_meta(){
		$meta_key_text = $this->input->post('meta_key_text');
		$product_id = $this->input->post('product_id');
		$in_price = $this->input->post('in_price');
		$out_price = $this->input->post('out_price');
		$product_meta_code = $this->input->post('product_meta_code');
		
		$url = $this->base_url."AddProductMeta";
		$udata['product_id'] = $product_id;
		$udata['product_meta_code'] = $product_meta_code;
		$udata['meta_key_text'] = $meta_key_text;
		$udata['in_price'] = $in_price;
		$udata['out_price'] = $out_price;
		$udata['last_update_id'] = 1;
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$udata['organisation_id'] = $organisation_id;
		$make_call = $this->callAPI('POST', $url,json_encode($udata));
		$response = json_decode($make_call, true);		
		echo json_encode($response);
	}
	
	public function save_product_meta_discount(){
		$product_meta_id = $this->input->post('product_meta_id');
		$discount_id = $this->input->post('discount_id');
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$last_update_id = $organisation_id;
		
		$url = $this->base_url."ProductMetaDiscount";
		$udata = '{
		  "product_meta_id": [
			'.$product_meta_id.'
		  ],
		  "discount_id": '.$discount_id.',
		  "organisation_id": '.$organisation_id.',
		  "last_update_id": '.$last_update_id.'
		}';
		$make_call = $this->callAPI('POST', $url,$udata);
		$response = json_decode($make_call, true);		
		echo json_encode($response);
	}
	
	public function save_product_offer(){
		$product_id = $this->input->post('product_id');
		$offer_id = $this->input->post('offer_id');
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$last_update_id = $organisation_id;
		
		$url = $this->base_url."addProductOffer";
		$udata = '{
		  "product_id": [
			'.$product_id.'
		  ],
		  "offer_id": '.$offer_id.',
		  "organisation_id": '.$organisation_id.',
		  "last_update_id": '.$last_update_id.'
		}';
		$make_call = $this->callAPI('POST', $url,$udata);
		$response = json_decode($make_call, true);		
		echo json_encode($response);
	}
	
	public function save_product_new_arrival(){
		$product_id = $this->input->post('product_id');
		$new_arrival_id = $this->input->post('new_arrival_id');
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$last_update_id = $organisation_id;
		
		$url = $this->base_url."addProductnewArrival";
		$udata = '{
		  "product_id": [
			'.$product_id.'
		  ],
		  "new_arrival_id": '.$new_arrival_id.',
		  "organisation_id": '.$organisation_id.',
		  "last_update_id": '.$last_update_id.'
		}';
		$make_call = $this->callAPI('POST', $url,$udata);
		$response = json_decode($make_call, true);		
		echo json_encode($response);
	}
	
	public function save_product_brand(){
		$product_id = $this->input->post('product_id');
		$brand_id = $this->input->post('brand_id');
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$last_update_id = $organisation_id;
		
		$url = $this->base_url."addProductBrand";
		$udata = '{
		  "product_id": [
			'.$product_id.'
		  ],
		  "brand_id": '.$brand_id.',
		  "organisation_id": '.$organisation_id.',
		  "last_update_id": '.$last_update_id.'
		}';
		$make_call = $this->callAPI('POST', $url,$udata);
		$response = json_decode($make_call, true);		
		echo json_encode($response);
	}
	
	public function save_product_category(){
		$product_id = $this->input->post('product_id');
		$category_id = $this->input->post('category_id');
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$last_update_id = $organisation_id;
		
		$url = $this->base_url."addProductCategory";
		$udata = '{
		  "product_id": [
			'.$product_id.'
		  ],
		  "category_id": '.$category_id.',
		  "organisation_id": '.$organisation_id.',
		  "last_update_id": '.$last_update_id.'
		}';
		
		$make_call = $this->callAPI('POST', $url,$udata);
		$response = json_decode($make_call, true);		
		echo json_encode($response);
	}
	
	public function update_product_meta(){
		$in_price = $this->input->post('in_price');
		$out_price = $this->input->post('out_price');
		$product_meta_code = $this->input->post('product_meta_code');
		$product_meta_id = $this->input->post('product_meta_id');	
		$loyalty_points = $this->input->post('loyalty_points');
		
		if (!empty($this->input->post('Rea_Camera_Lens_1'))){
			$Rea_Camera_Lens_1 = $this->input->post('Rea_Camera_Lens_1');
		}else{
			$Rea_Camera_Lens_1 = "";
		}
		
		if (!empty($this->input->post('Rea_Camera_Lens_2'))){
			$Rea_Camera_Lens_2 = $this->input->post('Rea_Camera_Lens_2');
		}else{
			$Rea_Camera_Lens_2 = "";
		}
		
		if (!empty($this->input->post('Screen_Size'))){
			$Screen_Size = $this->input->post('Screen_Size');
		}else{
			$Screen_Type =  "";
		}
		
		if (!empty($this->input->post('Battery_Power'))){
			$Battery_Power = $this->input->post('Battery_Power');
		}else{
			$Battery_Power =  "";
		}
		
		if (!empty($this->input->post('Inbuilt_Storage'))){
			$Inbuilt_Storage = $this->input->post('Inbuilt_Storage');
		}else{
			$Inbuilt_Storage =  "";
		}
		
		if (!empty($this->input->post('RAM'))){
			$RAM = $this->input->post('RAM');
		}else{
			$RAM =  "";
		}
		
		if (!empty($this->input->post('Expandable_Storage'))){
			$Expandable_Storage = $this->input->post('Expandable_Storage');
		}else{
			$Expandable_Storage =  "";
		}
		
		if (!empty($this->input->post('Processor_Brand'))){
			$Processor_Brand = $this->input->post('Processor_Brand');
		}else{
			$Processor_Brand =  "";
		}
		
		if (!empty($this->input->post('Operating_System'))){
			$Operating_System = $this->input->post('Operating_System');
		}else{
			$Operating_System =  "";
		}
		
		
		$other_specification_json = array("Rear_Camera_Lens_1"=>$Rea_Camera_Lens_1,"Rear_Camera_Lens_2"=>$Rea_Camera_Lens_2,"Screen_Size"=>$Screen_Size,"Screen_Type"=>$Screen_Type,"Battery_Power"=>$Battery_Power,"Inbuilt_Storage"=>$Inbuilt_Storage,"RAM"=>$RAM,"Expandable_Storage"=>$Expandable_Storage,"Processor_Brand"=>$Processor_Brand,"Operating_System"=>$Operating_System);
		$udata['other_specification_json'] = json_encode($other_specification_json);
		$url = $this->base_url."updateProductMeta/".$product_meta_id;
		$udata['in_price'] = $in_price;
		$udata['out_price'] = $out_price;
		$udata['product_meta_code'] = $product_meta_code;
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$udata['organisation_id'] = $organisation_id;
		$udata['last_updated_id'] = $organisation_id;		
		$udata['loyalty_points'] = $loyalty_points;
		
		$url = $this->base_url."updateProductMeta/".$product_meta_id;
		$make_call = $this->callAPI('PUT', $url,json_encode($udata));
		$response = json_decode($make_call, true);
		echo json_encode($response);
	}
	public function add(){
		$this->_load_add_view();
	}
	
	private function _load_add_view(){
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];		
		$meta_key_list_url = $this->base_url."getMetaKeyList/".$organisation_id;
		$meta_key_data = array();
		$make_call_meta_key = $this->callAPI('GET', $meta_key_list_url,$meta_key_data);
		$response_meta_key = json_decode($make_call_meta_key, true);
		$data['meta_key_list'] = $response_meta_key['responseList'];	
		$data['content']='admin/product/add';
		$this->load->view('admin/layouts/index',$data);
	}
	
	public function add_content(){
		if($this->input->post()){
			$this->form_validation->set_rules('product_name','Product Name','required');
			$this->form_validation->set_rules('meta_key_id','Category','required');
			if($this->form_validation->run()==FALSE){			
				$this->_load_add_view();
			}else{				
				$url = $this->base_url."AddProduct";				
				$organisation = $this->admin;
				$organisation_id = $organisation['organisation_id'];
				$udata['organisation_id'] = $organisation_id;
				$udata['last_update_id'] = $organisation_id;
				$udata['category_id']=$this->input->post('meta_key_id');
				$udata['product_name']=$this->input->post('product_name');
				$udata['product_short_description']=$this->input->post('short_description');
				$udata['product_long_description']=$this->input->post('long_description');
				$make_call = $this->callAPI('POST', $url,json_encode($udata));
				$response = json_decode($make_call, true);
				if($response['attributes']['status'] == 'error')
				{
					$this->session->set_flashdata('error_msg',$response['responseList']);
				}else{
					$this->session->set_flashdata('success_msg','Product Saved successfully');
				}
				redirect('admin/product');
			}
		}else{
			$this->_load_list_view();
		}
	}
	
	public function edit($product_id)
	{
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$url = $this->base_url."productDetails/".$product_id."/".$organisation_id;
		$data = array();
		$make_call = $this->callAPI('GET', $url,$data);
		$response = json_decode($make_call, true);
		$data['cms'] = $response['responseList'];
		$meta_key_list_url = $this->base_url."getMetaKeyList/".$organisation_id;
		$meta_key_data = array();
		$make_call_meta_key = $this->callAPI('GET', $meta_key_list_url,$meta_key_data);
		$response_meta_key = json_decode($make_call_meta_key, true);
		$data['meta_key_list'] = $response_meta_key['responseList'];
		
		if(empty($data['cms'])){
			$this->_load_list_view();
		}else{			
			$this->_load_details_view($data);
		}
	}
	
	public function update()
	{
		if($this->input->post()){
			$product_id = $this->input->post('product_id');
			$this->form_validation->set_rules('product_name','Product Name','required');
			$this->form_validation->set_rules('meta_key_id','Category','required');
			
			if($this->form_validation->run()==FALSE){
				$organisation = $this->admin;
				$organisation_id = $organisation['organisation_id'];
				$url = $this->base_url."productDetails/".$organisation_id."/".$product_id;
				$data = array();
				$make_call = $this->callAPI('GET', $url,$data);
				$response = json_decode($make_call, true);
				$data['cms'] = $response['responseList'];
				$this->_load_details_view($data);
			}else{
				$udata['product_name'] = $this->input->post('product_name');
				$udata['product_long_description'] = $this->input->post('long_description');
				$udata['product_short_description'] = $this->input->post('short_description');
				$udata['category_id'] = $this->input->post('meta_key_id');
				$organisation = $this->admin;
				$organisation_id = $organisation['organisation_id'];
				$udata['organisation_id'] = $organisation_id;
				$udata['last_updated_id'] = $organisation_id;
				$url = $this->base_url."UpdateProductInformation/".$product_id;
				$make_call = $this->callAPI('PUT', $url,json_encode($udata));
				$response = json_decode($make_call, true);
				
				if($response['attributes']['status'] == 'error')
				{
					$this->session->set_flashdata('error_msg',$response['responseList']);
				}else{
					$this->session->set_flashdata('success_msg',$response['responseList']);
				}
				redirect('admin/product');
			}
		}else{
			$this->_load_list_view();
		}
	}
	
	public function _load_details_view($parms)
	{
		$data['cms']=$parms['cms'];	
		$data['meta_key_list'] = $parms['meta_key_list'];	
		$data['content'] = 'admin/product/detail';
		$this->load->view('admin/layouts/index', $data);
	}
	
	public function remove_latest_product()
	{
		$product_meta_id = $this->input->post('product_meta_id');
		$organisation_id = 1;
		$url = $this->base_url."deleteLatestProduct/".$product_meta_id;
		$data = array();
		$make_call = $this->callAPI('DELETE', $url,$data);
		$response = json_decode($make_call, true);
		echo json_encode($response);	
	}
	
	public function delete_product_brand()
	{
		$product_id = $this->input->post('product_id');
		$brand_id = $this->input->post('brand_id');
		$url = $this->base_url."deleteProductBrand/".$product_id."/".$brand_id;
		$data = array();
		$make_call = $this->callAPI('DELETE', $url,$data);
		$response = json_decode($make_call, true);
		echo json_encode($response);	

	}
	
	public function delete_product_category()
	{
		$product_id = $this->input->post('product_id');
		$category_id = $this->input->post('category_id');
		$url = $this->base_url."deleteProductCategory/".$product_id."/".$category_id;
		$data = array();
		$make_call = $this->callAPI('DELETE', $url,$data);
		$response = json_decode($make_call, true);
		echo json_encode($response);
	}
	
	public function delete_product_offer()
	{
		$product_id = $this->input->post('product_id');
		$offer_id = $this->input->post('offer_id');
		$url = $this->base_url."deleteProductOffer/".$product_id."/".$offer_id;
		$data = array();
		$make_call = $this->callAPI('DELETE', $url,$data);
		$response = json_decode($make_call, true);
		echo json_encode($response);
	}

	public function delete_product_new_arrival()
	{
		$product_id = $this->input->post('product_id');
		$new_arrival_id = $this->input->post('new_arrival_id');
		$url = $this->base_url."deleteProductNewArrivale/".$product_id."/".$new_arrival_id;
		$data = array();
		$make_call = $this->callAPI('DELETE', $url,$data);
		$response = json_decode($make_call, true);
		echo json_encode($response);
	}
	
	public function add_latest_product()
	{
		$product_meta_id = $this->input->post('product_meta_id');
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];		
		$url = $this->base_url."addLatestProduct";
		$data['product_meta_id'] = $product_meta_id;
		$data['organisation_id'] = $organisation_id;
		$data['last_update_id'] = 1;		
		$make_call = $this->callAPI('POST', $url,json_encode($data));
		$response = json_decode($make_call, true);
		echo json_encode($response);
	}
	
	public function add_top_selling_product()
	{
		$product_meta_id = $this->input->post('product_meta_id');
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];		
		$url = $this->base_url."addProductTopSelling";
		$data['product_meta_id'] = $product_meta_id;
		$data['organisation_id'] = $organisation_id;
		$data['last_update_id'] = 1;
		$make_call = $this->callAPI('POST', $url,json_encode($data));
		$response = json_decode($make_call, true);
		echo json_encode($response);
	}
	
	public function remove_top_selling_product()
	{
		$product_meta_id = $this->input->post('product_meta_id');
		$organisation_id = 1;
		$url = $this->base_url."deleteProductTopSelling/".$product_meta_id;
		$data = array();
		$make_call = $this->callAPI('DELETE', $url,$data);
		$response = json_decode($make_call, true);
		echo json_encode($response);	
	}
	
	public function add_best_selling_product()
	{
		$product_meta_id = $this->input->post('product_meta_id');
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];	
		$url = $this->base_url."addProductBestSelling";
		$data['product_meta_id'] = $product_meta_id;
		$data['organisation_id'] = $organisation_id;
		$data['last_update_id'] = 1;
		$make_call = $this->callAPI('POST', $url,json_encode($data));
		$response = json_decode($make_call, true);
		echo json_encode($response);
	}
	
	public function remove_best_selling_product()
	{
		$product_meta_id = $this->input->post('product_meta_id');
		$url = $this->base_url."deleteBestSellingProduct/".$product_meta_id;
		$data = array();
		$make_call = $this->callAPI('DELETE', $url,json_encode($data));
		$response = json_decode($make_call, true);
		echo json_encode($response);
	}
	
	public function remove_product_meta()
	{
		$product_meta_id = $this->input->post('product_meta_id');
		$url = $this->base_url."deleteProductMeta/".$product_meta_id;
		$data = array();
		$make_call = $this->callAPI('DELETE', $url,json_encode($data));
		$response = json_decode($make_call, true);
		echo json_encode($response);
	}
	
	public function product_meta_images()
	{
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$product_meta_id = $this->input->post('product_meta_id');	
		$url = $this->base_url."getProductMetaDetails/".$product_meta_id."/".$organisation_id;
		$data = array();
		$make_call = $this->callAPI('GET', $url,$data);
		$response = json_decode($make_call, true);
		$product_meta_id = $this->input->post('product_meta_id');
		$url = $this->base_url."getProductMetaImages/".$product_meta_id;
		$make_call = $this->callAPI('GET', $url,$data);
		$image_decode = json_decode($make_call, true);
		$response['cms'] = $image_decode['responseList']['product_image'];
		echo json_encode($response);
	}
	
	public function product_meta_images_gallery()
	{
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$product_meta_id = $this->input->post('product_meta_id');	
		$url = $this->base_url."getProductMetaDetails/".$product_meta_id."/".$organisation_id;
		$data = array();
		$make_call = $this->callAPI('GET', $url,$data);
		$response = json_decode($make_call, true);
		$product_meta_id = $this->input->post('product_meta_id');
		$url = $this->base_url."getProductMetaImagesForGallery/".$product_meta_id;
		$make_call = $this->callAPI('GET', $url,$data);
		$image_decode = json_decode($make_call, true);
		$response['cms'] = $image_decode['responseList']['product_image'];
		echo json_encode($response);
	}
	
	public function save_product_meta_image()
	{
		$product_meta_id = $this->input->post('product_meta_id');
		$total = count($_FILES['files']['name']);
				// Loop through each file
		for( $i=0 ; $i < $total ; $i++ ) {

			//Get the temp file path
			$tmpFilePath = $_FILES['files']['tmp_name'][$i];
			
			$filename = $_FILES['files']['name'][$i];
			$filedata = $_FILES['files']['tmp_name'][$i];
			$filesize = $_FILES['files']['size'][$i];
			$type = $_FILES['files']['type'][$i];

			//Make sure we have a file path
			if ($tmpFilePath != ""){
				//Setup our new file path
				$newFilePath = "./public/admin_assets/images/content/" . $_FILES['files']['name'][$i];
				
				
				$url = 'http://ec2-3-19-228-138.us-east-2.compute.amazonaws.com/flaskapp/aws_portal_upload/awsResourceUploadController/uploadToS3Bucket/28';
				$make_call = $this->callAPIUpload($url,$filedata,$type,$filename);
				
				if($type == 'video/mp4'){
					$udata['image_type'] = 2;
				}else{
					$udata['image_type'] = 1;
				}
				
				$response = json_decode($make_call, true);
				
				if(!empty($response['responseList'][0]['FilePath'])){
					$udata['product_meta_id'] = $product_meta_id;
					$udata['image'] = $response['responseList'][0]['FilePath'];
					$udata['status'] = 1;
					$organisation = $this->admin;
					$organisation_id = $organisation['organisation_id'];
					$udata['organisation_id'] = $organisation_id;
					$udata['last_update_id'] = $organisation_id;
					
					$url_add_product_images = $this->base_url."AddProductImages";
					$make_call_product_images = $this->callAPI('POST', $url_add_product_images,json_encode($udata));
					$response = json_decode($make_call_product_images, true);
				}
					//Upload the file into the temp dir
				/*if(move_uploaded_file($tmpFilePath, $newFilePath)) {
					$udata['product_meta_id'] = $product_meta_id;
					$udata['image'] = base_url()."public/admin_assets/images/content/".$_FILES['files']['name'][$i];
					$udata['default_image_flag'] = 0;
					$udata['status'] = 1;
					$organisation = $this->admin;
					$organisation_id = $organisation['organisation_id'];
					$udata['organisation_id'] = $organisation_id;
					$udata['last_update_id'] = 1;
					$this->mproduct->insert('product_meta_images',$udata);
				}*/
			}
		}
		
		$condition = array("product_meta_id"=>$product_meta_id);
		$response['cms']=$this->mproduct->getDetails('product_meta_images',$condition);
		echo json_encode($response);
	}
	
	
	
	public function save_product_meta_image_gallery()
	{
		$product_meta_id = $this->input->post('product_meta_id');
		$total = count($_FILES['files']['name']);
				// Loop through each file
		for( $i=0 ; $i < $total ; $i++ ) {

			//Get the temp file path
			$tmpFilePath = $_FILES['files']['tmp_name'][$i];
			
			$filename = $_FILES['files']['name'][$i];
			$filedata = $_FILES['files']['tmp_name'][$i];
			$filesize = $_FILES['files']['size'][$i];
			$type = $_FILES['files']['type'][$i];

			//Make sure we have a file path
			if ($tmpFilePath != ""){
				//Setup our new file path
				$newFilePath = "./public/admin_assets/images/content/" . $_FILES['files']['name'][$i];
				
				
				$url = 'http://ec2-3-19-228-138.us-east-2.compute.amazonaws.com/flaskapp/aws_portal_upload/awsResourceUploadController/uploadToS3Bucket/28';
				$make_call = $this->callAPIUpload($url,$filedata,$type,$filename);
				
				if($type == 'video/mp4'){
					$udata['image_type'] = 2;
				}else{
					$udata['image_type'] = 1;
				}
				
				$response = json_decode($make_call, true);
				
				if(!empty($response['responseList'][0]['FilePath'])){
					$udata['product_meta_id'] = $product_meta_id;
					$udata['image'] = $response['responseList'][0]['FilePath'];
					$udata['status'] = 1;
					$organisation = $this->admin;
					$organisation_id = $organisation['organisation_id'];
					$udata['organisation_id'] = $organisation_id;
					$udata['last_update_id'] = $organisation_id;
					$udata['is_gallery'] = 1;					
					
					$url_add_product_images = $this->base_url."AddProductImagesGallery";
					$make_call_product_images = $this->callAPI('POST', $url_add_product_images,json_encode($udata));
					$response = json_decode($make_call_product_images, true);
				}
					//Upload the file into the temp dir
				/*if(move_uploaded_file($tmpFilePath, $newFilePath)) {
					$udata['product_meta_id'] = $product_meta_id;
					$udata['image'] = base_url()."public/admin_assets/images/content/".$_FILES['files']['name'][$i];
					$udata['default_image_flag'] = 0;
					$udata['status'] = 1;
					$organisation = $this->admin;
					$organisation_id = $organisation['organisation_id'];
					$udata['organisation_id'] = $organisation_id;
					$udata['last_update_id'] = 1;
					$this->mproduct->insert('product_meta_images',$udata);
				}*/
			}
		}
		
		$url = $this->base_url."getProductMetaImagesForGallery/".$product_meta_id;
		$make_call = $this->callAPI('GET', $url,$data);
		$image_decode = json_decode($make_call, true);
		$response['cms'] = $image_decode['responseList']['product_image'];
		echo json_encode($response);
	}
	
	public function remove_product_meta_image()
	{
		$product_image_id = $this->input->post('product_image_id');
		$product_meta_id = $this->input->post('product_meta_id');
		$url = $this->base_url."deleteProductMetaImage/".$product_image_id;
		$data = array();
		$make_call = $this->callAPI('DELETE', $url,json_encode($data));		
		$condition = array("product_meta_id"=>$product_meta_id);
		$response['cms']=$this->mproduct->getDetails('product_meta_images',$condition);
		echo json_encode($response);
	}	
	
	public function remove_product_meta_image_gallery()
	{
		$product_image_id = $this->input->post('product_image_id');
		$product_meta_id = $this->input->post('product_meta_id');
		$url = $this->base_url."deleteProductMetaImage/".$product_image_id;
		$data = array();
		$make_call = $this->callAPI('DELETE', $url,json_encode($data));
		$url = $this->base_url."getProductMetaImagesForGallery/".$product_meta_id;
		$make_call = $this->callAPI('GET', $url,$data);
		$image_decode = json_decode($make_call, true);
		$response['cms'] = $image_decode['responseList']['product_image'];
		echo json_encode($response);
	}
	
	public function product_meta_default_image()
	{
		$product_image_id = $this->input->post('product_image_id');
		$product_meta_id = $this->input->post('product_meta_id');
		$url = $this->base_url."productMetaDefaultImage/".$product_image_id."/".$product_meta_id;
		$data = array();
		$make_call = $this->callAPI('PUT', $url,json_encode($data));		
		$condition = array("product_meta_id"=>$product_meta_id);
		$response['cms']=$this->mproduct->getDetails('product_meta_images',$condition);
		echo json_encode($response);
	}
		
	
	public function add_product_Image(){
		$this->_load_add_image_view();
	}
	
	public function get_retailerlist_with_stock(){
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$product_meta_id = $this->input->post('product_meta_id');
		$url = $this->base_url."getRetailerListWithStock/".$organisation_id."/".$product_meta_id;
		$data = array();
		$make_call = $this->callAPI('GET', $url,json_encode($data));
		$response = json_decode($make_call, true);
		echo json_encode($response);
	}
	
	public function update_stock(){
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$retailer_store_id = $this->input->post('retailer_store_id');
		$stock = $this->input->post('stock');
		$url = $this->base_url."updateStock";
		$data['organisation_id'] = $organisation_id;
		$data['retailer_store_id'] = $retailer_store_id;
		$data['stock'] = (int)$stock;
		$data['last_update_id'] = 1;
		$data['product_meta_id'] = $this->input->post('product_meta_id');
		$make_call = $this->callAPI('PUT', $url,json_encode($data));
		$response = json_decode($make_call, true);
		//print_r($response);exit;
		echo json_encode($response);
	}
	
	private function _load_add_image_view(){		
		$data['content']='admin/product/add_image';
		$this->load->view('admin/layouts/index',$data);
	}
	
	public function callAPI($method, $url, $data){
	   $curl = curl_init();
	   switch ($method){
		  case "POST":
			 curl_setopt($curl, CURLOPT_POST, 1);
			 curl_setopt($curl,CURLOPT_SSL_VERIFYPEER, false);
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
			 break;
		  case "PUT":
			 curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);			 					
			 break;
		  case "DELETE":
			 curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "DELETE");
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);			 					
			 break;
		  default:
			 if ($data)
				$url = sprintf("%s?%s", $url, http_build_query($data));
	   }
	   // OPTIONS:
	   curl_setopt($curl, CURLOPT_URL, $url);
	   curl_setopt($curl, CURLOPT_HTTPHEADER,array(
		'Content-Type: application/json',
		));
	   curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
	   curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
	   // EXECUTE:
	   $result = curl_exec($curl);
	   if(!$result){die("Connection Failure");}
	   curl_close($curl);
	   return $result;
	}
	
	public function callAPIUpload($url, $filedata, $type,$filename){
	  $fields = [
			'file' => new \CurlFile(realpath($filedata), $type, $filename)
		];
		
			// Generated by curl-to-PHP: http://incarnate.github.io/curl-to-php/
		$ch = curl_init();
		
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_URL, $url);
		
		curl_setopt($ch, CURLOPT_HTTPHEADER,array(
			'Accept: application/json',
			'Content-Type: multipart/form-data'
		));
		
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);			
		
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		
		

		$result = curl_exec($ch);
		//$info = curl_getinfo($ch);
		//print_r($info['request_header']);exit;
		if(!$result){die("Connection Failure");}
		curl_close($curl);
		
		return $result;
	}
}