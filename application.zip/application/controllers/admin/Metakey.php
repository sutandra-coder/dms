<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Metakey extends MY_Controller {
	public function __construct() {
		parent::__construct();
		$this->redirect_guest();
		$this->admin=$this->session->userdata('admin');		
		$this->base_url = "http://ec2-18-221-89-14.us-east-2.compute.amazonaws.com/flaskapp/ecommerce_product/EcommerceProduct/";
	}
		
	public function index() { 
		$this->_load_list_view();		
	}
	
	private function _load_list_view() {
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$url = $this->base_url."getMetaKeyList/".$organisation_id;
		$data = array();
		$make_call = $this->callAPI('GET', $url,$data);
		$response = json_decode($make_call, true);
		$list = $response['responseList'];
		
		$data = array(
			"status"	=> false,
			"message"  	=> "",
			"post_data"	=>	$list
		);
		$data['admin'] = $this->admin;
		$data['content'] = 'admin/metakey/list';
		$this->load->view('admin/layouts/index', $data);
	}
	
	public function add(){
		$this->_load_add_view();
	}
	
	private function _load_add_view(){		
		$data['content']='admin/metakey/add';
		$this->load->view('admin/layouts/index',$data);
	}
	
	public function add_content()
	{
		if($this->input->post()){
			$this->form_validation->set_rules('meta_key','Tag','required');
			
			if($this->form_validation->run()==FALSE){			
				$this->_load_add_view();
			}else{
				$admin = $this->admin;
				$url = $this->base_url."AddMetaKey";				
				$organisation = $this->admin;
				$organisation_id = $organisation['organisation_id'];
				$udata['organisation_id'] = $organisation_id;
				$udata['last_update_id'] = $organisation_id;
				$udata['meta_key']=$this->input->post('meta_key');
				$make_call = $this->callAPI('POST', $url,json_encode($udata));
				$response = json_decode($make_call, true);
				if($response['attributes']['status'] == 'error')
				{
					$this->session->set_flashdata('error_msg',$response['responseList']);
				}else{
					$this->session->set_flashdata('success_msg','Tag Saved successfully');
				}
				redirect('admin/metakey');
			}
		}else{
			$this->_load_list_view();
		}
		
	}
	
	public function all_content_list(){	
		
		$new_list = array();	
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$url = $this->base_url."getMetaKeyList/".$organisation_id;
		$data = array();
		$make_call = $this->callAPI('GET', $url,$data);
		$response = json_decode($make_call, true);
		$list = $response['responseList'];
		$no = $_POST['start'];
		$i=1;
		
		if(isset($_POST['search']['value']) && !empty($_POST['search']['value']))
		{
			
			foreach($list as $key=>$person)
			{
				if($_POST['search']['value'] == $person['meta_key'])
				{
					$new_list[$key] = $person;
				}
			}
			
		}else{
			$new_list = $list;
		}
		
		foreach ($new_list as $person) {
			$row = array();	
			$row[]=$i;
			$row[] = $person['meta_key'];
			$row[] = '<a href="'.base_url('admin/metakey/details/'.$person['meta_key_id']).'" title="Edit" class="btn btn-info"><span class="glyphicon glyphicon-pencil"></span></a>';
			$row[] = ($person['status']==1?'<a class="cstm_view_status btn btn-success" id="active" href="javascript:void(0)" title="'.$person['meta_key_id'].'"><span class="glyphicon glyphicon-ok"></span></a>':'<a class="cstm_view_status btn btn-danger" id="inactive" href="javascript:void(0)" title="'.$person['meta_key_id'].'"><span class="glyphicon glyphicon-remove"></span></a>');
			$data[] = $row;
			$i++;
		}
		
		$output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" =>count($new_list),
                        "recordsFiltered" => count($new_list),
                        "data" => $data,
                );
        echo json_encode($output);
	}
	
	public function edit($meta_key_id)
	{
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$url = $this->base_url."getMetaKeyDetails/".$organisation_id."/".$meta_key_id;
		$data = array();
		$make_call = $this->callAPI('GET', $url,$data);
		$response = json_decode($make_call, true);
		$data['cms'] = $response['responseList'];		
		if(empty($data['cms'])){
			$this->_load_list_view();
		}else{			
			$this->_load_details_view($data);
		}
	}
	
	public function _load_details_view($parms)
	{
		$data['cms']=$parms['cms'];	
		$data['content'] = 'admin/metakey/detail';
		$this->load->view('admin/layouts/index', $data);
	}
	
	public function update()
	{
		if($this->input->post()){
			$meta_key_id = $this->input->post('meta_key_id');
			$this->form_validation->set_rules('meta_key','Tag','required');
			
			if($this->form_validation->run()==FALSE){
				$organisation_id = 1;
				$url = $this->base_url."getMetaKeyDetails/".$organisation_id."/".$meta_key_id;
				$data = array();
				$make_call = $this->callAPI('GET', $url,$data);
				$response = json_decode($make_call, true);
				$data['cms'] = $response['responseList'];
				$this->_load_details_view($data);
			}else{
				$udata['meta_key'] = $this->input->post('meta_key');
				$organisation = $this->admin;
				$organisation_id = $organisation['organisation_id'];
				$udata['organisation_id'] = $organisation_id;
				$udata['last_update_id'] = $organisation_id;
				$url = $this->base_url."UpdateMetaKey/".$meta_key_id;
				$make_call = $this->callAPI('PUT', $url,json_encode($udata));
				$response = json_decode($make_call, true);
				
				if($response['attributes']['status'] == 'error')
				{
					$this->session->set_flashdata('error_msg',$response['responseList']);
				}else{
					$this->session->set_flashdata('success_msg',$response['responseList']);
				}
				redirect('admin/metakey');
			}
		}else{
			$this->_load_list_view();
		}
	}
	
	public function active()
	{
		$meta_key_id=$this->input->post('meta_key_id');
		$udata['meta_key_status'] = 1;
		$url = $this->base_url."UpdateMetaKeyStatus/".$meta_key_id;
		$make_call = $this->callAPI('PUT', $url,json_encode($udata));
		$response = json_decode($make_call, true);
		if($response['attributes']['status'] == 'success')
		{
			$response=array('status'=>1,'message'=>'Success');
		}else{
			$response=array('status'=>0,'message'=>'Error');
		}
		echo json_encode($response);
	}
	
	public function inactive()
	{
		$meta_key_id=$this->input->post('meta_key_id');
		$udata['meta_key_status'] = 0;
		$url = $this->base_url."UpdateMetaKeyStatus/".$meta_key_id;
		$make_call = $this->callAPI('PUT', $url,json_encode($udata));
		$response = json_decode($make_call, true);
		if($response['attributes']['status'] == 'success')
		{
			$response=array('status'=>1,'message'=>'Success');
		}else{
			$response=array('status'=>0,'message'=>'Error');
		}
		echo json_encode($response);
	}
	
	public function callAPI($method, $url, $data){
	   $curl = curl_init();
	   switch ($method){
		  case "POST":
			 curl_setopt($curl, CURLOPT_POST, 1);
			 curl_setopt($curl,CURLOPT_SSL_VERIFYPEER, false);
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
			 break;
		  case "PUT":
			 curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);			 					
			 break;
		  default:
			 if ($data)
				$url = sprintf("%s?%s", $url, http_build_query($data));
	   }
	   // OPTIONS:
	   curl_setopt($curl, CURLOPT_URL, $url);
	   curl_setopt($curl, CURLOPT_HTTPHEADER,array(
		'Content-Type: application/json',
		));
	   curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
	   curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
	   // EXECUTE:
	   $result = curl_exec($curl);
	   if(!$result){die("Connection Failure");}
	   curl_close($curl);
	   return $result;
	}
}