<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Campaign extends MY_Controller {
	public function __construct() {
		parent::__construct();
		$this->redirect_guest();
		$this->admin=$this->session->userdata('admin');
		$this->base_url = "http://ec2-18-221-89-14.us-east-2.compute.amazonaws.com/flaskapp/ecommerce_campaign/EcommerceCampaign/";
	}
	
	public function index() { 
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$url = $this->base_url."getCampaignList/".$organisation_id;
		$this->_load_list_view($url);		
	}
	
	private function _load_list_view($url) {
		$data = array();
		$make_call = $this->callAPI('GET', $url,$data);
		$response = json_decode($make_call, true);
		$list = $response['responseList'];
		
		$data = array(
			"status"	=> false,
			"message"  	=> "",
			"post_data"	=>	$list
		);
		
		$data['content'] = 'admin/campaign/list';
		$this->load->view('admin/layouts/index', $data);
	}
	
	public function add(){
		$this->_load_add_view();
	}
	
	private function _load_add_view(){		
		$data['content']='admin/campaign/add';
		$this->load->view('admin/layouts/index',$data);
	}
	
	public function add_content()
	{
		if($this->input->post()){
			$this->form_validation->set_rules('campaign_name','Campaign Name','required');
			
			if($this->form_validation->run()==FALSE){			
				$this->_load_add_view();
			}else{
				$organisation = $this->admin;
				$organisation_id = $organisation['organisation_id'];				
				$udata['campaign_name'] = $this->input->post('campaign_name');
				$udata['organisation_id'] = $organisation_id;				
				$udata['last_update_id'] = 1;
				$sms_check = $this->input->post('sms_check');	
				if($sms_check == 1)
				{
					$udata['sms_content'] = $this->input->post('sms_content');
				}else{
					$udata['sms_content'] = "";
				}
				$email_check = $this->input->post('email_check');
				if($email_check == 1)
				{
					$udata['email_content'] = $this->input->post('email_content');
					if(is_uploaded_file($_FILES['imgInpemail']['tmp_name']))
					{
						$email_image=$this->email_image_upload();
						if($email_image['status']==1){
							$udata['email_image']=base_url()."public/admin_assets/images/campaign/".$email_image['result'];
						}
					}else{
						$udata['email_image'] = "";
					}
				}else{
					$udata['email_image'] = "";
					$udata['email_content'] = "";
				}
				$push_check = $this->input->post('push_check');
				if($push_check == 1)
				{
					$udata['app_content'] = $this->input->post('appnotification_content');
					if(is_uploaded_file($_FILES['imgInpapp']['tmp_name']))
					{
						$app_image=$this->app_notification_image_upload();
						if($app_image['status']==1){
							$udata['app_image']=base_url()."public/admin_assets/images/campaign/".$app_image['result'];
						}
					}else{
						$udata['app_image'] = "";
					}
				}else{
					$udata['app_content'] = "";
					$udata['app_image'] = "";
				}
				
				$url = $this->base_url."AddCampaign";				
				$make_call = $this->callAPI('POST', $url,json_encode($udata));
				$response = json_decode($make_call, true);
				
				if($response['attributes']['status'] == 'error')
				{
					$this->session->set_flashdata('error_msg',$response['responseList']);
				}else{
					$this->session->set_flashdata('success_msg','Campaign Saved successfully');
				}
				redirect('admin/campaign');
			}
		}else{
			$organisation = $this->admin;
			$organisation_id = $organisation['organisation_id'];
			$url = $this->base_url."getCampaignList/".$organisation_id;
			$this->_load_list_view($url);
		}
		
	}
	
	public function edit($campaign_id)
	{	
		$url = $this->base_url."getCampaignDetails/".$campaign_id;
		$data = array();
		$make_call = $this->callAPI('GET', $url,$data);
		$response = json_decode($make_call, true);
		$data['cms'] = $response['responseList'];
		if(empty($data['cms'])){
			$organisation = $this->admin;
			$organisation_id = $organisation['organisation_id'];
			$url = $this->base_url."getCampaignList/".$organisation_id;
			$this->_load_list_view($url);
		}else{			
			$this->_load_details_view($data);
		}
	}
	
	public function _load_details_view($parms)
	{
		$data['cms']=$parms['cms'];	
		$data['content'] = 'admin/campaign/detail';
		$this->load->view('admin/layouts/index', $data);
	}
	
	public function update()
	{
		if($this->input->post()){
			$campaign_id = $this->input->post('campaign_id');
			$this->form_validation->set_rules('campaign_name','Campaign Name','required');
			
			if($this->form_validation->run()==FALSE){
				$url = $this->base_url."getCampaignDetails/".$campaign_id;
				$data = array();
				$make_call = $this->callAPI('GET', $url,$data);
				$response = json_decode($make_call, true);
				$data['cms'] = $response['responseList'];
				$this->_load_details_view($data);
			}else{
					$organisation = $this->admin;
					$organisation_id = $organisation['organisation_id'];				
					$udata['campaign_name'] = $this->input->post('campaign_name');
					//$udata['organisation_id'] = $organisation_id;				
					//$udata['last_update_id'] = 1;
					$sms_check = $this->input->post('sms_check');	
					if($sms_check == 1)
					{
						$udata['sms_content'] = $this->input->post('sms_content');
					}else{
						$udata['sms_content'] = "";
					}
					$email_check = $this->input->post('email_check');
					if($email_check == 1)
					{
						$udata['email_content'] = $this->input->post('email_content');
						if(is_uploaded_file($_FILES['imgInpemail']['tmp_name']))
						{
							$email_image=$this->email_image_upload();
							if($email_image['status']==1){
								$udata['email_image']=base_url()."public/admin_assets/images/campaign/".$email_image['result'];
							}
						}
					}else{
						$udata['email_image'] = "";
						$udata['email_content'] = "";
					}
					$push_check = $this->input->post('push_check');
					if($push_check == 1)
					{
						$udata['app_content'] = $this->input->post('appnotification_content');
						if(is_uploaded_file($_FILES['imgInpapp']['tmp_name']))
						{
							$app_image=$this->app_notification_image_upload();
							if($app_image['status']==1){
								$udata['app_image']=base_url()."public/admin_assets/images/campaign/".$app_image['result'];
							}
						}
					}else{
						$udata['app_content'] = "";
						$udata['app_image'] = "";
					}		
					
					//echo json_encode($udata);exit;
					$url = $this->base_url."UpdateCampaign/".$campaign_id;
					$make_call = $this->callAPI('PUT', $url,json_encode($udata));
					$response = json_decode($make_call, true);
					if($response['attributes']['status'] == 'error')
					{
						$this->session->set_flashdata('error_msg',$response['responseList']);
					}else{
						$this->session->set_flashdata('success_msg',$response['responseList']);
					}
					redirect('admin/campaign');
			}
		}else{
			$organisation = $this->admin;
			$organisation_id = $organisation['organisation_id'];
			$url = $this->base_url."getCampaignList/".$organisation_id;
			$this->_load_list_view($url);
		}
	}
	
	private function email_image_upload(){
		$img='imgInpemail';
		$config['upload_path'] = './public/admin_assets/images/campaign';
		$config['allowed_types'] = 'gif|jpg|png';		
		$config['encrypt_name']  = true;
		$this->load->library('upload', $config);
		if ( ! $this->upload->do_upload($img)){
			$message = array('result' => $this->upload->display_errors(),'status'=>0);
		}else{ 
			$data = array('upload_data' => $this->upload->data());
			$message = array('result' => $data['upload_data']['file_name'],'status'=>1);
		}
		return $message;
	}
	
	private function app_notification_image_upload(){
		$img='imgInpapp';
		$config['upload_path'] = './public/admin_assets/images/campaign';
		$config['allowed_types'] = 'gif|jpg|png';		
		$config['encrypt_name']  = true;
		$this->load->library('upload', $config);
		if ( ! $this->upload->do_upload($img)){
			$message = array('result' => $this->upload->display_errors(),'status'=>0);
		}else{ 
			$data = array('upload_data' => $this->upload->data());
			$message = array('result' => $data['upload_data']['file_name'],'status'=>1);
		}
		return $message;
	}
	
	public function callAPI($method, $url, $data){
	   $curl = curl_init();
	   switch ($method){
		  case "POST":
			 curl_setopt($curl, CURLOPT_POST, 1);
			 curl_setopt($curl,CURLOPT_SSL_VERIFYPEER, false);
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
			 break;
		  case "PUT":
			 curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);			 					
			 break;
		  case "DELETE":
			 curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "DELETE");
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);			 					
			 break;
		  default:
			 if ($data)
				$url = sprintf("%s?%s", $url, http_build_query($data));
	   }
	   // OPTIONS:
	   curl_setopt($curl, CURLOPT_URL, $url);
	   curl_setopt($curl, CURLOPT_HTTPHEADER,array(
		'Content-Type: application/json',
		));
	   curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
	   curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
	   // EXECUTE:
	   $result = curl_exec($curl);
	   if(!$result){die("Connection Failure");}
	   curl_close($curl);
	   return $result;
	}
}