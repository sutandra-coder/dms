<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Audience extends MY_Controller {
	public function __construct() {
		parent::__construct();
		$this->redirect_guest();
		$this->admin=$this->session->userdata('admin');
		$this->base_url = "http://ec2-18-221-89-14.us-east-2.compute.amazonaws.com/flaskapp/ecommerce_campaign/EcommerceCampaign/";
	}
	
	public function index() { 
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$url = $this->base_url."getAudienceList/".$organisation_id;
		$this->_load_list_view($url);		
	}
	
	private function _load_list_view($url) {
		$data = array();
		$make_call = $this->callAPI('GET', $url,$data);
		$response = json_decode($make_call, true);
		$list = $response['responseList'];	
		
		$data = array(
			"status"	=> false,
			"message"  	=> "",
			"post_data"	=>	$list
		);
		$data['content'] = 'admin/audience/list';
		$this->load->view('admin/layouts/index', $data);
	}
	
	public function add(){
		$this->_load_add_view();
	}
	
	private function _load_add_view(){
		$data = array();
		$brand_list_url = "http://ec2-18-221-89-14.us-east-2.compute.amazonaws.com/flaskapp/ecommerce_product/EcommerceProduct/getMetaKeyValueListMetaId/2/1";
		$brand_list_make_call = $this->callAPI('GET', $brand_list_url,$data);
		$brand_response = json_decode($brand_list_make_call, true);
		$brand_list = $brand_response['responseList'];
		
		$retailer_list_url = "http://ec2-18-221-89-14.us-east-2.compute.amazonaws.com/flaskapp/ecommerce_customer/EcommerceCustomer/getLocation";
		$retailer_list_make_call = $this->callAPI('GET', $retailer_list_url,$data);
		$retailer_response = json_decode($retailer_list_make_call, true);
		$retailer_list = $retailer_response['responseList'];
		
		$data['brand_list'] = $brand_list;
		$data['retailer_list'] = $retailer_list;
		
		$data['content']='admin/audience/add';
		$this->load->view('admin/layouts/index',$data);
	}
	
	public function add_content()
	{
		if($this->input->post()){
			$this->form_validation->set_rules('audience_name','Audience Name','required');
			
			if($this->form_validation->run()==FALSE){			
				$this->_load_add_view();
			}else{
				$organisation = $this->admin;
				$organisation_id = $organisation['organisation_id'];				
				$udata['audience_name'] = $this->input->post('audience_name');
				$udata['organisation_id'] = $organisation_id;				
				$udata['last_update_id'] = 1;
				$user_value_check = $this->input->post('user_value_check');
				if($user_value_check == 1)
				{
					$udata['audience_user_gretter_value'] = $this->input->post('gretter_value');
					$udata['audience_user_less_value'] = $this->input->post('less_value');					
				}else{
					$udata['audience_user_gretter_value'] = "";
					$udata['audience_user_less_value'] = "";
				}
				
				$user_brand_check = $this->input->post('user_brand_check');
				if($user_brand_check == 1)
				{
					$udata['audience_user_brand_id'] = $this->input->post('audience_user_brand_id');
				}else{
					$udata['audience_user_brand_id'] = "";
				}
				
				$user_retailer_check = $this->input->post('user_retailer_check');
				if($user_retailer_check == 1)
				{
					$udata['audience_user_retailer_id'] = $this->input->post('audience_user_retailer_id');
				}else{
					$udata['audience_user_retailer_id'] = "";
				}
				
				$user_last_purchase_date_check = $this->input->post('user_last_purchase_date_check');
				
				if($user_last_purchase_date_check == 1)
				{
					$udata['audience_last_purchase_date'] = $this->input->post('audience_last_purchase_date');
				}else{
					$udata['audience_last_purchase_date'] = "";
				}
				
				$url = $this->base_url."AddAudience";				
				$make_call = $this->callAPI('POST', $url,json_encode($udata));
				$response = json_decode($make_call, true);
				
				if($response['attributes']['status'] == 'error')
				{
					$this->session->set_flashdata('error_msg',$response['responseList']);
				}else{
					$this->session->set_flashdata('success_msg','Audience Saved successfully');
				}
				redirect('admin/audience');
			}
		}else{
			$organisation = $this->admin;
			$organisation_id = $organisation['organisation_id'];
			$url = $this->base_url."getAudienceList/".$organisation_id;
			$this->_load_list_view($url);
		}
	}
	
	public function edit($audience_id)
	{	
		$url = $this->base_url."getAudienceDetails/".$audience_id;
		$data = array();
		$make_call = $this->callAPI('GET', $url,$data);
		$response = json_decode($make_call, true);
		$data['cms'] = $response['responseList'];
		if(empty($data['cms'])){
			$organisation = $this->admin;
			$organisation_id = $organisation['organisation_id'];
			$url = $this->base_url."getAudienceList/".$organisation_id;
			$this->_load_list_view($url);			
		}else{			
			$this->_load_details_view($data);
		}
	}
	public function _load_details_view($parms)
	{
		$data = array();
		$brand_list_url = "http://ec2-18-221-89-14.us-east-2.compute.amazonaws.com/flaskapp/ecommerce_product/EcommerceProduct/getMetaKeyValueListMetaId/2/1";
		$brand_list_make_call = $this->callAPI('GET', $brand_list_url,$data);
		$brand_response = json_decode($brand_list_make_call, true);
		$brand_list = $brand_response['responseList'];
		
		$retailer_list_url = "http://ec2-18-221-89-14.us-east-2.compute.amazonaws.com/flaskapp/ecommerce_customer/EcommerceCustomer/getLocation";
		$retailer_list_make_call = $this->callAPI('GET', $retailer_list_url,$data);
		$retailer_response = json_decode($retailer_list_make_call, true);
		$retailer_list = $retailer_response['responseList'];
		
		$data['brand_list'] = $brand_list;
		$data['retailer_list'] = $retailer_list;
		
		$data['cms']=$parms['cms'];	
		$data['content'] = 'admin/audience/detail';
		$this->load->view('admin/layouts/index', $data);
	}
	
	public function update()
	{
		if($this->input->post()){
			$this->form_validation->set_rules('audience_name','Audience Name','required');
			
			if($this->form_validation->run()==FALSE){			
				$this->_load_add_view();
			}else{
				$audience_id = $this->input->post('audience_id');
				$organisation = $this->admin;
				$organisation_id = $organisation['organisation_id'];				
				$udata['audience_name'] = $this->input->post('audience_name');
				$udata['organisation_id'] = $organisation_id;				
				$udata['last_update_id'] = 1;
				$user_value_check = $this->input->post('user_value_check');
				if($user_value_check == 1)
				{
					$udata['audience_user_gretter_value'] = $this->input->post('gretter_value');
					$udata['audience_user_less_value'] = $this->input->post('less_value');					
				}else{
					$udata['audience_user_gretter_value'] = "";
					$udata['audience_user_less_value'] = "";
				}
				
				$user_brand_check = $this->input->post('user_brand_check');
				if($user_brand_check == 1)
				{
					$udata['audience_user_brand_id'] = $this->input->post('audience_user_brand_id');
				}else{
					$udata['audience_user_brand_id'] = "";
				}
				
				$user_retailer_check = $this->input->post('user_retailer_check');
				if($user_retailer_check == 1)
				{
					$udata['audience_user_retailer_id'] = $this->input->post('audience_user_retailer_id');
				}else{
					$udata['audience_user_retailer_id'] = "";
				}
				
				$user_last_purchase_date_check = $this->input->post('user_last_purchase_date_check');
				
				if($user_last_purchase_date_check == 1)
				{
					$udata['audience_last_purchase_date'] = $this->input->post('audience_last_purchase_date');
				}else{
					$udata['audience_last_purchase_date'] = "";
				}				
				
				$url = $this->base_url."UpdateAudience/".$audience_id;				
				$make_call = $this->callAPI('PUT', $url,json_encode($udata));
				$response = json_decode($make_call, true);
				
				if($response['attributes']['status'] == 'error')
				{
					$this->session->set_flashdata('error_msg',$response['responseList']);
				}else{
					$this->session->set_flashdata('success_msg',$response['responseList']);
				}
				redirect('admin/audience');
			}
		}else{
			$organisation = $this->admin;
			$organisation_id = $organisation['organisation_id'];
			$url = $this->base_url."getAudienceList/".$organisation_id;
			$this->_load_list_view($url);
		}
	}
	
	public function customer_list($audience_id)
	{
		$udata = array();
		$organisation = $this->admin;	
		$organisation_id = $organisation['organisation_id'];	
		$url = $this->base_url."getAudienceDetails/".$audience_id;		
		$make_call = $this->callAPI('GET', $url,$udata);
		$response = json_decode($make_call, true);
		$less_value = $response['responseList']['less_value'];
		$gretter_value = $response['responseList']['gretter_value'];
		$last_purchase_date = $response['responseList']['last_purchase_date'];
		$brand_id = $response['responseList']['brand_id'];
		$retailer_id = $response['responseList']['retailer_id'];		
		$customer_list_response = array();
		if(!empty($less_value) && !empty($gretter_value) && !empty($last_purchase_date) && !empty($brand_id) && !empty($retailer_id))
		{			
			$customer_list_url = $this->base_url."orderHistoryFull/".$brand_id."/".$gretter_value."/".$less_value."/".$organisation_id."/".$retailer_id."/".$last_purchase_date;
		}else{			
			if(empty($less_value) && empty($gretter_value) && empty($last_purchase_date) && empty($brand_id))
			{
				$customer_list_url = $this->base_url."orderHistorywithretailerId/".$organisation_id."/".$retailer_id;				
			}else{
				if(empty($less_value) && empty($gretter_value) && empty($last_purchase_date) && empty($retailer_id))
				{
					$customer_list_url = $this->base_url."orderHistorywithbrandId/".$organisation_id."/".$brand_id;
				}else{
					if(empty($last_purchase_date) && empty($retailer_id) && empty($brand_id))
					{
						$customer_list_url = $this->base_url."orderHistoryWithValueRange/".$gretter_value."/".$less_value."/".$organisation_id;
					}
				}
			}
		}	
		//echo $customer_list_url;exit;
		$make_call_customer_list = $this->callAPI('GET', $customer_list_url,$udata);
		$customer_list_response = json_decode($make_call_customer_list, true);	
		
		$list = $customer_list_response['responseList'];			
		
		$data = array(
			"status"	=> false,
			"message"  	=> "",
			"post_data"	=>	$list
		);
		
		$organisation_id = $organisation['organisation_id'];
		$campaign_url = $this->base_url."getCampaignList/".$organisation_id;
		$make_campaign_call = $this->callAPI('GET', $campaign_url,$udata);
		$response_campaign = json_decode($make_campaign_call, true);
		$data['campaign_list'] = $response_campaign['responseList'];
		
		$data['content'] = 'admin/audience/customer_list';
		$this->load->view('admin/layouts/index', $data);
		
	}
	
	public function run_campaign()
	{
		$customer_ids = $this->input->post('customer_ids');
		$explode_customer_ids = explode(",",$customer_ids);
		$campaign_id = $this->input->post('campaign_id');
		
		$url = $this->base_url."getCampaignDetails/".$campaign_id;
		$data = array();
		$make_call = $this->callAPI('GET', $url,$data);
		$response = json_decode($make_call, true);
		
		foreach($explode_customer_ids as $customer_id)
		{
			$customerDetailsUrl = "http://ec2-18-221-89-14.us-east-2.compute.amazonaws.com/flaskapp/ecommerce_customer/EcommerceCustomer/customerDetails/".$customer_id;
			$customerDetailsData = array();
			$customerDetailsMakeCall = $this->callAPI('GET', $customerDetailsUrl,$customerDetailsData);
			$responseCustomerDetails = json_decode($customerDetailsMakeCall, true);	
			if(!empty($response['responseList']['email_content']))
			{
				$email = $responseCustomerDetails['responseList']['email'];
				$mail_temp = $response['responseList']['email_content'];
				$data['to'] = $email;
				$data['subject'] = "test";
				$mail_temp = "
						 <html>
						   <head>
							 <title></title>
						   </head>
						   <body>
							 <p>".$response['responseList']['email_content']."</p>
							 <p><img src='".$response['responseList']['email_image']."'></p>
						   </body>
						 </html>";
				$data['message']=$mail_temp;
				$this->sendMail($data);	
			}
			$device_token = $responseCustomerDetails['responseList']['device_token'];
			if(!empty($response['responseList']['app_content']) && !empty($response['responseList']['app_image']))
			{
				$push['image-url'] =  $response['responseList']['app_image'];
				$push['title'] = $response['responseList']['campaign_name'];
				$push['message'] =  $response['responseList']['app_content'];
				$this->send_android_notification($device_token,$push);
			}
		}
		
		$result['attributes']['status'] = "success";
		echo json_encode($result);
		
	}
	
	public function send_android_notification($registration_ids, $data) {
		$fields = array(
		'registration_ids' => array($registration_ids),
		'data'=> $data,
		);
		$headers = array(
		'Authorization: key=AAAATLVsDiA:APA91bFYEaJWn4PT09fp53An-H2Gmsn9kojQpX6V9Y8ol0Rj6qhH_j_Uos6Gua1kGMcuO5YsxNgbwp3HDZlE9fUNiUsM9ePEghWGaMDCXWXDiURHlHZnkDEvIvGvfYTrCecioM0Nx9hX', // FIREBASE_API_KEY_FOR_ANDROID_NOTIFICATION
		'Content-Type: application/json'
		);
		// Open connection
		$ch = curl_init();
		 
		// Set the url, number of POST vars, POST data
		curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
		curl_setopt( $ch,CURLOPT_POST, true );
		curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
		curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
		 
		// Disabling SSL Certificate support temporarly
		curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
		curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
		 
		// Execute post
		$result = curl_exec($ch );
		if($result === false){
		//die('Curl failed:' .curl_errno($ch));
			return 0;
		}
		 
		// Close connection
		curl_close( $ch );
		return $result;
	}
	
	private function sendMail($data){
		$config['protocol']    	= 'smtp';
        $config['smtp_host']     = 'mail.creamsonservices.com';
        $config['smtp_port']     = '587';  
        $config['smtp_user']     = 'communications@creamsonservices.com';
        $config['smtp_pass']     = 'CReam7789%$intELLi';
        $config['charset']    	= 'utf-8';
        $config['newline']    	= "\r\n";
        $config['mailtype'] 	= 'html';
        $config['validation'] 	= TRUE;   

        $this->email->initialize($config);

        $this->email->set_crlf( "\r\n" );

        $this->email->from('communications@creamsonservices.com', 'communications');
        $this->email->to($data['to']); 

        $this->email->subject($data['subject']);
        $this->email->message($data['message']);  

        $this->email->send();
		return true;   	
    } 
	
	public function callAPI($method, $url, $data){
	   $curl = curl_init();
	   switch ($method){
		  case "POST":
			 curl_setopt($curl, CURLOPT_POST, 1);
			 curl_setopt($curl,CURLOPT_SSL_VERIFYPEER, false);
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
			 break;
		  case "PUT":
			 curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);			 					
			 break;
		  case "DELETE":
			 curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "DELETE");
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);			 					
			 break;
		  default:
			 if ($data)
				$url = sprintf("%s?%s", $url, http_build_query($data));
	   }
	   // OPTIONS:
	   curl_setopt($curl, CURLOPT_URL, $url);
	   curl_setopt($curl, CURLOPT_HTTPHEADER,array(
		'Content-Type: application/json',
		));
	   curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
	   curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
	   // EXECUTE:
	   $result = curl_exec($curl);
	   if(!$result){die("Connection Failure");}
	   curl_close($curl);
	   return $result;
	}
}