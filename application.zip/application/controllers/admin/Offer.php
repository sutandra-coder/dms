<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Offer extends MY_Controller {
	public function __construct() {
		parent::__construct();
		$this->redirect_guest();
		$this->admin=$this->session->userdata('admin');
		$this->load->model('admin/moffer');
		$this->base_url = "http://ec2-18-221-89-14.us-east-2.compute.amazonaws.com/flaskapp/ecommerce_product/EcommerceProduct/";
	}
		
	public function index() { 
		$this->_load_list_view();		
	}
	
	private function _load_list_view() {
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$url = $this->base_url."getOfferList/".$organisation_id;
		$data = array();
		$make_call = $this->callAPI('GET', $url,$data);
		$response = json_decode($make_call, true);
		$list = $response['responseList'];
		
		$data = array(
			"status"	=> false,
			"message"  	=> "",
			"post_data"	=>	$list
		);
		$data['admin'] = $this->admin;
		$data['content'] = 'admin/offer/list';
		$this->load->view('admin/layouts/index', $data);
	}
	
	public function add(){
		$this->_load_add_view();
	}
	
	private function _load_add_view(){		
		$data['content']='admin/offer/add';
		$this->load->view('admin/layouts/index',$data);
	}
	
	public function add_content(){
		if($this->input->post()){
			$this->form_validation->set_rules('coupon_code','Coupon Code','required');			
			
			if($this->form_validation->run()==FALSE){	
				$this->_load_add_view();
			}else{
				if(is_uploaded_file($_FILES['imgInp']['tmp_name']))
				{
					$img=$this->image_upload();
					if($img['status']==1){
						$udata['offer_image']=base_url()."public/admin_assets/images/offer/".$img['result'];						
					}else{
						$this->session->set_flashdata('error_msg',$img['result']);
						redirect('admin/offer/','refersh'); 	
					}				
				}
				$udata['coupon_code'] = $this->input->post('coupon_code');
				$organisation = $this->admin;
				$organisation_id = $organisation['organisation_id'];
				$udata['organisation_id'] = $organisation_id;
				$udata['status'] = 1;
				$offer_id = $this->moffer->insert('offer',$udata);
				if(!empty($offer_id))
				{
					$offer_condition = array("offer_id"=>$offer_id);
					$offer_detail = $this->moffer->getDetail('offer',$offer_condition);
					$push['image-url'] = $offer_detail['offer_image'];
					$push['title'] = "offer";
					$push['message'] =  "Offer Coupon Code:".$offer_detail['coupon_code'];
					$condition = array("organisation_id"=>$organisation_id);
					$firebase_details = $this->moffer->getDetail('organisation_firebase_details',$condition);
					$deviceList=$this->moffer->deviceList();
					
					if(!empty($deviceList)){
						foreach($deviceList as $device){
							if($device['device_type']==2 && $device['device_token'] != ''){
								$this->send_android_notification($device['device_token'],$push,$firebase_details['firebase_key']);
							}
						}					
					}
				}
				redirect('admin/offer');
			}
		}else{
			$this->_load_list_view();
		}
	}
	
	public function edit($ofer_id)
	{
		$organisation_id = 1;
		$url = $this->base_url."getOfferDetails/".$ofer_id;
		$data = array();
		$make_call = $this->callAPI('GET', $url,$data);
		$response = json_decode($make_call, true);
		$data['cms'] = $response['responseList'];	
		if(empty($data['cms'])){
			$this->_load_list_view();
		}else{			
			$this->_load_details_view($data);
		}
	}
	
	public function delete_offer()
	{		
		$offer_id = $this->input->post('offer_id');
		$url = $this->base_url."deleteOffer/".$offer_id;
		$data = array();
		$make_call = $this->callAPI('DELETE', $url,$data);
		$response = json_decode($make_call, true);
		echo json_encode($response);
	}

	
	public function update()
	{
		if($this->input->post()){
			$offer_id = $this->input->post('offer_id');
			$this->form_validation->set_rules('coupon_code','Coupon Code','required');
			
			if($this->form_validation->run()==FALSE){
				$url = $this->base_url."getOfferDetails/".$ofer_id;
				$data = array();
				$make_call = $this->callAPI('GET', $url,$data);
				$response = json_decode($make_call, true);
				$data['cms'] = $response['responseList'];	
				$this->_load_details_view($data);
			}else{
				if(is_uploaded_file($_FILES['imgInp']['tmp_name']))
				{
					$img=$this->image_upload();
					if($img['status']==1){
						$udata['offer_image']=base_url()."public/admin_assets/images/offer/".$img['result'];						
					}else{
						$this->session->set_flashdata('error_msg',$img['result']);
						redirect('admin/offer/','refersh'); 	
					}				
				}
				$udata['coupon_code'] = $this->input->post('coupon_code');
				$condition = array("offer_id"=>$offer_id);
				$this->moffer->update('offer',$condition,$udata);
				redirect('admin/offer');
			}
		}else{
			$this->_load_list_view();
		}
	}
	
	
	public function _load_details_view($parms)
	{
		$data['cms']=$parms['cms'];	
		$data['content'] = 'admin/offer/detail';
		$this->load->view('admin/layouts/index', $data);
	}
	
	private function image_upload(){ 
		$img='imgInp';
		$config['upload_path'] = './public/admin_assets/images/offer';
		$config['allowed_types'] = 'gif|jpg|png|jpeg|GIF';
		$config['encrypt_name']  = true;
		$this->load->library('upload', $config);
		if ( ! $this->upload->do_upload($img)){
			$message = array('result' => $this->upload->display_errors(),'status'=>0);
		}else{ 
			$data = array('upload_data' => $this->upload->data());
			$message = array('result' => $data['upload_data']['file_name'],'status'=>1);
		}
		return $message;
	}

	
	public function callAPI($method, $url, $data){
	   $curl = curl_init();
	   switch ($method){
		  case "POST":
			 curl_setopt($curl, CURLOPT_POST, 1);
			 curl_setopt($curl,CURLOPT_SSL_VERIFYPEER, false);
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
			 break;
		  case "PUT":
			 curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);			 					
			 break;
		  case "DELETE":
			 curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "DELETE");
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);			 					
			 break;
		  default:
			 if ($data)
				$url = sprintf("%s?%s", $url, http_build_query($data));
	   }
	   // OPTIONS:
	   curl_setopt($curl, CURLOPT_URL, $url);
	   curl_setopt($curl, CURLOPT_HTTPHEADER,array(
		'Content-Type: application/json',
		));
	   curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
	   curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
	   // EXECUTE:
	   $result = curl_exec($curl);
	   if(!$result){die("Connection Failure");}
	   curl_close($curl);
	   return $result;
	}
	
	public function send_android_notification($registration_ids, $data,$firebase_key) {
		$fields = array(
		'registration_ids' => array($registration_ids),
		'data'=> $data,
		);
		$headers = array(
		'Authorization: key='.$firebase_key, // FIREBASE_API_KEY_FOR_ANDROID_NOTIFICATION
		'Content-Type: application/json'
		);
		// Open connection
		$ch = curl_init();
		 
		// Set the url, number of POST vars, POST data
		curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
		curl_setopt( $ch,CURLOPT_POST, true );
		curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
		curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
		 
		// Disabling SSL Certificate support temporarly
		curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
		curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
		 
		// Execute post
		$result = curl_exec($ch );
		if($result === false){
		//die('Curl failed:' .curl_errno($ch));
			return 0;
		}
		 
		// Close connection
		curl_close( $ch );
		return $result;
	}
}