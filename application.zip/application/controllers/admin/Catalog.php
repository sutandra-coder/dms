<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Catalog extends MY_Controller {
	public function __construct() {
		parent::__construct();
		$this->redirect_guest();
		$this->admin=$this->session->userdata('admin');		
		$this->base_url = "http://ec2-18-221-89-14.us-east-2.compute.amazonaws.com/flaskapp/ecommerce_product/EcommerceProduct/";
		$this->base_url_product_admin = "http://ec2-18-221-89-14.us-east-2.compute.amazonaws.com/flaskapp/ecommerce_product_admin/EcommerceProductAdmin/";
	}
	
	public function index() { 
		$this->_load_list_view();		
	}
	
	private function _load_list_view() {
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$url = $this->base_url."catalogListWithProduct/".$organisation_id;
		$data = array();
		$make_call = $this->callAPI('GET', $url,$data);
		$response = json_decode($make_call, true);
		$list = $response['responseList'];
		
		$data = array(
			"status"	=> false,
			"message"  	=> "",
			"post_data"	=>	$list
		);
		$data['admin'] = $this->admin;
		$data['content'] = 'admin/catalog/list';
		$this->load->view('admin/layouts/index', $data);
	}
	
	public function add(){
		$this->_load_add_view();
	}
	
	private function _load_add_view(){		
		$data['content']='admin/catalog/add';
		$this->load->view('admin/layouts/index',$data);
	}
	
	public function add_content()
	{
		if($this->input->post()){
			$this->form_validation->set_rules('catalog','catalog','required');
			
			if($this->form_validation->run()==FALSE){			
				$this->_load_add_view();
			}else{
				$admin = $this->admin;
				$url = $this->base_url."AddCatalog";				
				$organisation = $this->admin;
				$organisation_id = $organisation['organisation_id'];
				$udata['catalog_name'] = $this->input->post('catalog');
				$udata['organisation_id'] = $organisation_id;				
				$make_call = $this->callAPI('POST', $url,json_encode($udata));
				$response = json_decode($make_call, true);
				if($response['attributes']['status'] == 'success')
				{
					$this->session->set_flashdata('success_msg','Catalog Saved successfully');					
				}else{
					$this->session->set_flashdata('error_msg',$response['responseList']);
				}
				redirect('admin/catalog');
			}
		}else{
			$this->_load_list_view();
		}
		
	}
	
	public function produt_catalog_list()
	{
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$catalog_id = $this->input->post('catalog_id');
		$url = $this->base_url."organisationproductListWithOutMetaByCatalogId/".$catalog_id."/".$organisation_id;
		$data = array();
		$make_call = $this->callAPI('GET', $url,$data);
		$response = json_decode($make_call, true);
		echo json_encode($response);
	}
	
	/*public function add_catalog_product()
	{
		$product_id = $this->input->post('product_id');
		$catalog_id = $this->input->post('catalog_id');
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];		
		$url = $this->base_url."AddProductCatalog";
		$data['product_id'] = $product_id;
		$data['catalog_id'] = $catalog_id;
		$data['organisation_id'] = $organisation_id;				
		$make_call = $this->callAPI('POST', $url,json_encode($data));
		$response = json_decode($make_call, true);
		echo json_encode($response);
	}*/
	
	public function add_catalog_product()
	{
		$product_id = $this->input->post('product_id');
		$catalog_id = $this->input->post('catalog_id');
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];		
		$url = $this->base_url."AddProductCatalog";		
		$data = '{
		  "product_id": [
			'.$product_id.'
		  ],
		  "catalog_id": '.$catalog_id.',
		  "organisation_id": '.$organisation_id.'		  
		}';
		//$data['product_id'] = "[".$product_id."]";
		//$data['catalog_id'] = $catalog_id;
		//$data['organisation_id'] = $organisation_id;	
		//echo json_encode($data);exit;
		$make_call = $this->callAPI('POST', $url,$data);
		$response = json_decode($make_call, true);
		echo json_encode($response);
	}
	
	public function remove_catalog_product()
	{
		$product_id = $this->input->post('product_id');
		$catalog_id = $this->input->post('catalog_id');
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$url = $this->base_url."deleteCatalogProduct/".$catalog_id."/".$product_id."/".$organisation_id;
		$data = array();
		$make_call = $this->callAPI('DELETE', $url,$data);
		$response = json_decode($make_call, true);
		echo json_encode($response);	
	}
	
	public function add_catalog_category()
	{
		$category_id = $this->input->post('category_id');
		$catalog_id = $this->input->post('catalog_id');
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];		
		$url = $this->base_url_product_admin."AddCatalogCategory";
		$data['category_id'] = $category_id;
		$data['catalog_id'] = $catalog_id;
		$data['organisation_id'] = $organisation_id;				
		$make_call = $this->callAPI('POST', $url,json_encode($data));
		$response = json_decode($make_call, true);
		echo json_encode($response);
	}
	
	public function remove_catalog_category()
	{
		$category_id = $this->input->post('category_id');
		$catalog_id = $this->input->post('catalog_id');
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$url = $this->base_url_product_admin."deleteCatalogCategory/".$catalog_id."/".$category_id."/".$organisation_id;
		$data = array();
		$make_call = $this->callAPI('DELETE', $url,$data);
		$response = json_decode($make_call, true);
		echo json_encode($response);	
	}
	
	public function add_home_section()
	{
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$catalog_id = $this->input->post('catalog_id');		
		$url = $this->base_url_product_admin."AddCatalogCategory";
		$data['catalog_id'] = $catalog_id;
		$data['is_home_section'] = 1;		
		$data['organisation_id'] = $organisation_id;
		$make_call = $this->callAPI('POST', $url,json_encode($data));
		$response = json_decode($make_call, true);
		echo json_encode($response);
	}
	
	public function remove_home_section()
	{
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$catalog_id = $this->input->post('catalog_id');		
		$url = $this->base_url_product_admin."AddCatalogCategory";
		$data['catalog_id'] = $catalog_id;
		$data['is_home_section'] = 0;
		$data['organisation_id'] = $organisation_id;		
		$make_call = $this->callAPI('POST', $url,json_encode($data));
		$response = json_decode($make_call, true);
		echo json_encode($response);
	}
	
	public function category_catalog_list()
	{
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$catalog_id = $this->input->post('catalog_id');	
		$url = $this->base_url."catalogListWithategory/".$organisation_id."/".$catalog_id;
		$data = array();
		$make_call = $this->callAPI('GET', $url,$data);
		$response = json_decode($make_call, true);
		echo json_encode($response);
	}
	
	public function edit($catalog_id)
	{
		$organisation = $this->admin;
		$organisation_id = $organisation['organisation_id'];
		$url = $this->base_url."catalogDetails/".$catalog_id;
		$data = array();
		$make_call = $this->callAPI('GET', $url,$data);
		$response = json_decode($make_call, true);
		$data['cms'] = $response['responseList'];
		
		if(empty($data['cms'])){
			$this->_load_list_view();
		}else{			
			$this->_load_details_view($data);
		}
	}
	
	public function _load_details_view($parms)
	{
		$data['cms']=$parms['cms'];				
		$data['content'] = 'admin/catalog/detail';
		$this->load->view('admin/layouts/index', $data);
	}
	
	public function update()
	{
		if($this->input->post()){
			$catalog_id = $this->input->post('catalog_id');
			$this->form_validation->set_rules('catalog','Catalog Name','required');
			
			if($this->form_validation->run()==FALSE){
				$organisation_id = 1;
				$url = $this->base_url."catalogDetails/".$catalog_id;
				$data = array();
				$make_call = $this->callAPI('GET', $url,$data);
				$response = json_decode($make_call, true);
				$data['cms'] = $response['responseList'];
				$this->_load_details_view($data);
			}else{
				$udata['catalog_name'] = $this->input->post('catalog');				
				$url = $this->base_url."UpdateCatalog/".$catalog_id;				
				$make_call = $this->callAPI('PUT', $url,json_encode($udata));
				$response = json_decode($make_call, true);
				
				if($response['attributes']['status'] == 'error')
				{
					$this->session->set_flashdata('error_msg',$response['responseList']);
				}else{
					$this->session->set_flashdata('success_msg',$response['responseList']);
				}
				redirect('admin/catalog');
			}
		}else{
			$this->_load_list_view();
		}
	}
	
	public function callAPI($method, $url, $data){
	   $curl = curl_init();
	   switch ($method){
		  case "POST":
			 curl_setopt($curl, CURLOPT_POST, 1);
			 curl_setopt($curl,CURLOPT_SSL_VERIFYPEER, false);
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
			 break;
		  case "PUT":
			 curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);			 					
			 break;
		  case "DELETE":
			 curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "DELETE");
			 if ($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);			 					
			 break;
		  default:
			 if ($data)
				$url = sprintf("%s?%s", $url, http_build_query($data));
	   }
	   // OPTIONS:
	   curl_setopt($curl, CURLOPT_URL, $url);
	   curl_setopt($curl, CURLOPT_HTTPHEADER,array(
		'Content-Type: application/json',
		));
	   curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
	   curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
	   // EXECUTE:
	   $result = curl_exec($curl);
	   if(!$result){die("Connection Failure");}
	   curl_close($curl);
	   return $result;
	}
}