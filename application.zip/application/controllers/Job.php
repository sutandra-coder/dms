<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Job extends MY_Controller {
	public function __construct() {
		parent::__construct();
		$this->redirect_guest();
		$this->admin=$this->session->userdata('admin');
		$this->load->model('admin/mjob');
	}
		
	public function index() {		
		$this->_load_list_view();		
	}
	
	private function _load_list_view() {
		$data['content'] = 'admin/job/list';
		$this->load->view('admin/layouts/index', $data);
	}
	
	public function all_content_list(){		
		$list = $this->mjob->get_datatables();	
        $data = array();
        $no = $_POST['start'];
		$i=1;
        foreach ($list as $person) {
            $no++;
            $row = array();
			//$row[] = '<input type="checkbox" class="cstm_view" title="'.$person->user_id.'">';				
			$row[]=$i;			
			$row[] = $person->job_title;
			$row[] = $person->job_date;					
			$row[] = $person->client_phoneno;						
            $row[] = '<a class="cstm_view" id="delete" style="padding-left:5px" href="javascript:void(0)" title="'.$person->job_id.'"><i class="glyphicon glyphicon-remove"></i></a><a class="cstm_view" id="view" style="padding-left:5px" href="javascript:void(0)" title="'.$person->job_id.'"><i class="glyphicon glyphicon-eye-open"></i></a>';
			//$row[] = '<a class="cstm_view" id="view" style="padding-left:10px" href="javascript:void(0)" title="'.$person->user_id.'"><i class="glyphicon glyphicon-eye-open"></i></a>';
            $data[] = $row;
			$i++;
        }
        $output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" => $this->mjob->count_all(),
                        "recordsFiltered" => $this->mjob->count_filtered(),
                        "data" => $data,
                );
        echo json_encode($output);
	}
	
	public function all_details(){
		$job_id = $this->input->post('job_id');		
		$result = $this->mjob->get_details($job_id);	
		$category = $this->mjob->get_category_by_id($result['sub_cat_id']);
		if($category)
		{
			$result['category'] = $category;			
			$parent_category = $this->mjob->get_parent_category_by_parent_id($result['category']['parent_id']);
			if($parent_category)
			{
				$result['parent_category'] = $parent_category;
			}else{
				$result['parent_category']['category_name'] = '-';
			}
		}else{
			$result['parent_category']['category_name'] = '-';
			$result['category']['category_name'] = '-';
		}		
		echo json_encode($result);
	}
	
	public function edit($user_id){
		$data['cms']=$this->musersetting->get_details($user_id);	
		if(empty($data['cms'])){
			$this->_load_list_view();
		}else{			
			$this->_load_details_view($data);
		}
	}
	
	private function _load_details_view($parms){
		$data['parent_categories'] = $this->musersetting->get_parent_category();		
		$data['sub_category'] = $this->musersetting->get_sub_category_by_category_id($parms['cms']['cat_id']);		
		$data['parent_category_sub'] = $this->musersetting->get_parent_category_by_parent_id($data['sub_category']['parent_id']);
		$data['sub_categories'] = $this->musersetting->get_sub_categories_by_parent_id($data['sub_category']['parent_id']);
		$data['cms']=$parms['cms'];	
		$data['content'] = 'admin/usersetting/detail';
		$this->load->view('admin/layouts/index', $data);
	}
	
	public function update(){
		if($this->input->post()){
			$user_id = $this->input->post('user_id');
			$this->form_validation->set_rules('name','Name','required');			
			$this->form_validation->set_rules('phoneno','Phoneno','required');			
			
			if($this->form_validation->run()==FALSE){
				$data['cms']=$this->musersetting->get_details($user_id);				
				$this->_load_details_view($data);
			}else{
				$user_information = $this->musersetting->get_details($user_id);
				
				if(!empty($_FILES['imgInp']['name'])){
					$file=$this->image_upload();
					if($file['status']==1){
						$udata['profile_image']=$file['result'];
						if($_FILES['imgInp']['name']){
							if($user_information['profile_image']){								
								unlink('./public/images/profilepics/'.$user_information['profile_image']);
							}
						}						
					}else{
						$this->session->set_flashdata('error_msg',$file['result']);
						redirect('admin/usersetting/details/'.$user_id,'refersh');
					}
				}
				
				$condition=array('user_id'=>$user_id);
				
				$udata['name']=$this->input->post('name');									
				$udata['phoneno']=$this->input->post('phoneno');	
				$udata['cat_id']=$this->input->post('sub_category_id');
				$udata['address'] = $this->input->post('address');				
				$udata['date_of_update']=date('Y-m-d H:i:s');
				
				$this->musersetting->update($condition,$udata);
				$this->session->set_flashdata('success_msg','User updated successfully');
				redirect('admin/usersetting');
			}
		}else{
			$this->_load_list_view();
		}
	}
	
	public function add_content()
	{
		if($this->input->post()){
			$this->form_validation->set_rules('job_title','Job Title','required');			
			$this->form_validation->set_rules('job_description','Job Description','required');			
			$this->form_validation->set_rules('job_date','Job Date','required');
			$this->form_validation->set_rules('job_start_time','Job Start Time','required');
			$this->form_validation->set_rules('job_end_time','Job End Time','required');
			$this->form_validation->set_rules('client_name','Client Name','required');
			$this->form_validation->set_rules('client_phone_no','Client Phone No','required');
			$this->form_validation->set_rules('job_address','Job Address','required');
			$this->form_validation->set_rules('type_of_work','Type Of Work','required');
			if($this->form_validation->run()==FALSE){			
				$this->_load_add_view();
			}else{			
				$udata['job_title']=$this->input->post('job_title');				
				$udata['job_description']=$this->input->post('job_description');				
				$udata['job_date']=$this->input->post('job_date');
				$udata['job_start_time']=$this->input->post('job_start_time');
				$udata['job_end_time']=$this->input->post('job_end_time');				
				$udata['sub_cat_id'] = $this->input->post('sub_category_id');
				$udata['cat_id'] = $this->input->post('category_id');
				$udata['client_name'] = $this->input->post('client_name');
				$udata['client_phoneno'] = $this->input->post('client_phone_no');
				$udata['job_address'] = $this->input->post('job_address');
				$udata['type_of_work'] = $this->input->post('type_of_work');
				$udata['job_status']=1;								
				$udata['date_of_creation']=date('Y-m-d H:i:s');				
				$this->mjob->add($udata);
				
				$push['title']=$this->input->post('job_title');
				$push['description']=$this->input->post('job_description');
				$push['job_date']=$this->input->post('job_date');
				$push['job_start_time']=$this->input->post('job_start_time');
				$push['job_end_time']=$this->input->post('job_end_time');
				
				$deviceList=$this->mjob->deviceList($this->input->post('category_id'));
				if(!empty($deviceList)){
					foreach($deviceList as $device){
						if($device['device_type']==2 && $device['device_token'] != '' && $device['loggedin_status'] == 1){
							$this->send_android_notification($device['device_token'],$push);
						}else if($device['device_type']==1 && $device['device_token'] != '' && $device['loggedin_status'] == 1){
							$this->send_ios_notification($device['device_token'],$push);
						}
					}					
				}
				$this->session->set_flashdata('success_msg','Job added successfully');
				redirect('admin/job');
			}
		}else{
			$this->_load_list_view();
		}
	}
	
	private function image_upload(){ 
		$img='imgInp';
		if (!is_dir('./public/admin_assets/images/profilepics/')) {
			mkdir('./public/admin_assets/images/profilepics/' ,0777, TRUE);			
		}		
		$config['upload_path'] = './public/admin_assets/images/profilepics/';
		$config['allowed_types'] = 'gif|jpg|png';
		//$config['min_width']  = '200';
		//$config['min_height']  = '200';
		//$config['max_size']	= '100';
		//$config['max_width']  = '1024';
		//$config['max_height']  = '768';
		$config['encrypt_name']  = true;
		$this->load->library('upload', $config);
		if ( ! $this->upload->do_upload($img)){
			$message = array('result' => $this->upload->display_errors(),'status'=>0);
		}else{ 
			$data = array('upload_data' => $this->upload->data());
			$message = array('result' => $data['upload_data']['file_name'],'status'=>1);
		}
		return $message;
	}
	
	public function add(){		
		$this->_load_add_view();
	}
	
	private function _load_add_view(){		
		$data['parent_categories'] = $this->mjob->get_parent_category();
		$data['content']='admin/job/add';
		$this->load->view('admin/layouts/index',$data);
	}
	
	public function delete_content(){
		$condition['job_id']=$this->input->post('job_id');
		
		$this->mjob->delete($condition);
		$response=array('status'=>1,'message'=>'Success');
		echo header('Content-Type: application/json');
		echo json_encode($response);
	}
	
	public function active()
	{
		$condition['user_id']=$this->input->post('user_id');
		$udata['status'] = 1;
		$this->musersetting->active($condition,$udata);
		$response=array('status'=>1,'message'=>'Success');		
		echo json_encode($response);
	}
	
	public function inactive()
	{
		$condition['user_id']=$this->input->post('user_id');
		$udata['status'] = 0;
		$this->musersetting->active($condition,$udata);
		$response=array('status'=>1,'message'=>'Success');		
		echo json_encode($response);
	}
	
	public function multiple_del()
	{
		$user_ids = explode(',',$this->input->post('user_ids'));
		foreach($user_ids as $user_id)
		{
			$condition['user_id'] = $user_id;					
			$this->musersetting->delete($condition);			
			$response=array('status'=>1,'message'=>'Success');
		}		
		echo header('Content-Type: application/json');
		echo json_encode($response);
	}
	
	public function get_sub_category()
	{
		$category_id =  $this->input->post('category_id');
		$result['sub_category'] = $this->musersetting->get_sub_category($category_id);
		if(empty($result))
		{
			$result = array("category_name"=>"Select");
		}
		echo json_encode($result);
	}
	
	public function send_ios_notification($devicetoken,$data){
		$passphrase='123456';
        $deviceToken = $devicetoken;    
        $ctx = stream_context_create();
		// ck.pem is your certificate file ssl://gateway.sandbox.push.apple.com:2195
		stream_context_set_option($ctx, 'ssl', 'local_cert', './public/WeCareStaffPem.pem');
		stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);
		// Open a connection to the APNS server
		$fp = stream_socket_client(
			'ssl://gateway.sandbox.push.apple.com:2195', $err,
			$errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);

		if (!$fp){ 
			//exit("Failed to connect: $err $errstr" . PHP_EOL);
			return 2;
		}else{
			// Create the payload body
			$body['aps'] = array(
					'alert' => array(
					    'title' => 'Wecare App',
		                'body' => 'Wecare App',
					 ),
					'sound' => 'default',
					'data'=>$data
			);

			// Encode the payload as JSON
			$payload = json_encode($body);
			// Build the binary notification
			$msg = chr(0) . pack('n', 32) . pack('H*', str_replace(' ', '', $deviceToken)) . pack('n', strlen($payload)) . $payload;  //
			//$msg = chr(0) . pack('n', 32) . pack('H*',str_replace(' ', '', sprintf('%u', CRC32($deviceToken)))) . pack('n', strlen($payload)) . $payload;  // 
			//str_replace(' ', '', sprintf('%u', CRC32($deviceToken)))
			//$msg = chr(0) . pack('n', 32) . pack('H*', str_replace(' ', '', sprintf('%u', CRC32($deviceToken)))) . pack('n', strlen($payload)) . $payload
			// Send it to the server
			$result = fwrite($fp, $msg, strlen($msg));
			// Close the connection to the server
			fclose($fp);
			if (!$result){
				//return 'Message not delivered' . PHP_EOL;
				return 0; 
			}else{
				//return  'Message successfully delivered' . PHP_EOL;
				return 1;
			}
		} 
	}
	public function send_android_notification($registration_ids, $data) {
		$fields = array(
		'registration_ids' => array($registration_ids),
		'data'=> $data,
		);
		$headers = array(
		'Authorization: key=AAAAAjykQAw:APA91bF2xwn1yqpfBkoxg_K_fTp5bOaI4M3zXL_yG63hmQpqvVFZlMiilFdf65DWdqAO5Xy3eBxJjFybwKMwDMnr16ls_YnMDpMAfwTbJUcBnpHK4supv42pZIoDEBHrdUwOFI9wmQYs', // FIREBASE_API_KEY_FOR_ANDROID_NOTIFICATION
		'Content-Type: application/json'
		);
		// Open connection
		$ch = curl_init();
		 
		// Set the url, number of POST vars, POST data
		curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
		curl_setopt( $ch,CURLOPT_POST, true );
		curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
		curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
		 
		// Disabling SSL Certificate support temporarly
		curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
		curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
		 
		// Execute post
		$result = curl_exec($ch );
		if($result === false){
		//die('Curl failed:' .curl_errno($ch));
			return 0;
		}
		 
		// Close connection
		curl_close( $ch );
		return $result;
	}
}