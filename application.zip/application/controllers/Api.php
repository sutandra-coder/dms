<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Api extends CI_Controller {
    var $arr;
    var $obj;
	var $logo='';
	function __construct(){
		parent::__construct();
		$this->load->model('mapi');
		$this->arr=array();
		$this->obj=new stdClass();
		$this->logo=base_url().'/public/admin_assets/images/Logo.png';
  }
    private function displayOutput($response){
        header('Content-Type: application/json');
        echo json_encode($response);
        exit(0);
    }	
	
	
	//Login
	public function login()
	{
		$ap=json_decode(file_get_contents('php://input'), true);
		if(sizeof($ap)){
			if(empty($ap['email'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'Email field is required'),'result'=>array('userdetails'=>$this->obj));
              $this->displayOutput($response);
            }
			
			if(empty($ap['password'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'Password field is required'),'result'=>array('userdetails'=>$this->obj));
              $this->displayOutput($response);
            }
			
			$ap['password']=sha1($ap['password']);	

			if(!empty($ap['device_token']) && !empty($ap['device_type']))
			{
				$device_token=$ap['device_token'];
				$device_type=$ap['device_type'];
			}
			
			
			unset($ap['device_token']);
            unset($ap['device_type']);	

			
			$userdetails=$this->mapi->checkUser($ap);
			
			//print_r($userdetails);exit;
			
			if(empty($userdetails)){
            	$response=array('status'=>array('error_code'=>1,'message'=>'Invalid username or password'),'result'=>array('userdetails'=>$this->obj));
            }else{
				if($userdetails['status'] == 0)
				{
					$response=array('status'=>array('error_code'=>1,'message'=>'Your account is still pending.please contact admin for approval'),'result'=>array('userdetails'=>$this->obj));
				}else{
					
					$condition=array('email'=>$ap['email']);
					$data=array('date_of_lastlogin'=>date('Y-m-d H:i:s'),'loggedin_status'=>1);
					$this->mapi->update('admins',$condition,$data);
					
					$user_detail = $this->mapi->getRow('admins',$condition);
					$userdetails['date_of_lastlogin'] = $user_detail['date_of_lastlogin'];
					$userdetails['loggedin_status'] = $user_detail['loggedin_status'];
					
					if(!empty($device_token) && !empty($device_type))
					{
						$device_condition=array('device_type'=>$device_type,'user_id'=>$userdetails['admin_id']);
						$checkDeviceExist=$this->mapi->getRow('devices',$device_condition);	
						if(empty($checkDeviceExist)){
							  $dv['device_type']= $device_type;
							  $dv['device_token']=$device_token;
							  $dv['user_id']=$userdetails['user_id'];
							  $dv['date_of_creation']=date('Y-m-d h:i:s');
							  $this->mapi->insert('devices',$dv);
							}else{
							  $dv['device_token']=$device_token;
							  $dv['date_of_creation']=date('Y-m-d h:i:s');
							  $this->mapi->update('devices',$device_condition,$dv);	
							}
					}
					$response=array('status'=>array('error_code'=>0,'message'=>'Success'),'result'=>array('userdetails'=>$userdetails));
				}		
				
			}
			
		}else{
      		$response=array('status'=>array('error_code'=>1,'message'=>'Please fill up all required fields'),'result'=>array('userdetails'=>$this->obj));
      	}
      	$this->displayOutput($response);
	}
	
	//Profile Detail
	public function profileDetail()
	{
		$ap=json_decode(file_get_contents('php://input'), true);
		if(sizeof($ap)){
			if(empty($ap['user_id'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'User Id field is required'),'result'=>array('userdetails'=>$this->obj));
              $this->displayOutput($response);
            }
			
			$condition=array('admin_id'=>$ap['user_id']);
			$userDetail=$this->mapi->getRow('admins',$condition);			
			
			if(!empty($userDetail))
			{
				$response=array('status'=>array('error_code'=>0,'message'=>'Success'),'result'=>array('userdetails'=>$userDetail));
			}else{
				$response=array('status'=>array('error_code'=>0,'message'=>'Success'),'result'=>array('userdetails'=>$this->obj));
			}
					
		}else{
      		$response=array('status'=>array('error_code'=>1,'message'=>'Please fill up all required fields'),'result'=>array('userdetails'=>$this->obj));
      	}
      	$this->displayOutput($response);
	}
	
	//Update Profile
	public function profileUpdate()
	{
		 $ap=json_decode(file_get_contents('php://input'), true);
		  if(sizeof($ap)){
			  if(empty($ap['admin_id'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'User id field is required'),'result'=>$this->obj);
              $this->displayOutput($response);
			}
			
			 if(empty($ap['first_name'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'First name field is required'),'result'=>$this->obj);
              $this->displayOutput($response);
			}
			
			if(empty($ap['last_name'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'Last name field is required'),'result'=>$this->obj);
              $this->displayOutput($response);
			}
			
			if(empty($ap['employee_id'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'Employee Id field is required'),'result'=>$this->obj);
              $this->displayOutput($response);
			}
			
			if(empty($ap['dob'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'Date Of Birth field is required'),'result'=>$this->obj);
              $this->displayOutput($response);
			}
			
			if(empty($ap['emergency_contact'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'Emergency Contact No field is required'),'result'=>$this->obj);
              $this->displayOutput($response);
			}	
			
			if(empty($ap['tfn'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'TFN field is required'),'result'=>$this->obj);
              $this->displayOutput($response);
			}
			
			if(empty($ap['abn'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'ABN field is required'),'result'=>$this->obj);
              $this->displayOutput($response);
			}
			
			if(empty($ap['address'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'Address field is required'),'result'=>$this->obj);
              $this->displayOutput($response);
			}
			
		
			$condition=array('admin_id'=>$ap['admin_id']);
			$this->mapi->update('admins',$condition,$ap);			
			$response=array('status'=>array('error_code'=>0,'message'=>'Profile updated successfully'),'result'=>$this->obj);
		  }else{
				$response=array('status'=>array('error_code'=>1,'message'=>'Please fill up all required fields'),'result'=>$this->obj);
		  }
      $this->displayOutput($response);
	}
	
	//Change Password
	public function changePassword(){
    	$ap=json_decode(file_get_contents('php://input'), true);
      	if(sizeof($ap)){
      		if(empty($ap['old_password'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'Old password field is required'),'result'=>$this->obj);
              $this->displayOutput($response);
            }
            if(empty($ap['new_password'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'New password field is required'),'result'=>$this->obj);
              $this->displayOutput($response);
            }
            if(empty($ap['confirm_password'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'Confirm password field is required'),'result'=>$this->obj);
              $this->displayOutput($response);
            }
            if(empty($ap['user_id'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'User id field is required'),'result'=>$this->obj);
              $this->displayOutput($response);
            }
            $condition=array('admin_id'=>$ap['user_id']);
            $userdetails=$this->mapi->getRow('admins',$condition);
            if(strtolower($userdetails['org_password'])!=strtolower($ap['old_password'])){
            	$response=array('status'=>array('error_code'=>1,'message'=>'Old password is wrong'),'result'=>$this->obj);
              $this->displayOutput($response);
            }
            if(strtolower($ap['new_password'])!=strtolower($ap['confirm_password'])){
            	$response=array('status'=>array('error_code'=>1,'message'=>'New password does not match with confirm password'),'result'=>$this->obj);
              $this->displayOutput($response);
            }
            if(strtolower($ap['new_password'])==strtolower($ap['old_password'])){
            	$response=array('status'=>array('error_code'=>1,'message'=>'New password same as old password,try something else'),'result'=>$this->obj);
              $this->displayOutput($response);
            }
            $condition=array('admin_id'=>$ap['user_id']);
            $data=array('date_of_update'=>date('Y-m-d H:i:s'),'password'=>sha1($ap['new_password']),'org_password'=>$ap['new_password']);
            $this->mapi->update('admins',$condition,$data);
            $response=array('status'=>array('error_code'=>0,'message'=>'Password changed successfully'),'result'=>$this->obj);
      	}else{
      		$response=array('status'=>array('error_code'=>1,'message'=>'Please fill up all required fields'),'result'=>$this->obj);
      	}
      	$this->displayOutput($response);
    }
	
	//Forgot Password
	public function forgotPassword(){ 
    	$ap=json_decode(file_get_contents('php://input'), true);
      	if(sizeof($ap)){
      		if(empty($ap['email'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'Email field is required'),'result'=>array('details'=>$this->obj));
              $this->displayOutput($response);
            }
			
			$password = rand(000,999);
			$condition=array('email'=>$ap['email']);
            $data=array('password'=>sha1($password),'org_password'=>$password);
            $this->mapi->update('admins',$condition,$data);			
            
            $userDetails=$this->mapi->getRow('admins',$condition);
            if(empty($userDetails)){
            	$response=array('status'=>array('error_code'=>1,'message'=>'This email does not exist'),'result'=>array('details'=>$this->obj));
            }else{
            	$mail_temp = file_get_contents('./global/mail/password.html');
            	$mail_temp=str_replace("{shop_name}","Punjab Motor Work Shop",$mail_temp);
            	$mail_temp=str_replace("{shop_logo}",$this->logo,$mail_temp);
				$mail_temp=str_replace("{name}",$userDetails['name'],$mail_temp);
            	$mail_temp=str_replace("{username}",$userDetails['email'],$mail_temp);
            	$mail_temp=str_replace("{email}",$userDetails['email'],$mail_temp);
            	$mail_temp=str_replace("{passwd}",$userDetails['org_password'],$mail_temp);
            	$data['to']=$userDetails['email'];
            	$data['name']='Punjab Motor Work Shop';
            	$data['subject']='Punjab Motor Work Shop - new login credential';
            	$data['message']=$mail_temp;
            	$data['from']='punjabmotorworkshop@gmail.com';				
            	if($this->sendMail($data)){
                $response=array('status'=>array('error_code'=>0,'message'=>'Your login credential has been sent to your email'),'result'=>array('details'=>$this->obj));
              }else{
                $response=array('status'=>array('error_code'=>0,'message'=>'Due to server error mail could not be sent'),'result'=>array('details'=>$this->obj));
              }
            }
      	}else{
      		$response=array('status'=>array('error_code'=>1,'message'=>'Please fill up all required fields'),'result'=>array('details'=>$this->obj));
      	}
      	 $this->displayOutput($response);
    }
	
	//Question List
	public function questionList()
	{
		$condition = array();
		$questionList = $this->mapi->getRows('question',$condition);
		
		if(!empty($questionList)){
			$response=array('status'=>array('error_code'=>0,'message'=>'success'),'result'=>array('list'=>$questionList));
		}else{
			$response=array('status'=>array('error_code'=>0,'message'=>'success'),'result'=>array('list'=>$this->arr));
		}
		
		$this->displayOutput($response);
		
	}
	
	//Car List
	public function carList()
	{
		$condition = array();
		$carList = $this->mapi->getRows('car',$condition);
		
		if(!empty($carList)){
			$response=array('status'=>array('error_code'=>0,'message'=>'success'),'result'=>array('list'=>$carList));
		}else{
			$response=array('status'=>array('error_code'=>0,'message'=>'success'),'result'=>array('list'=>$this->arr));
		}
		
		$this->displayOutput($response);
	}
	
	//save Inspection
	public function saveInspection()
	{
		$ap=json_decode(file_get_contents('php://input'), true);
		
		if(sizeof($ap)){
			if(empty($ap['mechanic_id'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'Mechanic field is required'),'result'=>$this->obj);
              $this->displayOutput($response);
            }
			
			if(empty($ap['car_id'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'Car Id field is required'),'result'=>$this->obj);
              $this->displayOutput($response);
            }
			
			if(empty($ap['question_answer'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'Question Answer field is required'),'result'=>$this->obj);
              $this->displayOutput($response);
            }	
			
			
			$question_answers =  $ap['question_answer'];
			
			$inspection_data['car_id'] = $ap['car_id'];
			$inspection_data['mechanic_id'] = $ap['mechanic_id'];
			$inspection_data['date_of_creation'] = date('Y-m-d');
			$inspection_data['time_of_creation'] = date('H:i:s');
			
			$inspection_id = $this->mapi->insert('inspection',$inspection_data);
			
			if (!empty($inspection_id))
			{
			
				foreach($question_answers as $question_answer)
				{
					$inspection_answer_data['inspection_id'] = $inspection_id;
					$inspection_answer_data['question_id'] = $question_answer['question_id'];
					$inspection_answer_data['option'] = $question_answer['option'];
					
					$inspection_answer_id = $this->mapi->insert('inspection_answer',$inspection_answer_data);
					
					if(!empty($inspection_answer_id))
					{
						foreach($question_answer['images'] as $question_answer_image)
						{
							$filename=$question_answer_image.'.png';
							$path='./public/admin_assets/images/inspection/';
							$this->imageUpload($question_answer_image,$filename,$path);
							$inspection_answer_image_data['image']=$filename;					     
							$inspection_answer_image_data['inspection_answer_id']=$inspection_answer_id;
							$inspection_answer_image_data['date_of_creation']=date('Y-m-d');
							$this->mapi->insert('inspection_answer_image',$inspection_answer_image_data);
						}
					}
				}
				
				 $response=array('status'=>array('error_code'=>0,'message'=>'Inspection done successfully'),'result'=>$this->obj);
			}else{
				$response=array('status'=>array('error_code'=>1,'message'=>'Something Went Wrong'),'result'=>$this->obj);
			}
			
		}else{
      		$response=array('status'=>array('error_code'=>1,'message'=>'Please fill up all required fields'),'result'=>$this->obj);
      	}
      	$this->displayOutput($response);
	}
	
	//My Inspection List
	public function myInspectionList()
	{
		$ap=json_decode(file_get_contents('php://input'), true);
		
		if(sizeof($ap)){
			if(empty($ap['mechanic_id'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'Mechanic field is required'),'result'=>$this->obj);
              $this->displayOutput($response);
            }
			
			$myInspectionCondition = array("mechanic_id"=>$ap['mechanic_id']);			
			$myinspections = $this->mapi->getRows('inspection',$myInspectionCondition);
			
			if(!empty($myinspections))
			{
				foreach($myinspections as $key=>$myinspection)
				{
					$car_information_condition = array("car_id"=>$myinspection['car_id']);
					$car_information = $this->mapi->getRow('car',$car_information_condition);
					$myinspections[$key]['car_no'] = $car_information['car_no'];
				}

				$response=array('status'=>array('error_code'=>0,'message'=>'success'),'result'=>array('myinspectionList'=>$myinspections));			
				
			}else{
				$response=array('status'=>array('error_code'=>0,'message'=>'success'),'result'=>array('myinspectionList'=>$this->arr));
			}
		}else{
      		$response=array('status'=>array('error_code'=>1,'message'=>'Please fill up all required fields'),'result'=>$this->obj);
      	}
      	$this->displayOutput($response);
	}
	
	//Inspection Details
	public function inspectionDetails()
	{
		$ap=json_decode(file_get_contents('php://input'), true);
		
		if(sizeof($ap)){
			if(empty($ap['inspection_id'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'Mechanic field is required'),'result'=>$this->obj);
              $this->displayOutput($response);
            }
			
			$condition = array("inspection_id"=>$ap['inspection_id']);
			$inspection_answers = $this->mapi->getRows('inspection_answer',$condition);
			
			
			if(!empty($inspection_answers))
			{
				foreach($inspection_answers as $key=>$inspection_answer)
				{
					$question_condition = array("question_id"=>$inspection_answer['question_id']);
					$question = $this->mapi->getRow('question',$question_condition);
					$inspection_answers[$key]['question'] = $question['question'];
					
					$inspection_answer_image_condition = array("inspection_answer_id"=>$inspection_answer['inspection_answer_id']);
					$inspection_answers[$key]['image'] = $this->mapi->getRows('inspection_answer_image',$inspection_answer_image_condition);
				}
			}
			
			if(!empty($inspection_answers)){
				$response=array('status'=>array('error_code'=>0,'message'=>'success'),'result'=>array('inspectionDetails'=>$inspection_answers));
			}else{
				$response=array('status'=>array('error_code'=>0,'message'=>'success'),'result'=>array('inspectionDetails'=>$this->arr));
			}
			
		}else{
      		$response=array('status'=>array('error_code'=>1,'message'=>'Please fill up all required fields'),'result'=>$this->obj);
      	}
      	$this->displayOutput($response);
	}
	
	
	
	private function imageUpload($base64_string,$filename,$path){
    	$ifp = fopen($path.$filename, "wb"); 
    	fwrite($ifp, base64_decode($base64_string)); 
    	fclose($ifp); 
		return true;    
    }
	
	//job List
	public function jobList()
	{
		$ap=json_decode(file_get_contents('php://input'), true);
		
		if(sizeof($ap)){
			
			if(empty($ap['mechanic_id'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'Mechanic field is required'),'result'=>$this->obj);
              $this->displayOutput($response);
            }
			
			$condition = array("mechanic_id"=>$ap['mechanic_id'],"job_status"=>0);
			$assignjobList = $this->mapi->assignedJob($condition);
			
			$jobList = array();
			
			if(!empty($assignjobList))
			{
				foreach($assignjobList as $key=>$assignjob)
				{
					
					$job_condition = array("job_id"=>$assignjob['job_id']);
					$job = $this->mapi->getRow('job',$job_condition);
					
					//if(!empty($job)){
					
					
						$services = $this->mapi->getServices($assignjob['job_id']);	

						$service_date_condition = array("job_id"=>$assignjob['job_id']);
						$job_service_date = $this->mapi->getRow("job_service_date",$service_date_condition);
								
						
						$car_condition = array("car_id"=>$assignjob['car_id']);
						$car = $this->mapi->getRow('car',$car_condition);
						
						$assigned_by_condition = array("admin_id"=>$assignjob['created_by']);
						$assigned_by = $this->mapi->getRow('admins',$assigned_by_condition);
						
						//$service = explode(',',$job['service']);
						$jobList[$key]['job_id'] = $assignjob['job_id'];
						$jobList[$key]['service_date'] = $job_service_date['service_date'];
						$jobList[$key]['company_name'] = $car['company_name'];
						$jobList[$key]['car_no'] = $car['car_no'];
						$jobList[$key]['assigned_by'] = $assigned_by['name'];
						$jobList[$key]['service_count'] = sizeof($services);
					//}					
				}
			}			
			
			
			if(!empty($jobList)){
				$response=array('status'=>array('error_code'=>0,'message'=>'success'),'result'=>array('list'=>$jobList));
			}else{
				$response=array('status'=>array('error_code'=>0,'message'=>'success'),'result'=>array('list'=>$this->arr));
			}		
		
		}else{
      		$response=array('status'=>array('error_code'=>1,'message'=>'Please fill up all required fields'),'result'=>$this->obj);
      	}
      	$this->displayOutput($response);
	}
	
	//Job Details
	public function jobDetails()
	{
		$ap=json_decode(file_get_contents('php://input'), true);
		
		if(sizeof($ap)){
			if(empty($ap['job_id'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'Job Id field is required'),'result'=>$this->obj);
              $this->displayOutput($response);
            }
			
			$condition = array("job_id"=>$ap['job_id']);
			$jobDetails = $this->mapi->getRow('job',$condition);
			
			if(!empty($jobDetails))
			{	
				$services = $this->mapi->getServices($jobDetails['job_id']);
				
				$jobDetails['service'] = $services;
				
				$service_date_condition = array("job_id"=>$jobDetails['job_id']);
				$job_service_date = $this->mapi->getRow("job_service_date",$service_date_condition);
				
				$jobDetails['service_date'] = $job_service_date['service_date'];
				
				$carCondition = array("car_id"=>$jobDetails['car_id']);
				$other_details = $this->mapi->getRow('car',$carCondition);
				
				$assigned_by_condition = array("admin_id"=>$jobDetails['created_by']);
				$assigned_by = $this->mapi->getRow('admins',$assigned_by_condition);
				$jobDetails['assigned_by'] = $assigned_by['name'];
				$jobDetails['car'] = $other_details['car_no'];				
				
				$jobDetails['other_details'] = $other_details;
			}
			
			if(!empty($jobDetails))
			{
				$response=array('status'=>array('error_code'=>0,'message'=>'Success'),'result'=>array('jobDetails'=>$jobDetails));
			}else{
				$response=array('status'=>array('error_code'=>0,'message'=>'Success'),'result'=>array('jobDetails'=>$this->obj));
			}
		
		}else{
      		$response=array('status'=>array('error_code'=>1,'message'=>'Please fill up all required fields'),'result'=>$this->obj);
      	}
      	$this->displayOutput($response);
	}
	
	//Accept or deny job By Mechanic
	
	public function acceptOrDenyJob()
	{
		$ap=json_decode(file_get_contents('php://input'), true);
		
		if(sizeof($ap)){
			if(empty($ap['mechanic_id'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'Mechanic field is required'),'result'=>$this->obj);
              $this->displayOutput($response);
            }
			
			if(empty($ap['job_id'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'Mechanic field is required'),'result'=>$this->obj);
              $this->displayOutput($response);
            }
			
			if(!isset($ap['assign_status'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'Assign Status field is required'),'result'=>$this->obj);
              $this->displayOutput($response);
            }		
			
			
			
			$assignJobCondition = array("mechanic_id"=>$ap['mechanic_id'],"job_id"=>$ap['job_id']);			
			$assignedJob = $this->mapi->getRow('assign_job',$assignJobCondition);
			
			if(!empty($assignedJob))
			{			
				$data['assign_status'] = $ap['assign_status'];
				$data['remarks'] = $ap['remarks'];
				$this->mapi->update('assign_job',$assignJobCondition,$data);
				
				if($ap['assign_status'] == 1)
				{
					$job_condition = array("job_id"=>$ap['job_id']);
					$job_data['job_status'] = 1;
					$this->mapi->update('job',$job_condition,$job_data);
					
				}
				if($ap['assign_status'] == 1){
					$response=array('status'=>array('error_code'=>0,'message'=>'Job successfully accepted by you'),'result'=>array('details'=>$this->obj));
				}else{
					$response=array('status'=>array('error_code'=>0,'message'=>'You rejected this job'),'result'=>array('details'=>$this->obj));
				}
				
			}else{
				$response=array('status'=>array('error_code'=>1,'message'=>'Job Does Not Exsits'),'result'=>array('details'=>$this->obj));
			}
			
			
		}else{
      		$response=array('status'=>array('error_code'=>1,'message'=>'Please fill up all required fields'),'result'=>$this->obj);
      	}
      	$this->displayOutput($response);
	}
	
	//On Going Job List
	/*public function onGoingJob()
	{
		$ap=json_decode(file_get_contents('php://input'), true);
		
		if(sizeof($ap)){
			
			if(empty($ap['mechanic_id'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'Mechanic field is required'),'result'=>$this->obj);
              $this->displayOutput($response);
            }
			
			$condition = array("mechanic_id"=>$ap['mechanic_id'],"job_status"=>1,"assign_status"=>1);			
			$ongoingjob = $this->mapi->onGoiningJobList($condition);			
			

			
				
				$services = $this->mapi->getServices($ongoingjob['job_id']);				
				
				
				foreach($services as $key1=>$service)				
				{
					$task_condition = array("service_id"=>$service['service_id'],"status"=>1);
					$task = $this->mapi->getRows('task',$task_condition);
					$services[$key1]['task'] = $task;
					
				}
				
				
				$ongoingjob['service'] = $services;
				
				$image_condition = array("job_id"=>$ongoingjob['job_id']);
				
				$images = $this->mapi->getRows('job_images',$image_condition);
				
				//print_r($images);
				
				$ongoingjob['images'] = $images;
				
				
				$car_condition = array("car_id"=>$ongoingjob['car_id']);
				$car = $this->mapi->getRow('car',$car_condition);
				
				$ongoingjob['car'] = $car['car_no'];		
			
			}
			
			
			
			if(!empty($ongoingjob)){
				$response=array('status'=>array('error_code'=>0,'message'=>'success'),'result'=>array('list'=>$ongoingjob));
			}else{
				$response=array('status'=>array('error_code'=>0,'message'=>'success'),'result'=>array('list'=>$this->arr));
			}
			
			
			
		}else{
      		$response=array('status'=>array('error_code'=>1,'message'=>'Please fill up all required fields'),'result'=>$this->obj);
      	}
      	$this->displayOutput($response);
	}*/
	
	//On Going Job List
	public function onGoingJob()
	{
		$ap=json_decode(file_get_contents('php://input'), true);
		
		if(sizeof($ap)){
			
			if(empty($ap['mechanic_id'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'Mechanic field is required'),'result'=>$this->obj);
              $this->displayOutput($response);
            }
			
			$condition = array("mechanic_id"=>$ap['mechanic_id'],"job_status"=>1,"assign_status"=>1);			
			$ongoingjob = $this->mapi->onGoiningJobList($condition);
			
			$full_service_condition =array();
			$full_services = $this->mapi->getRows('service',$full_service_condition);		
			
			
			if(!empty($ongoingjob)){
			/*foreach($ongoingjobList as $key=>$ongoingjob)
			{*/
				
				$services = $this->mapi->getServices($ongoingjob['job_id']);

				$new_selected_service = array();
				
				foreach($services as $select_service)
				{
					$new_selected_service[] = $select_service['service_id'];
				}
				
				
				foreach($full_services as $key1=>$service)				
				{
					$task_condition = array("service_id"=>$service['service_id'],"status"=>1);
					
					if(in_array($service['service_id'],$new_selected_service))
					{
						$full_services[$key1]['is_active'] = 1;
					}else{
						$full_services[$key1]['is_active'] = 0;
					}
					$task = $this->mapi->getRows('task',$task_condition);
					$full_services[$key1]['task'] = $task;
					
				}
				
				
				$ongoingjob['service'] = $full_services;
				
				$image_condition = array("job_id"=>$ongoingjob['job_id']);
				
				$images = $this->mapi->getRows('job_images',$image_condition);
				
				//print_r($images);
				
				$ongoingjob['images'] = $images;
				
				
				$car_condition = array("car_id"=>$ongoingjob['car_id']);
				$car = $this->mapi->getRow('car',$car_condition);
				
				$ongoingjob['car'] = $car['car_no'];		
			
			}
			
			
			
			
			
			if(!empty($ongoingjob)){
				$response=array('status'=>array('error_code'=>0,'message'=>'success'),'result'=>array('list'=>$ongoingjob));
			}else{
				$response=array('status'=>array('error_code'=>0,'message'=>'success'),'result'=>array('list'=>$this->arr));
			}
			
			
			
		}else{
      		$response=array('status'=>array('error_code'=>1,'message'=>'Please fill up all required fields'),'result'=>$this->obj);
      	}
      	$this->displayOutput($response);
	}
	
	//Apply Task under service
	public function applyTaskUnderService()
	{
		$ap=json_decode(file_get_contents('php://input'), true);
		
		if(sizeof($ap)){
			
			if(empty($ap['task'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'Task Ids field is required'),'result'=>$this->obj);
              $this->displayOutput($response);
            }
			
			if(empty($ap['job_id'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'job Id field is required'),'result'=>$this->obj);
              $this->displayOutput($response);
            }			
			
			$tasks = $ap['task'];
			
			$data  = array();
			
			$mechanic_job_task_condition = array("job_id"=>$ap['job_id']);
			$this->mapi->delete('mechanic_job_task',$mechanic_job_task_condition);
			
			$service_ids = array();
			
			foreach($tasks as $key=>$task)
			{
				$task_ids = explode(',',$task['task_id']);				
				
				foreach($task_ids as $key1=>$task_id)
				{
					$data['service_id'] = $task['service_id'];
					$data['task_id'] = $task_id;	
					$data['job_id'] = $ap['job_id'];
					$this->mapi->insert('mechanic_job_task',$data);				
					
				}

				$service_ids[$key]['service_id'] = $task['service_id'];
				$service_ids[$key]['additional_note'] = $task['additional_note'];
				
			}
			
			
			
			$job_services_condition = array("job_id"=>$ap['job_id']);	
			$this->mapi->delete('job_services',$job_services_condition);
			
			foreach($service_ids as $service_id){			
				$additional_data['job_id'] = $ap['job_id'];
				$additional_data['additional_note'] = $service_id['additional_note'];
				$additional_data['service_id'] = $service_id['service_id'];
				$this->mapi->insert('job_services',$additional_data);
			
			}
			
			if(!empty($ap['km_reading']))
			{
				$udata['km_reading'] = $ap['km_reading'];
			}else{
				$udata['km_reading'] = "";
			}	

			
			if(!empty($ap['job_additional_note']))
			{
				$udata['additional_note'] = $ap['job_additional_note'];
			}else{
				$udata['additional_note'] = "";
			}
			
			$udata['job_status'] = 2;
			
			
			
			//$this->mapi->batch_insert('mechanic_job_task',$data);
			
			$condition = array("job_id"=>$ap['job_id']);
			$this->mapi->update('job',$condition,$udata);		
			
			$servic_date_data['service_end_date'] = date('Y-m-d');
			$servic_date_data['service_end_time'] = date('H:i:s');
			$this->mapi->update('job_service_date',$condition,$servic_date_data);
			
			$response=array('status'=>array('error_code'=>0,'message'=>'Task Applied successfully'),'result'=>$this->obj);
			
			
			
		}else{
      		$response=array('status'=>array('error_code'=>1,'message'=>'Please fill up all required fields'),'result'=>$this->obj);
      	}
      	$this->displayOutput($response);
	}
	
	
	//Save Multiple Images
	public function saveMultipleImage()
	{
		if(isset($_POST)){
			$job_id = $this->input->post('job_id');
			
			if(empty($job_id)){
              $response=array('status'=>array('error_code'=>1,'message'=>'Job Id field is required'),'result'=>array('result'=>$this->obj));
              $this->displayOutput($response);
            }
			
			$file_ary = $this->reArrayFiles($_FILES['imgInp']);
			foreach($file_ary as $key=>$file)
			{
				$file_name = time()."_".$file['name'];	
				$image_path = './public/admin_assets/images/job/'.$file_name;
				move_uploaded_file($file['tmp_name'],$image_path);
				$udata['image'] = $file_name;
				$udata['job_id'] = $job_id ;										
				$this->mapi->insert('job_images',$udata);
			}
			
			$response=array('status'=>array('error_code'=>0,'message'=>'Image Saved successfully'),'result'=>$this->obj);
			
		}else{
			$response=array('status'=>array('error_code'=>1,'message'=>'Please fill up all required fields'),'result'=>$this->obj);
		}
		$this->displayOutput($response);
	}
	
	//Job History
	public function jobHistory()
	{
		$ap=json_decode(file_get_contents('php://input'), true);
		
		if(sizeof($ap)){			
			if(empty($ap['mechanic_id'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'Mechanic field is required'),'result'=>$this->obj);
              $this->displayOutput($response);
            }
			
			$condition = array("mechanic_id"=>$ap['mechanic_id'],"assign_status"=>1);
			$assignjobList = $this->mapi->getRows('assign_job',$condition);			
			
			$jobList = array();
			
			if(!empty($assignjobList))
			{
				foreach($assignjobList as $key=>$assignjob)
				{
					$job_condition = array("job_id"=>$assignjob['job_id'],"job_status"=>2);
					$job = $this->mapi->getRow('job',$job_condition);
					
					
					$services = $this->mapi->getServices($assignjob['job_id']);	

					$service_date_condition = array("job_id"=>$assignjob['job_id']);
					$job_service_date = $this->mapi->getRow("job_service_date",$service_date_condition);							
					
					$car_condition = array("car_id"=>$job['car_id']);
					$car = $this->mapi->getRow('car',$car_condition);
					
					$assigned_by_condition = array("admin_id"=>$job['created_by']);
					$assigned_by = $this->mapi->getRow('admins',$assigned_by_condition);
					
					//$service = explode(',',$job['service']);
					$jobList[$key]['job_id'] = $assignjob['job_id'];
					$jobList[$key]['service_end_date'] = $job_service_date['service_end_date'];	
					$jobList[$key]['service_end_time'] = $job_service_date['service_end_time'];
					$jobList[$key]['car_no'] = $car['car_no'];					
					$jobList[$key]['service_count'] = sizeof($services);
				}
			}
			
			if(!empty($jobList)){
				$response=array('status'=>array('error_code'=>0,'message'=>'success'),'result'=>array('list'=>$jobList));
			}else{
				$response=array('status'=>array('error_code'=>0,'message'=>'success'),'result'=>array('list'=>$this->arr));
			}
			
		}else{
      		$response=array('status'=>array('error_code'=>1,'message'=>'Please fill up all required fields'),'result'=>$this->obj);
      	}
      	$this->displayOutput($response);
	}
	
	//Search Job History
	public function serachJobHistory()
	{
		$ap=json_decode(file_get_contents('php://input'), true);
		
		if(sizeof($ap)){
			
			if(empty($ap['mechanic_id'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'Mechanic field is required'),'result'=>$this->obj);
              $this->displayOutput($response);
            }
			
			
			if(empty($ap['car_no'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'Car Id field is required'),'result'=>$this->obj);
              $this->displayOutput($response);
            }
			
			if(empty($ap['start_date'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'Start Date field is required'),'result'=>$this->obj);
              $this->displayOutput($response);
            }
			
			if(empty($ap['end_date'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'Start Date field is required'),'result'=>$this->obj);
              $this->displayOutput($response);
            }
			
			$car_information_condition = array("car_no"=>$ap['car_no']);
			$car_information = $this->mapi->getRow('car',$car_information_condition);
			
			//$condition = array("mechanic_id"=>$ap['mechanic_id'],"assign_job.assign_status"=>1,
			//"job.car_id"=>$car_information['car_id'],"service_end_date>="=>$ap['start_date'],"service_end_date>="=>$ap['end_date']);
			$assignjobList = $this->mapi->searchJobHistory($ap['mechanic_id'],$car_information['car_id'],$ap['start_date'],$ap['end_date']);	
			
			$jobList = array();

			if(!empty($assignjobList))
			{
				foreach($assignjobList as $key=>$assignjob)
				{
					$job_condition = array("job_id"=>$assignjob['job_id'],"job_status"=>2);
					$job = $this->mapi->getRow('job',$job_condition);
					
					
					$services = $this->mapi->getServices($assignjob['job_id']);										
					
					$car_condition = array("car_id"=>$assignjob['car_id']);
					$car = $this->mapi->getRow('car',$car_condition);
					
					$assigned_by_condition = array("admin_id"=>$job['created_by']);
					$assigned_by = $this->mapi->getRow('admins',$assigned_by_condition);					
					
					$jobList[$key]['job_id'] = $assignjob['job_id'];
					$jobList[$key]['service_end_date'] = $assignjob['service_end_date'];	
					$jobList[$key]['service_end_time'] = $assignjob['service_end_time'];
					$jobList[$key]['car_no'] = $car['car_no'];					
					$jobList[$key]['service_count'] = sizeof($services);
				}
			}
			
			if(!empty($jobList)){
				$response=array('status'=>array('error_code'=>0,'message'=>'success'),'result'=>array('list'=>$jobList));
			}else{
				$response=array('status'=>array('error_code'=>0,'message'=>'success'),'result'=>array('list'=>$this->arr));
			}
			
		
		}else{
      		$response=array('status'=>array('error_code'=>1,'message'=>'Please fill up all required fields'),'result'=>$this->obj);
      	}
      	$this->displayOutput($response);
	}
	
	public function jobHistoryDetails()
	{
		$ap=json_decode(file_get_contents('php://input'), true);
		
		if(sizeof($ap)){
			
			if(empty($ap['job_id'])){
              $response=array('status'=>array('error_code'=>1,'message'=>'Job Id field is required'),'result'=>$this->obj);
              $this->displayOutput($response);
            }
			
			$finalJobHistoryDetails = array();
			$condition = array("job_id"=>$ap['job_id']);
			$jobDetails = $this->mapi->getRow('job',$condition);
			
			
			$carCondition = array("car_id"=>$jobDetails['car_id']);
			$carDetails = $this->mapi->getRow('car',$carCondition);
			
			$finalJobHistoryDetails['km_reading'] = $jobDetails['km_reading'];
			$finalJobHistoryDetails['additional_note'] = $jobDetails['additional_note'];
			
			$finalJobHistoryDetails['car_no'] = $carDetails['car_no'];
			$finalJobHistoryDetails['company_name'] = $carDetails['company_name'];	
			
			
				
			$jobhistoryDetails = $this->mapi->jobHostoryDetails($ap['job_id']);			
			
			
			$newjobhistoryDetailsarrays = array();
			foreach($jobhistoryDetails as $key_d=>$jobhistoryDetail)
			{				
				$newjobhistoryDetailsarrays[] = $jobhistoryDetail['service_id'];
			}
			
			
			
			
			$newJobHistoryDetails = array();
			
			//print_r(array_values(array_unique($newjobhistoryDetailsarrays)));exit;
			
			foreach(array_values(array_unique($newjobhistoryDetailsarrays)) as $key=>$newjobhistoryDetailsarray)
			{
				$newJobHistoryDetails[$key]['service_id'] = $newjobhistoryDetailsarray;
				
				$service_condition = array('service_id'=>$newjobhistoryDetailsarray);
				$service = $this->mapi->getRow('service',$service_condition);			
				
				$newJobHistoryDetails[$key]['service_name'] = $service['service_name'];
				
				$jobhistoryDetails = $this->mapi->jobHostoryDetailswithServiceId($ap['job_id'],$newjobhistoryDetailsarray);	
				
				//$newJobHistoryDetails[$key]['service_name'] = $jobhistoryDetails['service_name'];
				
				foreach( $jobhistoryDetails as  $key1=>$jobhistoryDetail)
				{
					$task_condition = array('task_id'=>$jobhistoryDetail['task_id']);
					$task = $this->mapi->getRow('task',$task_condition);
					$newJobHistoryDetails[$key]['task'][$key1] = $task;
				}
				
				
				$additional_note_condition = array("service_id"=>$newjobhistoryDetailsarray,"job_id"=>$ap['job_id']);
				$additional_note = $this->mapi->getRow('job_services',$additional_note_condition);
				$newJobHistoryDetails[$key]['additional_note'] = $additional_note['additional_note'];
			
			}		
			
						
			
			$finalJobHistoryDetails['services'] = $newJobHistoryDetails;
			
			$jobImages = $this->mapi->getRows('job_images',$condition);
			$finalJobHistoryDetails['images'] = $jobImages;
			
			if(!empty($finalJobHistoryDetails))
			{
				$response=array('status'=>array('error_code'=>0,'message'=>'Success'),'result'=>array('jobHistoryDetails'=>$finalJobHistoryDetails));
			}else{
				$response=array('status'=>array('error_code'=>0,'message'=>'Success'),'result'=>array('jobHistoryDetails'=>$this->obj));
			}		
			
			
		}else{
      		$response=array('status'=>array('error_code'=>1,'message'=>'Please fill up all required fields'),'result'=>$this->obj);
      	}
      	$this->displayOutput($response);
	}
	
	private function reArrayFiles(&$file_post) {

		$file_ary = array();
		$file_count = count($file_post['name']);
		$file_keys = array_keys($file_post);

		for ($i=0; $i<$file_count; $i++) {
			foreach ($file_keys as $key) {
				$file_ary[$i][$key] = $file_post[$key][$i];
			}
		}

		return $file_ary;
	}
	
	
	
	
	private function sendMail($data){
		$config['protocol']    	= 'smtp';
        $config['protocol']      = 'smtp';
        $config['smtp_host']     = 'ssl://mail.fitser.com';
        $config['smtp_port']     = '465';  
        $config['smtp_user']     = 'test123@fitser.com';
        $config['smtp_pass']     = 'Test123@';
        $config['charset']    	= 'utf-8';
        $config['newline']    	= "\r\n";
        $config['mailtype'] 	= 'html';
        $config['validation'] 	= TRUE;   

        $this->email->initialize($config);

        $this->email->set_crlf( "\r\n" );

        $this->email->from('info@punjabmotorworkshop.com', 'Punjab Motor Work Shop');
        $this->email->to($data['to']); 

        $this->email->subject($data['subject']);
        $this->email->message($data['message']);  

        $this->email->send();
		return true;   	
    } 
	
}
