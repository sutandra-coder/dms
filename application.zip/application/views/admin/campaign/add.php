 <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
 <script src="<?php echo base_url()?>/public/validation/js/jquery.validate.js"></script>
<!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h3>
            Campaign Settings
            
          </h3>         
        </section>

        <!-- Main content -->
        <section class="content"> 
			<div class="row">
				<!-- general form elements -->
				<div class="col-md-12">
					  <div class="box box-primary">						 
						<div class="box-header with-border">
						 <div class="admin-tab-wrapper">
							<div class="admin_tab">
								<!--<button class="btn btn-primary dropdown-toggle btn-algnmt" type="button" data-toggle="dropdown">Action
								<span class="caret"></span></button>-->
								<ul>
									<li><a href="javascript:void(0);" onclick="window.history.back();">Back</a></li>
								</ul>
							</div>
						</div>
						  <h3 class="box-title"></h3>
						  <?php if($this->session->flashdata('error_msg')){?>
								<span style="color:red; font-weight:bold"><?php echo $this->session->flashdata('error_msg');?></span>
							<?php }?>
							<?php if($this->session->flashdata('success_msg')){?>
								<span style="color:green; font-weight:bold"><?php  echo $this->session->flashdata('success_msg'); ?></span>
							<?php }?>
						</div>
						<!-- /.box-header -->
						<!-- form start -->
						<form id="signupForm" role="form" class="mtbresize" method="post" action="<?php echo base_url('admin/campaign/add_content');?>" enctype="multipart/form-data" autocomplete="off">
						  <div class="box-body">
							<div class="form-group">
							  <label for="campaign_name">Campaign Name<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="campaign_name" name="campaign_name" value="<?php echo set_value('campaign_name');?>" placeholder="Campaign Name" required="required">
							  <?php echo form_error('campaign_name','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-check">
								<input type="checkbox" class="form-check-input" id="sms_check" name="sms_check" value="1">
								<label class="form-check-label" for="exampleCheck1">sms</label>
							</div>
							
							<div id="sms_content_box">
								<div class="form-group">
								  <label for="sms_content">Sms Content:</label>
								  <textarea class="form-control" rows="5" id="sms_content" name="sms_content"></textarea>
								</div>
							</div>
							<div class="form-check">
								<input type="checkbox" class="form-check-input" id="email_check" name="email_check" value="1">
								<label class="form-check-label" for="exampleCheck1">email</label>
							</div>
							<div id="email_content_box">
								<div class="form-group">
								  <label for="imgInp"> Email Image</label>
								  <input id="imgInp" type="file" name="imgInpemail">							  
								</div>
								<div class="form-group">
								  <label for="email_content">Email Content:</label>
								  <textarea class="form-control" rows="5" id="email_content" name="email_content"></textarea>
								</div>
							</div>
							<div class="form-check">
								<input type="checkbox" class="form-check-input" id="push_check" name="push_check" value="1">
								<label class="form-check-label" for="exampleCheck1">App Notification</label>
							</div>
							<div id="push_content_box">
								<div class="form-group">
								  <label for="imgInp"> App Notification Image</label>
								  <input id="imgInp" type="file" name="imgInpapp">							  
								</div>
								<div class="form-group">
								  <label for="appnotification_content">App Notification Content:</label>
								  <textarea class="form-control" rows="5" id="appnotification_content" name="appnotification_content"></textarea>
								</div>
							</div>
							<div class="form-check">
								<input type="checkbox" class="form-check-input" id="whatsapp_check">
								<label class="form-check-label" for="exampleCheck1">whatsapp</label>
							</div>
							<div id="whatsapp_content_box">
								<div class="form-group">
								  <label for="imgInp"> whatsapp Notification Image</label>
								  <input id="imgInp" type="file" name="imgInp" disabled="true">							  
								</div>
								<div class="form-group">
								  <label for="appnotification_content">whatsapp Notification Content:</label>
								  <textarea class="form-control" rows="5" id="appnotification_content" disabled="true"></textarea>
								</div>
							</div>
						  </div>
						  <!-- /.box-body -->
						  <div class="box-footer">							
							<button type="submit" class="btn btn-sm btn-primary">Submit</button>
						  </div>
						</form>
					  </div>
				</div>
          <!-- /.box -->
          </div><!-- /.row -->	
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-show-password/1.0.3/bootstrap-show-password.min.js"></script>
<script>
$( "#signupForm" ).validate( {
					rules: {
						campaign_name: "required"
					},
					messages: {						
						campaign_name: {required:"Campaign Name field is required"}
					},
					errorElement: "em",
					
					highlight: function ( element, errorClass, validClass ) {
						$( element ).parents( ".form-control" ).addClass( "has-error" ).removeClass( "has-success" );
					},
					unhighlight: function (element, errorClass, validClass) {
						$( element ).parents( ".form-control" ).addClass( "has-success" ).removeClass( "has-error" );
					}
				} );


$('#sms_check').click(function(){
    if($(this).prop("checked") == true){
		$("#sms_content_box").show();
    }else{
		$("#sms_content_box").hide();
	}
});

$('#email_check').click(function(){
    if($(this).prop("checked") == true){
		$("#email_content_box").show();
    }else{
		$("#email_content_box").hide();
	}
});

$('#push_check').click(function(){
    if($(this).prop("checked") == true){
		$("#push_content_box").show();
    }else{
		$("#push_content_box").hide();
	}
});

$('#whatsapp_check').click(function(){
    if($(this).prop("checked") == true){
		$("#whatsapp_content_box").show();
    }else{
		$("#whatsapp_content_box").hide();
	}
});


$( document ).ready(function() {
    $("#sms_content_box").hide();
	$("#email_content_box").hide();
	$("#push_content_box").hide();
	$("#whatsapp_content_box").hide();
});
</script>