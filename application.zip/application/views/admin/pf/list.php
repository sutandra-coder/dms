<style>
.cstm_view{font-size:15px;}
</style>
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
          <h3>
            Uploading Track List
            
          </h3>
          <!--<ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>-->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box box-primary">
            <div class="box-header with-border">
			<div class="admin_tab">
			<ul>
				<li><a href="javascript:void(0);" onclick="window.history.back();">Back</a></li>	
				<li><a href="<?php echo base_url();?>admin/pfdms/add">Add</a></li>	
			</ul>
			
				 
							
							<?php if($this->session->flashdata('error_msg')){?>
								<span style="color:red; font-weight:bold"><?php echo $this->session->flashdata('error_msg');?></span>
							<?php }?>
							<?php if($this->session->flashdata('success_msg')){?>
								<span style="color:green; font-weight:bold"><?php  echo $this->session->flashdata('success_msg'); ?></span>
							<?php }?>
				<div class="row" >
					<form action="<?php echo base_url();?>admin/pfdms" method="post">
						<div class='col-sm-2'>
							<div class="form-group">
							 <label>From Date</label>
								<div class='input-group date'>
									<input type='text' class="form-control" placeholder="Start Date" value="<?php echo $start_date;?>" id="start_date" name="start_date"/>
									<span class="input-group-addon">
										<span class="glyphicon glyphicon-calendar"></span>
									</span>
								</div>
							</div>
						</div>
						<div class='col-sm-2'>
							<div class="form-group">
							 <label>To Date</label>
								<div class='input-group date'>
									<input type='text' class="form-control" placeholder="End Date" value="<?php echo $end_date;?>" id="end_date" name="end_date"/>
									<span class="input-group-addon">
										<span class="glyphicon glyphicon-calendar"></span>
									</span>
								</div>
							</div>
						</div>	
						<div class='col-sm-2'>	
							<div class="form-group">
									<label>Content Type</label>
									<select class="form-control" id="content_type" name="content_type" >
										<option value="" <?php if($content_type == ''){echo "selected";}?>>Select</option>									
										<option value="challan" <?php if($content_type == 'challan'){echo "selected";}?>>Challan</option>	
										<option value="payment" <?php if($content_type == 'payment'){echo "selected";}?>>Payment</option>
									</select>							
							</div>
						</div>
						<div class='col-sm-2'>
							<div class="form-group">
								<label></label>
								<button class="form-control btn-primary" id="btn_filter">Search</button>
							</div>
						</div>	
					</form>
				</div>	
			</div>			 
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example" class="table table-bordered table-striped">
                <thead>
                <tr>
				  <th class="no-sort">Sl. NO.</th>
				  <th class="no-sort">Request No</th>	
				  <th class="no-sort">Uploading File Count</th>	
				  <th class="no-sort">File Type</th>
				  <th class="no-sort">Content Type</th>
				  <th class="no-sort">Uploading Timestamp</th>		
				  <th class="no-sort">View</th>
				  <th class="no-sort">Delete</th>
                </tr>
                </thead> 
				<tbody>
					<?php $i=1; foreach($post_data as $row){ ?>
					<tr>
						<td class="text-center">
                          <?php echo $i;?>
                        </td> 
						<td class="text-center">
                          <?php echo $row['request_no'] ;?>
                        </td>
						<td class="text-center">
                          <?php echo $row['uploading_file_count'] ;?>
                        </td> 
						<td class="text-center">
                          <?php echo $row['file_type'];?>
                        </td>
						<td class="text-center">
                          <?php echo $row['content_type'];?>
                        </td>
						<td class="text-center">
                          <?php echo $row['last_update_ts'];?>
                        </td>
						<td class="text-center">							
							<a href="<?php echo base_url('admin/pfdms/uploading_track_details_list/'.$row['request_no']); ?>" ><span class="glyphicon glyphicon-eye-open"></span></a>
						</td>
						<td class="text-center">
							<a href="javascript:void(0)" title="<?php echo $row['request_no'];?>" class="cstm_view" id="delete_uploading_track"><span class="glyphicon glyphicon-minus"></span></a>
						</td>
					</tr>
					<?php $i++;} ?>
				</tbody>
                <tfoot>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>

<script src="<?php echo base_url()?>public/admin_assets/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url()?>public/admin_assets/plugins/datatables/dataTables.bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>
<script>
/*$(document).ready(function() {
    $('#example').DataTable( {
        "processing": true,
        "serverSide": true,
        "ajax": {
            "url": "<?php echo base_url('admin/metakey/all_content_list');?>",
            "type": "POST"
        },
        //Set column definition initialisation properties.
        "columnDefs": [
        { 
            "targets": 'no-sort', //1st and last column
            "orderable": false, //set not orderable
        },
        ],
    } );
	
	var dtable = $("#example").dataTable().api();
	
	$(".dataTables_filter input")
    .unbind() // Unbind previous default bindings
    .bind("input", function(e) { // Bind our desired behavior
        // If the length is 3 or more characters, or the user pressed ENTER, search
        if(this.value.length >= 3 || e.keyCode == 13) {
            // Call the API search function
            dtable.search(this.value).draw();
        }
        // Ensure we clear the search if they backspace far enough
        if(this.value == "") {
            dtable.search("").draw();
        }
        return;
    });
} );*/

var  table = $('#example').dataTable({
    'bLengthChange': false,
    'searching': true,
    'paging':   true,  // Table pagination
    'ordering': false,  // Column ordering
    'info':     true,  // Bottom left status text
    'responsive': true, // https://datatables.net/extensions/responsive/examples/
    // Text translation options
    // Note the required keywords between underscores (e.g _MENU_)
    oLanguage: {
        // sSearch:      'Search all columns:',
        sLengthMenu:  '_MENU_ records per page',
        info:         'Showing page _PAGE_ of _PAGES_',
        zeroRecords:  'Nothing found - sorry',
        infoEmpty:    'No records available',
        infoFiltered: '(filtered from _MAX_ total records)'
    },
    // set columns options
    'aoColumns': [
    {'bVisible':true},
    {'bVisible':true},
    {'bVisible':true},
	{'bVisible':true},
	{'bVisible':true},
	{'bVisible':true},
	{'bVisible':true},
	{'bVisible':true}
    ]
  });
  
 	$(document).on( "click",'#delete_uploading_track.cstm_view',function() {
		var request_no=$(this).prop('title');				
		$.ajax({
			  type:'POST',
			  url :'<?php echo base_url('admin/dms/delete_uploading_track');?>',
			   data:'request_no='+request_no,
			  dataType:'json',
			  success:function(result){
				window.location.reload('<?php echo base_url('admin/ptaxdms'); ?>');
			},error:function(){

			}
		});
	});
	
	$('#start_date').datepicker({
	maxDate: '0',
	format: 'yyyy-mm-dd',
	setDate: new Date()
});
	
$('#end_date').datepicker({
	maxDate: '0',
	format: 'yyyy-mm-dd',
	setDate: new Date()
});  
	
</script>
