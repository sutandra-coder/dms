 <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
 <script src="<?php echo base_url()?>/public/validation/js/jquery.validate.js"></script>
<!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h3>
            PF Challan Data
            
          </h3>         
        </section>

        <!-- Main content -->
        <section class="content"> 
			<div class="row">
				<div class="col-md-6">										
					<div class="embed-responsive embed-responsive-4by3">
						<iframe class="embed-responsive-item" src="<?php echo base_url()."/public/images/".$uploadig_file_name; ?>" allowfullscreen></iframe>
					</div>
				</div>
				<!-- general form elements -->
				<div class="col-md-6">
					  <div class="box box-primary ex1">						 
						<div class="box-header with-border">						
						  <h3 class="box-title"></h3>
						  <?php if($this->session->flashdata('error_msg')){?>
								<span style="color:red; font-weight:bold"><?php echo $this->session->flashdata('error_msg');?></span>
							<?php }?>
							<?php if($this->session->flashdata('success_msg')){?>
								<span style="color:green; font-weight:bold"><?php  echo $this->session->flashdata('success_msg'); ?></span>
							<?php }?>
						</div>
						<!-- /.box-header -->
						<!-- form start -->
						<form id="signupForm" role="form" class="mtbresize" method="post" action="<?php echo base_url()."admin/pfdms/pf_challan_data_update"; ?>" enctype="multipart/form-data" autocomplete="off">
						  <div class="box-body">							
							<div class="form-group">
							  <label for="trn">TRN<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="trn" name="trn" value="<?php echo $cms['trn'];?>" placeholder="trn" required="required">
							  <?php echo form_error('grn','<span class="error">', '</span>'); ?>
							</div>	
							<div class="form-group">
							  <label for="establishment_code">Establishment Code<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="establishment_code" name="establishment_code" value="<?php echo $cms['establishment_code'];?>" placeholder="Establishment Code" required="required">
							  <?php echo form_error('establishment_code','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="establishment_name">Establishment Name<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="grn_date" name="establishment_name" value="<?php echo $cms['establishment_name'];?>" placeholder="Establishment Name" required="required">
							  <?php echo form_error('establishment_name','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="due_for_the_wages_month_of_data">Due For The Wages Month<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="due_for_the_wages_month_of_data" name="due_for_the_wages_month_of_data" value="<?php echo $cms['due_for_the_wages_month_of_data'];?>" placeholder="Due For The Wages Month" required="required">
							  <?php echo form_error('due_for_the_wages_month_of_data','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="due_for_the_wages_year_of_data">Due For The Wages Year<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="due_for_the_wages_year_of_data" name="due_for_the_wages_year_of_data" value="<?php echo $cms['due_for_the_wages_year_of_data'];?>" placeholder="Due For The Wages Year" required="required">
							  <?php echo form_error('brn','<span class="error">', '</span>'); ?>
							</div>
							<table class="table">
							  <thead>
								<tr>
								  <th scope="col"></th>
								  <th scope="col">EPF</th>
								  <th scope="col">EPS</th>
								  <th scope="col">EDLI</th>
								</tr>
							  </thead>
							  <tbody>
								<tr>
								  <th scope="row">Total Subscribers:</th>
								  <td> <input type="text" class="form-control" id="total_subscribers_epf" name="total_subscribers_epf" value="<?php echo $cms['total_subscribers_epf'];?>" placeholder="Due For The Wages Month" required="required"></td>
								  <td><input type="text" class="form-control" id="total_subscribers_eps" name="total_subscribers_eps" value="<?php echo $cms['total_subscribers_eps'];?>" placeholder="Total Subscribers Eps" required="required"></td>	
								  <td><input type="text" class="form-control" id="total_subscribers_edli" name="total_subscribers_edli" value="<?php echo $cms['total_subscribers_edli'];?>" placeholder="total subscribers Edli" required="required"></td>
								</tr>
								<tr>
								  <th scope="row">Total Wages:</th>
								  <td><input type="text" class="form-control" id="total_wages_epf" name="total_wages_epf" value="<?php echo $cms['total_wages_epf'];?>" placeholder="Total Wages Epf" required="required"></td>
								  <td><input type="text" class="form-control" id="total_wages_eps" name="total_wages_eps" value="<?php echo $cms['total_wages_eps'];?>" placeholder="Total Wages Eps" required="required"></td>	
								  <td><input type="text" class="form-control" id="total_wages_edli" name="total_wages_edli" value="<?php echo $cms['total_wages_edli'];?>" placeholder="Total Wages Edli" required="required"></td>
								</tr>								
							  </tbody>
							</table>
							<table class="table">
							  <thead>
								<tr>
								  <th scope="col">SL.</th>
								  <th scope="col">PARTICULARS</th>
								  <th scope="col">A/C.0.1 (Rs.)</th>
								  <th scope="col">A/C.0.2 (Rs.)</th>
								  <th scope="col">A/C.10 (Rs.)</th>
								  <th scope="col">A/C.21 (Rs.)</th>
								  <th scope="col">A/C.22 (Rs.)</th>
								  <th scope="col">Total</th>
								</tr>
							  </thead>
							  <tbody>
								<tr>
								  <th scope="row">1</th>
								  <td>Administration Charges</td>
								  <td><input type="text" class="form-control" id="administration_charges_ac_01" name="administration_charges_ac_01" value="<?php echo $cms['administration_charges_ac_01'];?>" placeholder="Administration Charges ac 01" required="required"></td>
								  <td><input type="text" class="form-control" id="administration_charges_ac_02" name="administration_charges_ac_02" value="<?php echo $cms['administration_charges_ac_02'];?>" placeholder="Administration Charges Ac 02" required="required"></td>
								  <td><input type="text" class="form-control" id="administration_charges_ac_10" name="administration_charges_ac_10" value="<?php echo $cms['administration_charges_ac_10'];?>" placeholder="Administration charges ac 10" required="required"></td>
								  <td><input type="text" class="form-control" id="administration_charges_ac_21" name="administration_charges_ac_21" value="<?php echo $cms['administration_charges_ac_21'];?>" placeholder="administration_charges_ac_21" required="required"></td>
								  <td><input type="text" class="form-control" id="administration_charges_ac_22" name="administration_charges_ac_22" value="<?php echo $cms['administration_charges_ac_22'];?>" placeholder="Administration_charges_ac_22" required="required"></td>
								  <td><input type="text" class="form-control" id="administration_charges_ac_total" name="administration_charges_ac_total" value="<?php echo $cms['administration_charges_ac_total'];?>" placeholder="administration_charges_ac_total" required="required"></td></td>
								</tr>
								<tr>
								  <th scope="row">2</th>
								  <td>Employer's Share Of</td>
								  <td><input type="text" class="form-control" id="employers_share_of_ac_01" name="employers_share_of_ac_01" value="<?php echo $cms['employers_share_of_ac_01'];?>" placeholder="Employers Share Of ac 01" required="required"></td>
								  <td><input type="text" class="form-control" id="employers_share_of_ac_02" name="employers_share_of_ac_02" value="<?php echo $cms['employers_share_of_ac_02'];?>" placeholder="Employers Share Of ac 02" required="required"></td>
								  <td><input type="text" class="form-control" id="employers_share_of_ac_10" name="employers_share_of_ac_10" value="<?php echo $cms['employers_share_of_ac_10'];?>" placeholder="Employers Share Of Ac 10" required="required"></td>
								  <td><input type="text" class="form-control" id="employers_share_of_ac_21" name="employers_share_of_ac_21" value="<?php echo $cms['employers_share_of_ac_21'];?>" placeholder="Employers Share Of Ac 21" required="required"></td>
								  <td><input type="text" class="form-control" id="employers_share_of_ac_22" name="employers_share_of_ac_22" value="<?php echo $cms['employers_share_of_ac_22'];?>" placeholder="Employers Share Of ac 22" required="required"></td>
								  <td><input type="text" class="form-control" id="employers_share_of_ac_total" name="employers_share_of_ac_total" value="<?php echo $cms['employers_share_of_ac_total'];?>" placeholder="Employers Share Of Ac Total" required="required"></td>
								</tr>
								<tr>
								  <th scope="row">3</th>
								  <td>Employee's Share Of</td>
								  <td><input type="text" class="form-control" id="employees_share_of_ac_01" name="employees_share_of_ac_01" value="<?php echo $cms['employees_share_of_ac_01'];?>" placeholder="Employees Share Of Ac 01" required="required"></td>
								  <td><input type="text" class="form-control" id="employees_share_of_ac_02" name="employees_share_of_ac_02" value="<?php echo $cms['employees_share_of_ac_02'];?>" placeholder="Employees Share of Ac 02" required="required"></td>
								  <td><input type="text" class="form-control" id="employees_share_of_ac_10" name="employees_share_of_ac_10" value="<?php echo $cms['employees_share_of_ac_10'];?>" placeholder="Employees Share of Ac 10" required="required"></td>
								  <td><input type="text" class="form-control" id="employees_share_of_ac_21" name="employees_share_of_ac_21" value="<?php echo $cms['employees_share_of_ac_21'];?>" placeholder="Employees Share of Ac 21" required="required"></td>
								  <td><input type="text" class="form-control" id="employees_share_of_ac_22" name="employees_share_of_ac_22" value="<?php echo $cms['employees_share_of_ac_22'];?>" placeholder="Employees Share of Ac 22" required="required"></td>
								  <td><input type="text" class="form-control" id="employees_share_of_ac_total" name="employees_share_of_ac_total" value="<?php echo $cms['employees_share_of_ac_total'];?>" placeholder="Employees Share Of Ac total" required="required"></td>
								</tr>
								<tr>
								  <th scope="row">Grand Total</th>
								  <td></td>
								  <td></td>
								  <td></td>
								  <td></td>
								  <td></td>
								  <td></td>
								  <td><input type="text" class="form-control" id="grand_total" name="grand_total" value="<?php echo $cms['grand_total'];?>" placeholder="grand_total" required="required"></td>
								</tr>
							  </tbody>
							</table>
							<table class="table">
							  <thead>
								<tr>
								  <th scope="col"></th>
								  <th scope="col">PMRPY</th>
								  <th scope="col">PMGKY</th>								 
								</tr>
							  </thead>
							  <tbody>
								<tr>
								  <th scope="row">A)A/C no 1 (Employer share) ( Rs.) -</th>
								  <td><input type="text" class="form-control" id="ac_no_1_employer_share_rs_pmrpy_data" name="ac_no_1_employer_share_rs_pmrpy_data" value="<?php echo $cms['ac_no_1_employer_share_rs_pmrpy_data'];?>" placeholder="ac no 1 employer share rs pmrpy data" required="required"></td>
								  <td><input type="text" class="form-control" id="ac_no_1_employers_share_rs_pmgky_data" name="ac_no_1_employers_share_rs_pmgky_data" value="<?php echo $cms['ac_no_1_employers_share_rs_pmgky_data'];?>" placeholder="ac no 1 employers share rs pmgky data" required="required"></td>								  
								</tr>
								<tr>
								  <th scope="row">B)A/C no 10 (Pension fund) ( Rs.) -</th>
								  <td><input type="text" class="form-control" id="ac_no_10_Pension_fund_rs_pmrpy_data" name="ac_no_10_Pension_fund_rs_pmrpy_data" value="<?php echo $cms['ac_no_10_Pension_fund_rs_pmrpy_data'];?>" placeholder="ac no 10 Pension fund rs pmrpy data" required="required"></td>
								  <td><input type="text" class="form-control" id="ac_no_10_Pension_fund_rs_pmgky_data" name="ac_no_10_Pension_fund_rs_pmgky_data" value="<?php echo $cms['ac_no_10_Pension_fund_rs_pmgky_data'];?>" placeholder="ac no 10 Pension fund rs pmgky data" required="required"></td>
								</tr>		
								<tr>
								  <th scope="row">C)A/C no 1 (Employee share) ( Rs.) -</th>
								   <td><input type="text" class="form-control" id="ac_no_1_employee_share_rs_pmrpy_data" name="ac_no_1_employee_share_rs_pmrpy_data" value="<?php echo $cms['ac_no_1_employee_share_rs_pmrpy_data'];?>" placeholder="Ac No 1 Employee Share rs pmrpy data" required="required"></td>
								  <td><input type="text" class="form-control" id="ac_no_1_employee_share_rs_pmgky_data" name="ac_no_1_employee_share_rs_pmgky_data" value="<?php echo $cms['ac_no_1_employee_share_rs_pmgky_data'];?>" placeholder="Ac No 1 Employee Share Rs Pmgky data" required="required"></td>
								</tr>
								<tr>
								  <th scope="row">D)Total (A + B + C) ( Rs.) -</th>
								   <td><input type="text" class="form-control" id="total_a_b_c_rs_pmrpy_data" name="total_a_b_c_rs_pmrpy_data" value="<?php echo $cms['total_a_b_c_rs_pmrpy_data'];?>" placeholder="Total a b c rs pmrpy data" required="required"></td>
								  <td><input type="text" class="form-control" id="total_a_b_c_rs_pmgky_data" name="total_a_b_c_rs_pmgky_data" value="<?php echo $cms['total_a_b_c_rs_pmgky_data'];?>" placeholder="total a b c rs pmgky data" required="required"></td>
								</tr>
								<tr>
								  <th scope="row">E) Total remittance by Employer ( Rs.) -</th>
								   <td><input type="text" class="form-control" id="total_remittance_by_employer_rs" name="total_remittance_by_employer_rs" value="<?php echo $cms['total_remittance_by_employer_rs'];?>" placeholder="Total remittance by employer rs" required="required"></td>
								  <td></td>
								</tr>
								<tr>
								  <th scope="row">F)Total amount of uploaded ECR (D + E) -</th>
								   <td><input type="text" class="form-control" id="total_amount_of_uploaded_ECR" name="total_amount_of_uploaded_ECR" value="<?php echo $cms['total_amount_of_uploaded_ECR'];?>" placeholder="Total amount of uploaded ECR" required="required"></td>
								  <td></td>
								</tr>
							  </tbody>
							</table>
						  </div>
						  <div class="box-footer">
							<input type="hidden" id="pf_challan_id" name="pf_challan_id" value="<?php echo $cms['pf_challan_id']; ?>">
							<input type="hidden" id="uploading_track_details_id" name="uploading_track_details_id" value="<?php echo $cms['uploading_track_details_id']; ?>">
							<button type="submit" class="btn btn-sm btn-primary">Submit</button>
						  </div>
						</form>						
						  <!-- /.box-body -->						  
					  </div>
				</div>
          <!-- /.box -->
          </div><!-- /.row -->	
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
	  
<div class="modal" id='myModal2'>
    <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span></button>
                <h4 class="modal-title">Esic Table Data</h4>
              </div>
              <div class="modal-body" id='modalContent2' title="">
				<div class="form-group">
					<label for="is_disable">Is Disable<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Is disable" id="is_disable" name="is_disable" >
				</div>
				<div class="form-group">
					<label for="ip_number">Ip Number<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Ip Number" id="ip_number" name="ip_number" >
				</div>
				<div class="form-group">
					<label for="ip_name">Ip Name<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Ip Name" id="ip_name" name="ip_name" >
				</div>
				<div class="form-group">
					<label for="no_of_days">No Of Days<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="No Of Days" id="no_of_days" name="no_of_days" >
				</div>
				<div class="form-group">
					<label for="total_wages">Total Wages<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Total Wages" id="total_wages" name="total_wages" >
				</div>
				<div class="form-group">
					<label for="ip_contribution">Ip Contribution<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="ip_contribution" id="ip_contribution" name="ip_contribution" >
				</div>
				<div class="form-group">
					<label for="reason">Reason<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="reason" id="reason" name="reason" >
				</div>
				<input type='hidden' class="form-control" id="esic_table_data_id">
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal" id="cdel2">save</button>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
		
<div class="modal" id='myModal3'>
    <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span></button>
                <h4 class="modal-title">Esic Table Data</h4>
              </div>
              <div class="modal-body" id='modalContent2' title="">
				<div class="form-group">
					<label for="is_disable">Is Disable<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Is disable" id="is_disable_add" name="is_disable_add" >
				</div>
				<div class="form-group">
					<label for="ip_number">Ip Number<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Ip Number" id="ip_number_add" name="ip_number_add" >
				</div>
				<div class="form-group">
					<label for="ip_name">Ip Name<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Ip Name" id="ip_name_add" name="ip_name_add" >
				</div>
				<div class="form-group">
					<label for="no_of_days">No Of Days<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="No Of Days" id="no_of_days_add" name="no_of_days_add" >
				</div>
				<div class="form-group">
					<label for="total_wages">Total Wages<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Total Wages" id="total_wages_add" name="total_wages_add" >
				</div>
				<div class="form-group">
					<label for="ip_contribution">Ip Contribution<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Ip Contribution" id="ip_contribution_add" name="ip_contribution_add" >
				</div>
				<div class="form-group">
					<label for="reason">Reason<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="reason" id="reason_add" name="reason_add" >
				</div>
				<input type='hidden' class="form-control" id="esic_basic_data_id">
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal" id="cdel2_add">save</button>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
		
<script src="https://cdn.ckeditor.com/4.5.7/standard/ckeditor.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-show-password/1.0.3/bootstrap-show-password.min.js"></script>
<script>
$( "#signupForm" ).validate( {
					rules: {
						product_name: "required",
						meta_key_id:"required",
						brand_id:"required"
						
						
					},
					messages: {						
						product_name: {required:"name field is required"},
						meta_key_id: {required:"Category field is required"},
						brand_id: {required:"Brand field is required"}
						
					},
					errorElement: "em",
					
					highlight: function ( element, errorClass, validClass ) {
						$( element ).parents( ".form-control" ).addClass( "has-error" ).removeClass( "has-success" );
					},
					unhighlight: function (element, errorClass, validClass) {
						$( element ).parents( ".form-control" ).addClass( "has-success" ).removeClass( "has-error" );
					}
				} );
				
$(document).on( "click",'.cstm_view',function() {
    var esic_table_data_id=$(this).prop('title');
    var content='<div class="box-body"><table class="table table-bordered">';
	 $.ajax({
      type:'POST',
      url :'<?php echo base_url('admin/dms/esic_table_details');?>',
      data:'esic_table_data_id='+esic_table_data_id,
      dataType:'json',
      success:function(result){
		$("#is_disable").val(result.responseList.is_disable);
		$("#ip_number").val(result.responseList.ip_number);
		$("#ip_name").val(result.responseList.ip_name);
		$("#no_of_days").val(result.responseList.no_of_days);
		$("#total_wages").val(result.responseList.total_wages);
		$("#ip_contribution").val(result.responseList.ip_contribution);
		$("#reason").val(result.responseList.reason);
		$("#esic_table_data_id").val(result.responseList.esic_table_data_id);
      },error:function(){

      }
    });
	$('#myModal2').modal('show');
  });
  
 $("#cdel2").click(function(){
	var  is_disable = $("#is_disable").val();
	var ip_number  = $("#ip_number").val();
	var ip_name = $("#ip_name").val();
	var no_of_days = $("#no_of_days").val();
	var total_wages = $("#total_wages").val();
	var ip_contribution = $("#ip_contribution").val();
	var reason = $("#reason").val();
	var esic_table_data_id = $("#esic_table_data_id").val();
	 $.ajax({
      type:'POST',
      url :'<?php echo base_url('admin/dms/update_esic_table_data');?>',
      data:'esic_table_data_id='+esic_table_data_id+'&is_disable='+is_disable+'&ip_number='+ip_number+'&ip_name='+ip_name+'&no_of_days='+no_of_days+'&total_wages='+total_wages+'&ip_contribution='+ip_contribution+'&reason='+reason,
      dataType:'json',
      success:function(result){
		window.location.reload('<?php echo base_url('admin/dms/esic_details'); ?>'+result.responseList.esic_basic_data_id);	
      },error:function(){

      }
    });
 });
 
 $(document).on( "click",'.cstm_view_esic_table',function() {
	var esic_basic_data_id=$(this).prop('title');
	$('#esic_basic_data_id').val(esic_basic_data_id);
	$('#myModal3').modal('show');
 });
 
  $("#cdel2_add").click(function(){
	var is_disable = $("#is_disable_add").val();
	var ip_number  = $("#ip_number_add").val();
	var ip_name = $("#ip_name_add").val();
	var no_of_days = $("#no_of_days_add").val();
	var total_wages = $("#total_wages_add").val();
	var ip_contribution = $("#ip_contribution_add").val();
	var esic_basic_data_id = $("#esic_basic_data_id").val();
	var reason = $("#reason_add").val();  
	$.ajax({
      type:'POST',
      url :'<?php echo base_url('admin/dms/add_esic_table_data');?>',
      data:'esic_basic_data_id='+esic_basic_data_id+'&is_disable='+is_disable+'&ip_number='+ip_number+'&ip_name='+ip_name+'&no_of_days='+no_of_days+'&total_wages='+total_wages+'&ip_contribution='+ip_contribution+'&reason='+reason,
      dataType:'json',
      success:function(result){
		window.location.reload('<?php echo base_url('admin/dms/esic_details'); ?>'+result.responseList.esic_basic_data_id);	
      },error:function(){

      }
    });
  });
  
 $(document).on( "click",'.delete_data',function() {
	var esic_basic_data_id=$(this).attr('basic_data_id'); 
	var esic_table_data_id = $(this).prop('title');
	alert(esic_table_data_id);
	$.ajax({
      type:'POST',
      url :'<?php echo base_url('admin/dms/delete_esic_table_data');?>',
      data:'esic_basic_data_id='+esic_basic_data_id+'&esic_table_data_id='+esic_table_data_id,
      dataType:'json',
      success:function(result){
		window.location.reload('<?php echo base_url('admin/dms/esic_details'); ?>'+result.responseList.esic_basic_data_id);	
      },error:function(){

      }
    });
 });
  
  
</script>
<style>
div.ex1 {
  overflow: scroll;
  height: 420px;
}
</style>