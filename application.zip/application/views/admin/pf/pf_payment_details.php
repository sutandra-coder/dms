 <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
 <script src="<?php echo base_url()?>/public/validation/js/jquery.validate.js"></script>
<!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h3>
            PF Payment Data
            
          </h3>         
        </section>

        <!-- Main content -->
        <section class="content"> 
			<div class="row">
				<div class="col-md-6">										
					<div class="embed-responsive embed-responsive-4by3">
						<iframe class="embed-responsive-item" src="<?php echo base_url()."/public/images/".$uploadig_file_name; ?>" allowfullscreen></iframe>
					</div>
				</div>
				<!-- general form elements -->
				<div class="col-md-6">
					  <div class="box box-primary ex1">						 
						<div class="box-header with-border">						
						  <h3 class="box-title"></h3>
						  <?php if($this->session->flashdata('error_msg')){?>
								<span style="color:red; font-weight:bold"><?php echo $this->session->flashdata('error_msg');?></span>
							<?php }?>
							<?php if($this->session->flashdata('success_msg')){?>
								<span style="color:green; font-weight:bold"><?php  echo $this->session->flashdata('success_msg'); ?></span>
							<?php }?>
						</div>
						<!-- /.box-header -->
						<!-- form start -->
						<form id="signupForm" role="form" class="mtbresize" method="post" action="<?php echo base_url()."admin/pfdms/pf_payment_data_update"; ?>" enctype="multipart/form-data" autocomplete="off">
						  <div class="box-body">							
							<div class="form-group">
							  <label for="trrn_data">TRRN No:<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="trrn_data" name="trrn_data" value="<?php echo $cms['trrn_data'];?>" placeholder="Trrn No" required="required">
							  <?php echo form_error('trrn_data','<span class="error">', '</span>'); ?>
							</div>	
							<div class="form-group">
							  <label for="challan_status_data">Challan Status:<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="challan_status_data" name="challan_status_data" value="<?php echo $cms['challan_status_data'];?>" placeholder="Challan Status Data" required="required">
							  <?php echo form_error('challan_status_data','<span class="error">', '</span>'); ?>
							</div>	
							<div class="form-group">
							  <label for="challan_generated_on_data">Challan Generated On:<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="challan_generated_on_data" name="challan_generated_on_data" value="<?php echo $cms['challan_generated_on_data'];?>" placeholder="Challan Generated On" required="required">
							  <?php echo form_error('challan_generated_on_data','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="establishment_id_data">Establishment Id Data:<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="establishment_id_data" name="establishment_id_data" value="<?php echo $cms['establishment_id_data'];?>" placeholder="Establishment Id" required="required">
							  <?php echo form_error('establishment_id_data','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="esablishment_name_data">Esablishment Name:<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="esablishment_name_data" name="esablishment_name_data" value="<?php echo $cms['esablishment_name_data'];?>" placeholder="Esablishment Nme" required="required">
							  <?php echo form_error('esablishment_name_data','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="challan_type_data">Challan Tpe:<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="challan_type_data" name="challan_type_data" value="<?php echo $cms['challan_type_data'];?>" placeholder="Challan Type" required="required">
							  <?php echo form_error('challan_type_data','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="wages_month_data">Wages Month:<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="wages_month_data" name="wages_month_data" value="<?php echo $cms['wages_month_data'];?>" placeholder="Wages Month" required="required">
							  <?php echo form_error('wages_month_data','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="total_amount_rs_data">Total Amount(Rs):<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="total_amount_rs_data" name="total_amount_rs_data" value="<?php echo $cms['total_amount_rs_data'];?>" placeholder="Total Amount(Rs)" required="required">
							  <?php echo form_error('total_amount_rs_data','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="account_1_amount_rs_data">Account-1 Aount(Rs) :<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="account_1_amount_rs_data" name="account_1_amount_rs_data" value="<?php echo $cms['account_1_amount_rs_data'];?>" placeholder="Account-1 Aount(Rs)" required="required">
							  <?php echo form_error('account_1_amount_rs_data','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="account_2_amount_rs_data">Account-2 Aount(Rs) :<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="account_1_amount_rs_data" name="account_1_amount_rs_data" value="<?php echo $cms['account_1_amount_rs_data'];?>" placeholder="Account-1 Aount(Rs)" required="required">
							  <?php echo form_error('account_1_amount_rs_data','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="account_10_amount_rs_data">Account-10 Aount(Rs) :<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="account_10_amount_rs_data" name="account_10_amount_rs_data" value="<?php echo $cms['account_10_amount_rs_data'];?>" placeholder="Account-10 Aount(Rs)" required="required">
							  <?php echo form_error('account_10_amount_rs_data','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="account_21_amount_rs_data">Account-21 Aount(Rs) :<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="account_21_amount_rs_data" name="account_21_amount_rs_data" value="<?php echo $cms['account_21_amount_rs_data'];?>" placeholder="Account-21 Aount(Rs)" required="required">
							  <?php echo form_error('account_21_amount_rs_data','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="account_22_amount_rs_data">Account-22 Aount(Rs) :<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="account_22_amount_rs_data" name="account_22_amount_rs_data" value="<?php echo $cms['account_22_amount_rs_data'];?>" placeholder="Account-22 Aount(Rs)" required="required">
							  <?php echo form_error('account_22_amount_rs_data','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="payment_confirmation_bank_data">Payment Confirmation Bank :<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="payment_confirmation_bank_data" name="payment_confirmation_bank_data" value="<?php echo $cms['payment_confirmation_bank_data'];?>" placeholder="Payment Confirmation Bank" required="required">
							  <?php echo form_error('payment_confirmation_bank_data','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="crn_data">CRN :<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="crn_data" name="crn_data" value="<?php echo $cms['crn_data'];?>" placeholder="CRN" required="required">
							  <?php echo form_error('crn_data','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="payment_date_data">Payment Date :<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="payment_date_data" name="payment_date_data" value="<?php echo $cms['payment_date_data'];?>" placeholder="CRN" required="required">
							  <?php echo form_error('payment_date_data','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="payment_confirmation_date_data">Payment Confirmation date :<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="payment_confirmation_date_data" name="payment_confirmation_date_data" value="<?php echo $cms['payment_date_data'];?>" placeholder="CRN" required="required">
							  <?php echo form_error('payment_confirmation_date_data','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="total_pmrpy_benefit_data">Total Pmrpy Benefit :<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="total_pmrpy_benefit_data" name="total_pmrpy_benefit_data" value="<?php echo $cms['total_pmrpy_benefit_data'];?>" placeholder="Total Pmrpy Benefit" required="required">
							  <?php echo form_error('total_pmrpy_benefit_data','<span class="error">', '</span>'); ?>
							</div>
							<div class="box-footer">
								<input type="hidden" id="pf_payment_id" name="pf_payment_id" value="<?php echo $cms['pf_payment_id']; ?>">
								<input type="hidden" id="uploading_track_details_id" name="uploading_track_details_id" value="<?php echo $cms['uploading_track_details_id']; ?>">
								<button type="submit" class="btn btn-sm btn-primary">Submit</button>
							</div>
						</form>						
						  <!-- /.box-body -->						  
					  </div>
				</div>
          <!-- /.box -->
          </div><!-- /.row -->	
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
	  
<div class="modal" id='myModal2'>
    <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span></button>
                <h4 class="modal-title">Esic Table Data</h4>
              </div>
              <div class="modal-body" id='modalContent2' title="">
				<div class="form-group">
					<label for="is_disable">Is Disable<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Is disable" id="is_disable" name="is_disable" >
				</div>
				<div class="form-group">
					<label for="ip_number">Ip Number<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Ip Number" id="ip_number" name="ip_number" >
				</div>
				<div class="form-group">
					<label for="ip_name">Ip Name<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Ip Name" id="ip_name" name="ip_name" >
				</div>
				<div class="form-group">
					<label for="no_of_days">No Of Days<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="No Of Days" id="no_of_days" name="no_of_days" >
				</div>
				<div class="form-group">
					<label for="total_wages">Total Wages<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Total Wages" id="total_wages" name="total_wages" >
				</div>
				<div class="form-group">
					<label for="ip_contribution">Ip Contribution<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="ip_contribution" id="ip_contribution" name="ip_contribution" >
				</div>
				<div class="form-group">
					<label for="reason">Reason<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="reason" id="reason" name="reason" >
				</div>
				<input type='hidden' class="form-control" id="esic_table_data_id">
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal" id="cdel2">save</button>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
		
<div class="modal" id='myModal3'>
    <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span></button>
                <h4 class="modal-title">Esic Table Data</h4>
              </div>
              <div class="modal-body" id='modalContent2' title="">
				<div class="form-group">
					<label for="is_disable">Is Disable<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Is disable" id="is_disable_add" name="is_disable_add" >
				</div>
				<div class="form-group">
					<label for="ip_number">Ip Number<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Ip Number" id="ip_number_add" name="ip_number_add" >
				</div>
				<div class="form-group">
					<label for="ip_name">Ip Name<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Ip Name" id="ip_name_add" name="ip_name_add" >
				</div>
				<div class="form-group">
					<label for="no_of_days">No Of Days<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="No Of Days" id="no_of_days_add" name="no_of_days_add" >
				</div>
				<div class="form-group">
					<label for="total_wages">Total Wages<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Total Wages" id="total_wages_add" name="total_wages_add" >
				</div>
				<div class="form-group">
					<label for="ip_contribution">Ip Contribution<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Ip Contribution" id="ip_contribution_add" name="ip_contribution_add" >
				</div>
				<div class="form-group">
					<label for="reason">Reason<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="reason" id="reason_add" name="reason_add" >
				</div>
				<input type='hidden' class="form-control" id="esic_basic_data_id">
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal" id="cdel2_add">save</button>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
		
<script src="https://cdn.ckeditor.com/4.5.7/standard/ckeditor.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-show-password/1.0.3/bootstrap-show-password.min.js"></script>
<script>
$( "#signupForm" ).validate( {
					rules: {
						product_name: "required",
						meta_key_id:"required",
						brand_id:"required"
						
						
					},
					messages: {						
						product_name: {required:"name field is required"},
						meta_key_id: {required:"Category field is required"},
						brand_id: {required:"Brand field is required"}
						
					},
					errorElement: "em",
					
					highlight: function ( element, errorClass, validClass ) {
						$( element ).parents( ".form-control" ).addClass( "has-error" ).removeClass( "has-success" );
					},
					unhighlight: function (element, errorClass, validClass) {
						$( element ).parents( ".form-control" ).addClass( "has-success" ).removeClass( "has-error" );
					}
				} );
				
$(document).on( "click",'.cstm_view',function() {
    var esic_table_data_id=$(this).prop('title');
    var content='<div class="box-body"><table class="table table-bordered">';
	 $.ajax({
      type:'POST',
      url :'<?php echo base_url('admin/dms/esic_table_details');?>',
      data:'esic_table_data_id='+esic_table_data_id,
      dataType:'json',
      success:function(result){
		$("#is_disable").val(result.responseList.is_disable);
		$("#ip_number").val(result.responseList.ip_number);
		$("#ip_name").val(result.responseList.ip_name);
		$("#no_of_days").val(result.responseList.no_of_days);
		$("#total_wages").val(result.responseList.total_wages);
		$("#ip_contribution").val(result.responseList.ip_contribution);
		$("#reason").val(result.responseList.reason);
		$("#esic_table_data_id").val(result.responseList.esic_table_data_id);
      },error:function(){

      }
    });
	$('#myModal2').modal('show');
  });
  
 $("#cdel2").click(function(){
	var  is_disable = $("#is_disable").val();
	var ip_number  = $("#ip_number").val();
	var ip_name = $("#ip_name").val();
	var no_of_days = $("#no_of_days").val();
	var total_wages = $("#total_wages").val();
	var ip_contribution = $("#ip_contribution").val();
	var reason = $("#reason").val();
	var esic_table_data_id = $("#esic_table_data_id").val();
	 $.ajax({
      type:'POST',
      url :'<?php echo base_url('admin/dms/update_esic_table_data');?>',
      data:'esic_table_data_id='+esic_table_data_id+'&is_disable='+is_disable+'&ip_number='+ip_number+'&ip_name='+ip_name+'&no_of_days='+no_of_days+'&total_wages='+total_wages+'&ip_contribution='+ip_contribution+'&reason='+reason,
      dataType:'json',
      success:function(result){
		window.location.reload('<?php echo base_url('admin/dms/esic_details'); ?>'+result.responseList.esic_basic_data_id);	
      },error:function(){

      }
    });
 });
 
 $(document).on( "click",'.cstm_view_esic_table',function() {
	var esic_basic_data_id=$(this).prop('title');
	$('#esic_basic_data_id').val(esic_basic_data_id);
	$('#myModal3').modal('show');
 });
 
  $("#cdel2_add").click(function(){
	var is_disable = $("#is_disable_add").val();
	var ip_number  = $("#ip_number_add").val();
	var ip_name = $("#ip_name_add").val();
	var no_of_days = $("#no_of_days_add").val();
	var total_wages = $("#total_wages_add").val();
	var ip_contribution = $("#ip_contribution_add").val();
	var esic_basic_data_id = $("#esic_basic_data_id").val();
	var reason = $("#reason_add").val();  
	$.ajax({
      type:'POST',
      url :'<?php echo base_url('admin/dms/add_esic_table_data');?>',
      data:'esic_basic_data_id='+esic_basic_data_id+'&is_disable='+is_disable+'&ip_number='+ip_number+'&ip_name='+ip_name+'&no_of_days='+no_of_days+'&total_wages='+total_wages+'&ip_contribution='+ip_contribution+'&reason='+reason,
      dataType:'json',
      success:function(result){
		window.location.reload('<?php echo base_url('admin/dms/esic_details'); ?>'+result.responseList.esic_basic_data_id);	
      },error:function(){

      }
    });
  });
  
 $(document).on( "click",'.delete_data',function() {
	var esic_basic_data_id=$(this).attr('basic_data_id'); 
	var esic_table_data_id = $(this).prop('title');
	alert(esic_table_data_id);
	$.ajax({
      type:'POST',
      url :'<?php echo base_url('admin/dms/delete_esic_table_data');?>',
      data:'esic_basic_data_id='+esic_basic_data_id+'&esic_table_data_id='+esic_table_data_id,
      dataType:'json',
      success:function(result){
		window.location.reload('<?php echo base_url('admin/dms/esic_details'); ?>'+result.responseList.esic_basic_data_id);	
      },error:function(){

      }
    });
 });
  
  
</script>
<style>
div.ex1 {
  overflow: scroll;
  height: 420px;
}
</style>