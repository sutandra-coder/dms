<style>
.cstm_view{font-size:15px;}
</style>
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
          <h3>
            Catalog List
            
          </h3>
          <!--<ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>-->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box box-primary">
            <div class="box-header with-border">
			<div class="admin_tab">
			<ul>
				<li><a href="javascript:void(0);" onclick="window.history.back();">Back</a></li>
				<li><a href="<?php echo base_url();?>admin/catalog/add">Add</a></li>
			</ul>
			
				 
							
							<?php if($this->session->flashdata('error_msg')){?>
								<span style="color:red; font-weight:bold"><?php echo $this->session->flashdata('error_msg');?></span>
							<?php }?>
							<?php if($this->session->flashdata('success_msg')){?>
								<span style="color:green; font-weight:bold"><?php  echo $this->session->flashdata('success_msg'); ?></span>
							<?php }?>
				</div>			 
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example" class="table table-bordered table-striped">
                <thead>
                <tr>
				  <th>Sl. NO.</th>
				  <th>Category</th>	
				  <th>Product Count</th>
				  <th>category List</th>
				  <th>Home Section</th>
				  <th class="no-sort">Edit</th>
                </tr>
                </thead> 
				<tbody>
					<?php $i=1; foreach($post_data as $row){ ?>
					<tr>
						<td class="text-center">
                          <?php echo $i;?>
                        </td> 
						<td class="text-center">
                          <?php echo $row['catalog_name'];?>
                        </td> 
						<td class="text-center">
							<a class="cstm_view" id="view" style="padding-left:5px" href="javascript:void(0)" title="<?php echo  $row['catalog_id']; ?>"><?php echo $row['product_count'];?></a>                         
                        </td>
						<td class="text-center">
							<a class="cstm_view" id="categoryList" style="padding-left:5px" href="javascript:void(0)" title="<?php echo  $row['catalog_id']; ?>">Show Category</a>                         
                        </td>
						<td class="text-center">
                          <?php 
							if($row['is_home_section']==1)
							{
								echo '<a class="cstm_view" id="activee" href="javascript:void(0)" title="'.$row['catalog_id'].'"><span class="glyphicon glyphicon-ok"></span></a>';
							}else{
								echo '<a class="cstm_view" id="inactivee" href="javascript:void(0)" title="'.$row['catalog_id'].'"><span class="glyphicon glyphicon-remove"></span></a>';
							}
						  ?>
                        </td>
						<td class="text-center">
                          <a href="<?php echo base_url('admin/catalog/details/'.$row['catalog_id']); ?>" ><span class="glyphicon glyphicon-pencil"></span></a>
                        </td>
						
					</tr>
					<?php $i++;} ?>
				</tbody>
                <tfoot>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  
  <div class="modal" id='myModal2'>
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span></button>
                <h4 class="modal-title"> Product List</h4>
              </div>
			  
              <div class="modal-body"  title="">
				<span style="font-weight:bold" id="msg_modal2"></span>
				<!--<div class="form-group">
						<label for="discount_id">Discount</label>
						<select class="form-control" id="discount_id" name="discount_id" >
							<option value="">Select</option>
							<?php foreach($discount_list as $discount){?>							
							<option value="<?php echo $discount["discount_id"]?>"><?php echo $discount["discount"]?></option>									
							<?php } ?>
						</select>							  
						<?php echo form_error('discount_id','<span class="error">', '</span>'); ?>
				</div> -->
				<div id='modalContent2'>
				</div>
               <!-- <p>Would you like to continue ?</p>-->
              </div>
              <div class="modal-footer">
			  <input type="hidden" id="product_id_list" name="product_id_list">
			  <!-- <button type="button" class="btn btn-primary" id="save_product_meta_discount">Save</button> -->
                <button type="button" class="btn btn-primary" data-dismiss="modal" id="cdel2">Cancel</button>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
		
		<div class="modal" id='myModalCategory'>
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span></button>
                <h4 class="modal-title"> Category List</h4>
              </div>
			  
              <div class="modal-body"  title="">
				<span style="font-weight:bold" id="msg_modal2"></span>				
				<div id='modalContentCategory'>
				</div>
               <!-- <p>Would you like to continue ?</p>-->
              </div>
              <div class="modal-footer">
			  <input type="hidden" id="product_id_list" name="product_id_list">
			  <!-- <button type="button" class="btn btn-primary" id="save_product_meta_discount">Save</button> -->
                <button type="button" class="btn btn-primary" data-dismiss="modal" id="cdel2">Cancel</button>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>

<script src="<?php echo base_url()?>public/admin_assets/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url()?>public/admin_assets/plugins/datatables/dataTables.bootstrap.min.js"></script>
<script>
/*$(document).ready(function() {
    $('#example').DataTable( {
        "processing": true,
        "serverSide": true,
        "ajax": {
            "url": "<?php echo base_url('admin/metakey/all_content_list');?>",
            "type": "POST"
        },
        //Set column definition initialisation properties.
        "columnDefs": [
        { 
            "targets": 'no-sort', //1st and last column
            "orderable": false, //set not orderable
        },
        ],
    } );
	
	var dtable = $("#example").dataTable().api();
	
	$(".dataTables_filter input")
    .unbind() // Unbind previous default bindings
    .bind("input", function(e) { // Bind our desired behavior
        // If the length is 3 or more characters, or the user pressed ENTER, search
        if(this.value.length >= 3 || e.keyCode == 13) {
            // Call the API search function
            dtable.search(this.value).draw();
        }
        // Ensure we clear the search if they backspace far enough
        if(this.value == "") {
            dtable.search("").draw();
        }
        return;
    });
} );*/

var  table = $('#example').dataTable({
    'bLengthChange': false,
    'searching': true,
    'paging':   true,  // Table pagination
    'ordering': true,  // Column ordering
    'info':     true,  // Bottom left status text
    'responsive': true, // https://datatables.net/extensions/responsive/examples/
    // Text translation options
    // Note the required keywords between underscores (e.g _MENU_)
    oLanguage: {
        // sSearch:      'Search all columns:',
        sLengthMenu:  '_MENU_ records per page',
        info:         'Showing page _PAGE_ of _PAGES_',
        zeroRecords:  'Nothing found - sorry',
        infoEmpty:    'No records available',
        infoFiltered: '(filtered from _MAX_ total records)'
    },
    // set columns options
    'aoColumns': [
    {'bVisible':true},
    {'bVisible':true},
    {'bVisible':true},
	{'bVisible':true},
	{'bVisible':true},
	{'bVisible':true}
    ],
	"columnDefs": [
        { 
            "targets": 'no-sort', //1st and last column
            "orderable": false, //set not orderable
        },
        ]
 });
 
$(document).on( "click",'#view.cstm_view',function() {
	var catalog_id=$(this).prop('title');	
	var content='<div class="box-body" style="height:300px;overflow-y:scroll;"><table id="product_list" class="table table-bordered">';
	$.ajax({
      type:'POST',
      url :'<?php echo base_url('admin/catalog/produt_catalog_list');?>',
      data:'catalog_id='+catalog_id,
      dataType:'json',
      success:function(result){		  
			var i=1;
			content+=' <tr><th>Sl No</th><th>Product Name</th><th>Product Catalog</th></tr>';
			$.each( result.responseList, function( key, value ) {				
				if(value.is_prodcut_catalog == 1)
				{
					is_prodcut_catalog = '<a class="cstm_view_product_catalog" id="active" href="javascript:void(0)" catalog_id = "'+catalog_id+'" title="'+value.product_id+'"><span class="glyphicon glyphicon-ok"></span></a>';
				}else{
					is_prodcut_catalog = '<a class="cstm_view_product_catalog" id="inactive" href="javascript:void(0)" catalog_id = "'+catalog_id+'" title="'+value.product_id+'"><span class="glyphicon glyphicon-remove"></span></a>';
				}				
				
				content+=' <tr><td>'+i+'</td><td>'+value.product_name+'</td><td>'+is_prodcut_catalog+'</td></tr>';
				
				 i++;
				 content+='</hr>';
			});
			
			content+='</table></div>';			
			$('#modalContent2').html(content);  
			$('#myModal2').modal('show');
		 },error:function(){

		  }
		});
});

$(document).on( "click",'#categoryList.cstm_view',function() {
	var catalog_id=$(this).prop('title');	
	var content='<div class="box-body" style="height:300px;overflow-y:scroll;"><table id="product_list" class="table table-bordered">';
	$.ajax({
      type:'POST',
      url :'<?php echo base_url('admin/catalog/category_catalog_list');?>',
      data:'catalog_id='+catalog_id,
      dataType:'json',
      success:function(result){		  
			var i=1;
			content+=' <tr><th>Sl No</th><th>Catalog Name</th><th>Is Category</th></tr>';
			$.each( result.responseList, function( key, value ) {				
				if(value.is_category == 1)
				{
					is_category = '<a class="cstm_view_category_catalog" id="activec" href="javascript:void(0)" catalog_id = "'+catalog_id+'" title="'+value.category_id+'"><span class="glyphicon glyphicon-ok"></span></a>';
				}else{
					is_category = '<a class="cstm_view_category_catalog" id="inactivec" href="javascript:void(0)" catalog_id = "'+catalog_id+'" title="'+value.category_id+'"><span class="glyphicon glyphicon-remove"></span></a>';
				}				
				
				content+=' <tr><td>'+i+'</td><td>'+value.category_name+'</td><td>'+is_category+'</td></tr>';
				
				 i++;
				 content+='</hr>';
			});
			
			content+='</table></div>';			
			$('#modalContentCategory').html(content);  
			$('#myModalCategory').modal('show');
		 },error:function(){

		  }
		});
});

$(document).on( "click",'#active.cstm_view_product_catalog',function() {
		var p = $(this);
		p.html('---');		
		var id=$(this).prop('title');
		var catalog_id = $(this).attr('catalog_id');
		$.ajax({
		  type: "POST",
		  url: '<?php echo base_url('admin/catalog/remove_catalog_product')?>',
		  data: 'catalog_id='+catalog_id+'&product_id='+id,
		  dataType:'json',
		  success: function(response){
			p.attr("id", "inactive");
			p.html('<span class="glyphicon glyphicon-remove"></span>');	
			//window.location.reload('<?php echo base_url('admin/feedback'); ?>');	
		  }
		});
	});
	
	$(document).on( "click",'#inactive.cstm_view_product_catalog',function() {
		var pactive = $(this);
		pactive.html('---');		
		var id=$(this).prop('title');
		var catalog_id = $(this).attr('catalog_id');
		$.ajax({
		  type: "POST",
		  url: '<?php echo base_url('admin/catalog/add_catalog_product')?>',
		  data: 'catalog_id='+catalog_id+'&product_id='+id,
		  dataType:'json',
		  success: function(response){
			pactive.attr("id","active");
			pactive.html('<span class="glyphicon glyphicon-ok"></span>');						
			//window.location.reload('<?php echo base_url('admin/feedback'); ?>');		
		  }
		});
	});
	
$(document).on( "click",'#activec.cstm_view_category_catalog',function() {
		var p = $(this);
		p.html('---');		
		var id=$(this).prop('title');
		var catalog_id = $(this).attr('catalog_id');
		$.ajax({
		  type: "POST",
		  url: '<?php echo base_url('admin/catalog/remove_catalog_category')?>',
		  data: 'catalog_id='+catalog_id+'&category_id='+id,
		  dataType:'json',
		  success: function(response){
			p.attr("id", "inactivec");
			p.html('<span class="glyphicon glyphicon-remove"></span>');	
			//window.location.reload('<?php echo base_url('admin/feedback'); ?>');	
		  }
		});
	});
	
	$(document).on( "click",'#inactivec.cstm_view_category_catalog',function() {
		var pactive = $(this);
		pactive.html('---');		
		var id=$(this).prop('title');
		var catalog_id = $(this).attr('catalog_id');
		$.ajax({
		  type: "POST",
		  url: '<?php echo base_url('admin/catalog/add_catalog_category')?>',
		  data: 'catalog_id='+catalog_id+'&category_id='+id,
		  dataType:'json',
		  success: function(response){
			pactive.attr("id","activec");
			pactive.html('<span class="glyphicon glyphicon-ok"></span>');						
			//window.location.reload('<?php echo base_url('admin/feedback'); ?>');		
		  }
		});
	});
	
	$(document).on( "click",'#activee.cstm_view',function() {
		var p = $(this);
		p.html('---');		
		var id=$(this).prop('title');
		$.ajax({
		  type: "POST",
		  url: '<?php echo base_url('admin/catalog/remove_home_section')?>',
		  data: 'catalog_id='+id,
		  dataType:'json',
		  success: function(response){
			p.attr("id", "inactivee");
			p.html('<span class="glyphicon glyphicon-remove"></span>');	
			//window.location.reload('<?php echo base_url('admin/feedback'); ?>');	
		  }
		});
	});
	
	$(document).on( "click",'#inactivee.cstm_view',function() {
		var pactive = $(this);
		pactive.html('---');		
		var id=$(this).prop('title');
		$.ajax({
		  type: "POST",
		  url: '<?php echo base_url('admin/catalog/add_home_section')?>',
		  data: 'catalog_id='+id,
		  dataType:'json',
		  success: function(response){
			pactive.attr("id","activee");
			pactive.html('<span class="glyphicon glyphicon-ok"></span>');						
			//window.location.reload('<?php echo base_url('admin/feedback'); ?>');		
		  }
		});
	});
	
</script>
