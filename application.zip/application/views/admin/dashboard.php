<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>

<style>

.icon_wrp_bx
{
	color:#333;
}
.icon_wrp_bx:hover
{
	color:#333;
}
</style

<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <!--<small>Version 2.0</small>-->
      </h1>
     <!-- <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>-->
    </section>
	
	

    <!-- Main content -->
    <section class="content">
	
	<div class="row">       
		<div class="col-md-3 col-sm-6 col-xs-12">
			<a href="<?php echo base_url();?>admin/dms" class="icon_wrp_bx">
			  <div class="info-box">
				<span class="info-box-icon bg-my-color"><i class="fa fa-money"></i></span>

				<div class="info-box-content">
				  <span class="info-box-text"></span>
				  <span class="info-box-number">Total Esic Challan</span>
				   <span class="info-box-number"><?php echo $esic_challan_couunt;?></span>
				</div> 
				<!-- /.info-box-content -->
			  </div>
			</a>
			  <!-- /.info-box -->
        </div>
		<div class="col-md-3 col-sm-6 col-xs-12">
			<a href="<?php echo base_url();?>admin/dms" class="icon_wrp_bx">
			  <div class="info-box">
				<span class="info-box-icon bg-my-color"><i class="fa fa-money"></i></span>

				<div class="info-box-content">
				  <span class="info-box-text"></span>
				  <span class="info-box-number">Total Esic Payment</span>
				   <span class="info-box-number"><?php echo $total_payment_count;?></span>
				</div> 
				<!-- /.info-box-content -->
			  </div>
			</a>
			  <!-- /.info-box -->
        </div>
		<div class="col-md-3 col-sm-6 col-xs-12">
			<a href="<?php echo base_url();?>admin/ptaxdms" class="icon_wrp_bx">
			  <div class="info-box">
				<span class="info-box-icon bg-my-color"><i class="fa fa-money"></i></span>

				<div class="info-box-content">
				  <span class="info-box-text"></span>
				  <span class="info-box-number">Total P-tax Challan</span>
				   <span class="info-box-number"><?php echo $p_tax_challan_count;?></span>
				</div> 
				<!-- /.info-box-content -->
			  </div>
			</a>
			  <!-- /.info-box -->
        </div>
		<div class="col-md-3 col-sm-6 col-xs-12">
			<a href="<?php echo base_url();?>admin/ptaxdms" class="icon_wrp_bx">
			  <div class="info-box">
				<span class="info-box-icon bg-my-color"><i class="fa fa-money"></i></span>

				<div class="info-box-content">
				  <span class="info-box-text"></span>
				  <span class="info-box-number">Total P-tax Payment</span>
				   <span class="info-box-number"><?php echo $p_tax_payment_count;?></span>
				</div> 
				<!-- /.info-box-content -->
			  </div>
			</a>
			  <!-- /.info-box -->
        </div>
		<div class="col-md-3 col-sm-6 col-xs-12">
			<a href="<?php echo base_url();?>admin/pfdms" class="icon_wrp_bx">
			  <div class="info-box">
				<span class="info-box-icon bg-my-color"><i class="fa fa-money"></i></span>

				<div class="info-box-content">
				  <span class="info-box-text"></span>
				  <span class="info-box-number">Total PF Challan</span>
				   <span class="info-box-number"><?php echo $pf_challan_count;?></span>
				</div> 
				<!-- /.info-box-content -->
			  </div>
			</a>
			  <!-- /.info-box -->
        </div>
		<div class="col-md-3 col-sm-6 col-xs-12">
			<a href="<?php echo base_url();?>admin/pfdms" class="icon_wrp_bx">
			  <div class="info-box">
				<span class="info-box-icon bg-my-color"><i class="fa fa-money"></i></span>

				<div class="info-box-content">
				  <span class="info-box-text"></span>
				  <span class="info-box-number">Total PF Payment</span>
				   <span class="info-box-number"><?php echo $pf_payment_count;?></span>
				</div> 
				<!-- /.info-box-content -->
			  </div>
			</a>
			  <!-- /.info-box -->
        </div>
      </div>     
	<!-- Main row -->
      <!-- /.row -->
    </section>
    <!-- /.content -->	 
  </div>
 
  <!-- /.content-wrapper -->
  
  <style>
  .bg-my-color{background-color: #367fa9}
  .bg-my-color-completed{background-color: #367fa9}
  .bg-my-color-waiting{background-color: #367fa9}
  </style>