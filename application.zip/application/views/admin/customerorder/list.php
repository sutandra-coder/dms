<style>
td.details-control {
    background: url('https://cdn.rawgit.com/DataTables/DataTables/6c7ada53ebc228ea9bc28b1b216e793b1825d188/examples/resources/details_open.png') no-repeat center center;
    cursor: pointer;
}
tr.shown td.details-control {
    background: url('https://cdn.rawgit.com/DataTables/DataTables/6c7ada53ebc228ea9bc28b1b216e793b1825d188/examples/resources/details_close.png') no-repeat center center;
}


</style>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
          <h3>
            Customer Order List
            
          </h3>
          <!--<ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>-->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box box-primary">
            <div class="box-header with-border">
			<div class="admin_tab">
			<ul>
				<li><a href="javascript:void(0);" onclick="window.history.back();">Back</a></li>				
			</ul>
			
				 
							
							<?php if($this->session->flashdata('error_msg')){?>
								<span style="color:red; font-weight:bold"><?php echo $this->session->flashdata('error_msg');?></span>
							<?php }?>
							<?php if($this->session->flashdata('success_msg')){?>
								<span style="color:green; font-weight:bold"><?php  echo $this->session->flashdata('success_msg'); ?></span>
							<?php }?>
			</div>
			<div class="row" >					
				<div class='col-sm-2'>
					<div class="form-group">
						<label>Select Brnad</label>
						<select class="form-control select2" name="brand" id="brand">
							<option value="">Select</option>
							<?php foreach($brand_list as $brand){?>
								<option value= "<?php echo $brand["meta_key_value_id"]?>"><?php echo $brand['meta_key_value'];?></option>
							<?php } ?>							  
						</select>							  
					</div>
				</div>
				<div class='col-sm-2'>
					<div class="form-group">
					 <label>From Date</label>
						<div class='input-group date'>
							<input type='text' class="form-control" placeholder="Start Date" value="<?php echo date('Y-m-01');?>" id="start_date"/>
							<span class="input-group-addon">
								<span class="glyphicon glyphicon-calendar"></span>
							</span>
						</div>
					</div>
				</div>
				<div class='col-sm-2'>
					<div class="form-group">
					 <label>To Date</label>
						<div class='input-group date'>
							<input type='text' class="form-control" placeholder="End Date" value="<?php echo date("Y-m-d");?>" id="end_date"/>
							<span class="input-group-addon">
								<span class="glyphicon glyphicon-calendar"></span>
							</span>
						</div>
					</div>
				</div>
				<div class='col-sm-2'>
					<div class="form-group">
						<label>Select Payment Status</label>
						<select class="form-control select2" name="status" id="status">														
							<option value= "Pending">Pending</option>
							<option value= "Complete">Complete</option>
						</select>							  
					</div>
				</div>
				<div class='col-sm-2'>
					<div class="form-group">
						<label></label>
						<button class="form-control btn-primary" id="btn_filter">Search</button>
					</div>
				</div>				
            </div>
            <!-- /.box-header -->
            <div class="box-body">
				<table id="example" class="table table-bordered table-striped">
					<thead>
						<tr>
									<th></th>
							<th>Order No</th>
							<th>Total Amount</th>
							<th>Payment Status</th>
							<th>Customer Name</th>
							<th>Phone No</th>
							<th>Coupon Code</th>
							<th>Invoice</th>
							<th>Upload Invoice</th>
							<th>Date</th>
						</tr>
					</thead>
					<tfoot>
						<tr>
									<th></th>
							<th>Order No</th>
							<th>Total Amount</th>
							<th>Payment Status</th>
							<th>Customer Name</th>
							<th>Phone No</th>
							<th>Coupon Code</th>
							<th>Invoice</th>
							<th>Upload Invoice</th>
							<th>Date</th>
						</tr>
					</tfoot>
				</table>
				
				 </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  
  <div class="modal" id='myModalImages'>
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span></button>
                <h4 class="modal-title">Upload Invoice</h4>
              </div>
			  
              <div class="modal-body"  title="">
				<span style="font-weight:bold" id="msg_modal2"></span>
				<form method='post' id="myForm" action='' enctype="multipart/form-data">
				<div class="form-group">					
					<input type="file" id='files' name="tmp_name">										
				</div>
				<input type="button" id="submit" value='Upload'>
				</form>				
               <!-- <p>Would you like to continue ?</p>-->
              </div>
              <div class="modal-footer">
			  <input type="hidden" id="transaction_id" name="transaction_id">			  
                <button type="button" class="btn btn-primary" data-dismiss="modal" id="cdel2">Cancel</button>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>

<script src="<?php echo base_url()?>public/admin_assets/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url()?>public/admin_assets/plugins/datatables/dataTables.bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>
<script>
/* Formatting function for row details - modify as you need */
function format ( d ) {
	content = '<table class="table table-bordered table-striped">';	
	content+=' <tr><th>Product Name</th><th>Image</th><th>Product Meta Code</th><th>qty</th><th>Price</th><th>Actual Price</th></tr>';
	$.each( d.customer_product, function( key, value ) {   	
		content+='<tr><td>'+value.product_name+'(';
		$.each( value.met_key_value, function( key, mvalue ) {					
			content+= mvalue+" ";					
		});
	content+=')</td><td><img src="'+value.product_image+'"  width="50" height="50"></td><td>'+value.product_meta_code+'</td><td>'+value.qty+'</td><td>'+value.out_price+'</td><td>'+value.actual_price+'</td>';
		content+="</tr>";
	});
	content+= '</table>';
	return content;
}

$(document).ready(function() {
	var start_date = $('#start_date').val();
	var end_date = $('#end_date').val();
	var status = $('#status').val();
	
    var table = $('#example').DataTable({
		"processing": true,
		"ajax": {            
			"url": "<?php echo site_url('admin/customerorder/all_content_list/')?>"+start_date+'/'+end_date+'/'+status,
			"type": "POST"			
        },
        'columns': [
            {
                'className':      'details-control',
                'orderable':      false,
                'data':           null,
                'defaultContent': ''
            },
            { 'data': 'transaction_id' },
			{ 'data': 'amount' },
            { 'data': 'status' },
            { 'data': 'first_name' },
            { 'data': 'phoneno' },
			{ 'data': 'coupon_code' },
			{ 'data': 'invoice_url'},
			{ 'data': 'upload_invoice'},
			{ 'data':'last_update_ts'}
			
        ],
        'order': [[1, 'asc']]
    } );
	
	

    // Add event listener for opening and closing details
    $('#example tbody').on('click', 'td.details-control', function(){
        var tr = $(this).closest('tr');
        var row = table.row( tr );

        if(row.child.isShown()){
            // This row is already open - close it
            row.child.hide();
            tr.removeClass('shown');
        } else {
            // Open this row
            row.child(format(row.data())).show();
            tr.addClass('shown');
        }
    });

    // Handle click on "Expand All" button
    $('#btn-show-all-children').on('click', function(){
        // Enumerate all rows
        table.rows().every(function(){
            // If row has details collapsed
            if(!this.child.isShown()){
                // Open this row
                this.child(format(this.data())).show();
                $(this.node()).addClass('shown');
            }
        });
    });

    // Handle click on "Collapse All" button
    $('#btn-hide-all-children').on('click', function(){
        // Enumerate all rows
        table.rows().every(function(){
            // If row has details expanded
            if(this.child.isShown()){
                // Collapse row details
                this.child.hide();
                $(this.node()).removeClass('shown');
            }
        });
    });
	
	$('#btn_filter').click(function(){
		var brand = $('#brand').val();
		var start_date = $('#start_date').val();
		var end_date = $('#end_date').val();
		var status = $('#status').val();
		if (brand == '')
		{
			var url = '<?php echo site_url('admin/customerorder/all_content_list/')?>'+start_date+'/'+end_date+'/'+status;
		}else{			
			var url = '<?php echo site_url('admin/customerorder/all_content_list_with_brand/')?>'+start_date+'/'+end_date+'/'+status+'/'+brand;
		}
		table.ajax.url( url ).load();
	});
});

$('#start_date').datepicker({
	maxDate: '0',
	format: 'yyyy-mm-dd',
	setDate: new Date()
});
	
$('#end_date').datepicker({
	maxDate: '0',
	format: 'yyyy-mm-dd',
	setDate: new Date()
});

$(document).on( "click",'#view.cstm_view',function() {
    var id=$(this).prop('title');
	$('#transaction_id').val(id);
	$('#myModalImages').modal('show');
})

$('#submit').click(function(){
	var transaction_id = $('#transaction_id').val();
	var file_data = $("#files").prop("files")[0];   
	var form_data = new FormData();
	form_data.append("files", file_data);
	form_data.append("transaction_id", transaction_id);
	
	$.ajax({
			 url: '<?php echo base_url('admin/customerorder/invoice_upload');?>', 
			 type: 'post',
			 data: form_data,
			 dataType: 'json',
			 contentType: false,
			 processData: false,
			 success: function (response) {
				window.location.reload('<?php echo base_url('admin/customerorder'); ?>');
			 },error:function(){

			}
		   });
});
</script>
