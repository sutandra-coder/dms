 <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
 <script src="<?php echo base_url()?>/public/validation/js/jquery.validate.js"></script>
<!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h3>
            Product Settings
            
          </h3>         
        </section>

        <!-- Main content -->
        <section class="content"> 
			<div class="row">
				<!-- general form elements -->
				<div class="col-md-12">
					  <div class="box box-primary">						 
						<div class="box-header with-border">
						 <div class="admin-tab-wrapper">
							<div class="admin_tab">
								<!--<button class="btn btn-primary dropdown-toggle btn-algnmt" type="button" data-toggle="dropdown">Action
								<span class="caret"></span></button>-->
								<ul>
									<li><a href="<?php echo base_url()."admin/product"; ?>">Back</a></li>
								</ul>
							</div>
						</div>
						  <h3 class="box-title"></h3>
						  <?php if($this->session->flashdata('error_msg')){?>
								<span style="color:red; font-weight:bold"><?php echo $this->session->flashdata('error_msg');?></span>
							<?php }?>
							<?php if($this->session->flashdata('success_msg')){?>
								<span style="color:green; font-weight:bold"><?php  echo $this->session->flashdata('success_msg'); ?></span>
							<?php }?>
						</div>
						<!-- /.box-header -->
						<!-- form start -->
						<form id="signupForm" role="form" class="mtbresize" method="post" action="<?php echo base_url()."admin/product/update"; ?>" enctype="multipart/form-data" autocomplete="off">
						  <div class="box-body">
							<div class="form-group">
								<label for="meta_key_id">Product Type<sup class="superr">*</sup></label>
								<select class="form-control" id="meta_key_id" name="meta_key_id" >
									<option value="">Select</option>
									<?php foreach($meta_key_list as $meta_key){?>	
									<?php if($meta_key["meta_key_id"] == 6 || $meta_key["meta_key_id"] == 7 || $meta_key["meta_key_id"] == 8 || $meta_key["meta_key_id"] == 134){?>
									<option value="<?php echo $meta_key["meta_key_id"]?>" <?php if($cms['category_id'] == $meta_key["meta_key_id"]){echo "selected";}?>><?php echo $meta_key["meta_key"]?></option>									
									<?php } }?>
								</select>							  
								<?php echo form_error('meta_key_id','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="product_name">Name<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="product_name" name="product_name" value="<?php echo $cms['product_name'];?>" placeholder="Name" required="required">
							  <?php echo form_error('product_name','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="short_description">Short Description</label>
							  <textarea id="short_description" class="form-control" name="short_description" rows="10" cols="80"><?php echo $cms['product_short_description'];?></textarea>
							  <?php echo form_error('short_description','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="long_description">Long Description</label>
							  <textarea id="long_description" class="form-control" name="long_description" rows="10" cols="80"><?php echo $cms['product_long_description'];?></textarea>
							  <?php echo form_error('long_description','<span class="error">', '</span>'); ?>
							</div>
						  </div>
						  <!-- /.box-body -->
						  <div class="box-footer">
							<input type="hidden" id="product_id" name="product_id" value="<?php echo $cms['product_id']; ?>">
							<button type="submit" class="btn btn-sm btn-primary">Submit</button>
						  </div>
						</form>
					  </div>
				</div>
          <!-- /.box -->
          </div><!-- /.row -->	
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
<script src="https://cdn.ckeditor.com/4.5.7/standard/ckeditor.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-show-password/1.0.3/bootstrap-show-password.min.js"></script>
<script>
$( "#signupForm" ).validate( {
					rules: {
						product_name: "required",
						meta_key_id:"required"
						
						
					},
					messages: {						
						product_name: {required:"name field is required"},
						meta_key_id: {required:"Category field is required"},
						
					},
					errorElement: "em",
					
					highlight: function ( element, errorClass, validClass ) {
						$( element ).parents( ".form-control" ).addClass( "has-error" ).removeClass( "has-success" );
					},
					unhighlight: function (element, errorClass, validClass) {
						$( element ).parents( ".form-control" ).addClass( "has-success" ).removeClass( "has-error" );
					}
				} );
				
CKEDITOR.replace('short_description');
CKEDITOR.replace('long_description');
</script>