<style>
.cstm_view{font-size:15px;}
.modal-dialog{ width: 1000px;}
</style>
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
          <h3>
            Product List
            
          </h3>
          <!--<ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>-->
		  
    </section>
	

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box box-primary">
            <div class="box-header with-border">
			<div class="admin_tab">
				<ul>
					<li><a href="javascript:void(0);" onclick="window.history.back();">Back</a></li>
					<li><a href="product/add">Add</a></li>
				</ul>
			
							
							
							<?php if($this->session->flashdata('error_msg')){?>
								<span style="color:red; font-weight:bold"><?php echo $this->session->flashdata('error_msg');?></span>
							<?php }?>
							<?php if($this->session->flashdata('success_msg')){?>
								<span style="color:green; font-weight:bold"><?php  echo $this->session->flashdata('success_msg'); ?></span>
							<?php }?>
				</div>
				<div class="row" >
					<form id="signupForm" role="form"  method="post" action="<?php echo base_url()."admin/product"; ?>" enctype="multipart/form-data" autocomplete="off">
					<!--<div class='col-sm-2'>
						<div class="form-group">
							<label>Select Category</label>
							<select class="form-control select2" name="meta_key_id">
								<option value="">Select All</option>
								<?php foreach($meta_key_list as $meta_key){?>	
								<?php if($meta_key["meta_key_id"] == 6 || $meta_key["meta_key_id"] == 7 || $meta_key["meta_key_id"] == 8 ){?>
								<option value="<?php echo $meta_key["meta_key_id"]?>"><?php echo $meta_key["meta_key"]?></option>									
								<?php } }?>							  
							</select>							  
						</div>
					</div> -->
					<div class='col-sm-2'>
						<div class="form-group">
							<label>Select Offer</label>
							<select class="form-control select2" name="offer" id="id_select2_example">
								<option value="">Select</option>
								<?php foreach($offer_list as $offer){?>
								 <option value= "<?php echo $offer["offer_id"]?>" data-img_src="<?php echo $offer['offer_image']; ?>"></option>
								<?php } ?>							  
							</select>							  
						</div>
					</div>					
					<div class='col-sm-2'>
						<div class="form-group">
							<label>Select Brnad</label>
							<select class="form-control select2" name="brand" id="brand">
								<option value="">Select</option>								
								<?php foreach($brand_list as $brand){?>
								 <option value= "<?php echo $brand["meta_key_value_id"]?>"><?php echo $brand['meta_key_value'];?></option>
								<?php } ?>							  
							</select>							  
						</div>
					</div>
					<div class='col-sm-2'>
						<div class="form-group">
							<label>Select Category</label>
							<select class="form-control select2" name="category" id="category">
								<option value="">Select</option>
								<?php foreach($category_list as $category){?>
								 <option value= "<?php echo $category["meta_key_value_id"]?>"><?php echo $category['meta_key_value'];?></option>
								<?php } ?>							  
							</select>							  
						</div>
					</div>
					<!--<div class='col-sm-2'>
						<div class="form-group">
							<label></label>
							<button type="submit" class="form-control btn-primary">submit</button>							
						</div>
					</div> -->
					</form>
				</div>	
				<div class="row" >
				<form id="signupForm" role="form"  method="post" action="<?php echo base_url()."admin/product"; ?>" enctype="multipart/form-data" autocomplete="off">				
				<div class='col-sm-2'>				
					<div class="form-group">
						<label>Select Brnad</label>
						<select class="form-control select2" name="search_brand_id" id="search_brand_id">							
							<?php foreach($brand_list as $brand){?>
								<option value= "<?php echo $brand["meta_key_value_id"]?>" <?php if($brand_id == $brand["meta_key_value_id"]){echo "selected";} ?>><?php echo $brand['meta_key_value'];?></option>
							<?php } ?>		
							<option value="other"<?php if($brand_id == "other"){echo "selected";} ?>>others</option>
						</select>							  
					</div>
				</div>	
				<div class='col-sm-2'>
						<div class="form-group">
							<label>Select Category</label>
							<select class="form-control select2" name="meta_key_id">								
								<?php foreach($meta_key_list as $meta_key){?>	
								<?php if($meta_key["meta_key_id"] == 6 || $meta_key["meta_key_id"] == 7 || $meta_key["meta_key_id"] == 8 || $meta_key["meta_key_id"] == 134 ){?>
								<option value="<?php echo $meta_key["meta_key_id"]?>" <?php if($category_id == $meta_key["meta_key_id"]){echo "selected";} ?>><?php echo $meta_key["meta_key"]?></option>									
								<?php } }?>							  
							</select>							  
						</div>
					</div>				
				<div class='col-sm-2'>
					<div class="form-group">
						<label></label>
						<button class="form-control btn-primary" id="btn_filter">Search</button>
					</div>
				</div>
				</form>				
            </div>				
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example" class="table table-bordered table-striped">
                <thead>
                <tr>
				 <th class="text-center"></th>
				  <th class="text-center">Sl. NO.</th>
				  <th class="text-center">Product Name</th>
				  <th class="text-center">Product Type</th>
				  <th class="text-center">Offer</th>				  
				  <th class="text-center">Brand</th>
				  <th class="text-center">Category</th>
				  <th class="text-center">Product Variation List</th>
				  <th class="no-sort">Add Product Variation</th>
				  <th class="text-center">Status</th>
				  <th class="no-sort">Edit</th>
                </tr>
                </thead>
                <tbody>
					<?php $i=1; foreach($post_data as $row){ ?>
					<tr>
						<td class="text-center">
                          <input type="checkbox" value="<?php echo $row['product_id'];?>"></td>
                        </td> 
						<td class="text-center">
                          <?php echo $i;?>
                        </td> 
						<td class="text-center">
                          <?php echo $row['product_name'];?>
                        </td> 
						<td class="text-center">
                          <?php echo $row['meta_key'];?>
                        </td>
						<td class="text-center">
							<?php if($row['offer_image'] != ''){?>
                          <a class="cstm_view" id="delete_product_offer" style="padding-left:5px" href="javascript:void(0)" title="<?php echo  $row['product_id']; ?>" delete_offer_id="<?php echo $row['offer_id'];?>"><img src="<?php echo $row['offer_image'];?>"  width="50" height="60"></a>
							<?php }else{ ?>
							No Offer Chosen
							<?php } ?>
                        </td>						
						<td class="text-center">
                          <a class="cstm_view" id="delete_product_brand" style="padding-left:5px" href="javascript:void(0)" title="<?php echo  $row['product_id']; ?>" delete_brand_id="<?php echo $row['brand_id'];?>"><?php echo $row['brand'];?></a>
                        </td>
						<td class="text-center">
                          <a class="cstm_view" id="delete_product_category" style="padding-left:5px" href="javascript:void(0)" title="<?php echo  $row['product_id']; ?>" delete_category_id="<?php echo $row['category_id'];?>"><?php echo $row['category'];?></a>
                        </td>
						<td class="text-center">
                          <a class="cstm_view" id="view" style="padding-left:5px" href="javascript:void(0)" title="<?php echo  $row['product_id']; ?>"><i class="glyphicon glyphicon-eye-open"></i></a>
                        </td>
						<td class="text-center">
                          <a class="cstm_view" id="add_product_meta" title="<?php echo  $row['product_id']; ?>" class="btn btn-info"><span class="glyphicon glyphicon-plus-sign"></span></a>
                        </td>
						<?php if($row['status'] == 1){?>
							<td class="text-center">
							  <a class="cstm_view_status" id="active" href="javascript:void(0)" title="<?php echo $row['product_id']?>"><span class="glyphicon glyphicon-ok"></span></a>
							</td>
						<?php }else{ ?>
							<td class="text-center">
								<a class="cstm_view_status" id="inactive" href="javascript:void(0)" title="<?php echo $row['product_id']?>"><span class="glyphicon glyphicon-remove"></span></a>								
							</td>
						<?php } ?>
						<td class="text-center">
                          <a href="<?php echo base_url('admin/product/details/'.$row['product_id']); ?>" ><span class="glyphicon glyphicon-pencil"></span></a>
                        </td>
						
					</tr>
					<?php $i++;} ?>
				</tbody>
                <tfoot>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  
  <div class="modal" id='myModal2'>
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span></button>
                <h4 class="modal-title"><span id="product_name"></span> Variation List</h4>
              </div>
			  
              <div class="modal-body"  title="">
				<span style="font-weight:bold" id="msg_modal2"></span>
				<!--<div class="form-group">
						<label for="discount_id">Discount</label>
						<select class="form-control" id="discount_id" name="discount_id" >
							<option value="">Select</option>
							<?php foreach($discount_list as $discount){?>							
							<option value="<?php echo $discount["discount_id"]?>"><?php echo $discount["discount"]?></option>									
							<?php } ?>
						</select>							  
						<?php echo form_error('discount_id','<span class="error">', '</span>'); ?>
				</div> -->
				<div id='modalContent2'>
				</div>
               <!-- <p>Would you like to continue ?</p>-->
              </div>
              <div class="modal-footer">
			  <input type="hidden" id="product_id_list" name="product_id_list">
			  <!-- <button type="button" class="btn btn-primary" id="save_product_meta_discount">Save</button> -->
                <button type="button" class="btn btn-primary" data-dismiss="modal" id="cdel2">Cancel</button>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
		
		<div class="modal" id='myModalImages'>
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span></button>
                <h4 class="modal-title"><span id="product_meta_images_name"></span></h4>
              </div>
			  
              <div class="modal-body"  title="">
				<span style="font-weight:bold" id="msg_modal2"></span>
				<form method='post' id="myForm" action='' enctype="multipart/form-data">
				<div class="form-group">
					<label for="imgInp">Select Images</label>
					<input type="file" id='files' name="tmp_name[]" multiple>
					<input type="button" id="submit" value='Upload'>					
				</div>	
				</form>
				<div id='modalContentImages'>						
				</div>
               <!-- <p>Would you like to continue ?</p>-->
              </div>
              <div class="modal-footer">
			  <input type="hidden" id="product_meta_id_image" name="product_meta_id_image">			  
                <button type="button" class="btn btn-primary" data-dismiss="modal" id="cdel2">Cancel</button>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
		
		<div class="modal" id='myModalImagesGallery'>
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span></button>
                <h4 class="modal-title"><span id="product_meta_images_name"></span></h4>
              </div>
			  
              <div class="modal-body"  title="">
				<span style="font-weight:bold" id="msg_modal2"></span>
				<form method='post' id="myForm" action='' enctype="multipart/form-data">
				<div class="form-group">
					<label for="imgInp">Select Images</label>
					<input type="file" id='filesg' name="tmp_name[]" multiple>
					<input type="button" id="submitG" value='Upload'>					
				</div>	
				</form>
				<div id='modalContentImagesGallery'>						
				</div>
               <!-- <p>Would you like to continue ?</p>-->
              </div>
              <div class="modal-footer">
			  <input type="hidden" id="product_meta_id_image" name="product_meta_id_image">			  
                <button type="button" class="btn btn-primary" data-dismiss="modal" id="cdel2">Cancel</button>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
		
		<div class="modal" id='myModal_add_product'>
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span></button>
                <h4 class="modal-title">Add Product Variation</h4>
              </div>
              <div class="modal-body" id='modalContent_add_product' title="">
			  <span style="font-weight:bold" id="msg_product_variation"></span>
			  <div id="meta_key_value">
				   <div class="form-group">
						<label for="meta_key_id">Category<sup class="superr">*</sup></label>
						<select class="form-control" id="meta_key_id" name="meta_key_id" >
							<option value="">Select</option>
							<?php foreach($meta_key_list as $meta_key){?>	
							<?php if($meta_key["meta_key_id"] == 3 ){?>
							<option value="<?php echo $meta_key["meta_key_id"]?>"><?php echo $meta_key["meta_key"]?></option>									
							<?php } }?>
						</select>							  
						<?php echo form_error('meta_key_id','<span class="error">', '</span>'); ?>
					</div>
					<div class="form-group">
						<label for="meta_key_id">Category Values<sup class="superr">*</sup></label>
						<select class="form-control" name="meta_key_value_id" id="meta_key_value_id">
						</select>							  
						<?php echo form_error('meta_key_id','<span class="error">', '</span>'); ?>
					</div>
					<div class="form-group">
						<label for="meta_key_id">Category<sup class="superr">*</sup></label>
						<select class="form-control" id="meta_key_id_1" name="meta_key_id" >
							<option value="">Select</option>
							<?php foreach($meta_key_list as $meta_key){?>	
							<?php if($meta_key["meta_key_id"] == 5 ){?>
							<option value="<?php echo $meta_key["meta_key_id"]?>"><?php echo $meta_key["meta_key"]?></option>									
							<?php } }?>
						</select>							  
						<?php echo form_error('meta_key_id','<span class="error">', '</span>'); ?>
					</div>
					<div class="form-group">
						<label for="meta_key_id">Category Values<sup class="superr">*</sup></label>
						<select class="form-control" name="meta_key_value_id" id="meta_key_value_id_1">
						</select>							  
						<?php echo form_error('meta_key_id','<span class="error">', '</span>'); ?>
					</div>
					<div class="form-group">
						<label for="meta_key_id">Category<sup class="superr">*</sup></label>
						<select class="form-control" id="meta_key_id_2" name="meta_key_id" >
							<option value="">Select</option>
							<?php foreach($meta_key_list as $meta_key){?>	
							<?php if($meta_key["meta_key_id"] == 4 ){?>
							<option value="<?php echo $meta_key["meta_key_id"]?>"><?php echo $meta_key["meta_key"]?></option>									
							<?php } }?>
						</select>							  
						<?php echo form_error('meta_key_id','<span class="error">', '</span>'); ?>
					</div>
					<div class="form-group">
						<label for="meta_key_id">Category Values<sup class="superr">*</sup></label>
						<select class="form-control" name="meta_key_value_id" id="meta_key_value_id_2">
						</select>							  
						<?php echo form_error('meta_key_id','<span class="error">', '</span>'); ?>
					</div>
					<!--<div class="form-group">
						<label for="meta_key_id">Category<sup class="superr">*</sup></label>
						<select class="form-control" id="meta_key_id" name="meta_key_id_9" >
							<option value="">Select</option>
							<?php foreach($meta_key_list as $meta_key){?>	
							<?php if($meta_key["meta_key_id"] == 9 ){?>
							<option value="<?php echo $meta_key["meta_key_id"]?>"><?php echo $meta_key["meta_key"]?></option>									
							<?php } }?>
						</select>							  
						<?php echo form_error('meta_key_id','<span class="error">', '</span>'); ?>
					</div>
					<div class="form-group">
						<label for="meta_key_id">Category Values<sup class="superr">*</sup></label>
						<select class="form-control" name="meta_key_value_id" id="meta_key_value_id_9">
						</select>							  
						<?php echo form_error('meta_key_id','<span class="error">', '</span>'); ?>
					</div>-->
					<!-- <a href="#" class="btn btn-info" role="button" id="add_more_meta_key_value">+</a>-->					
				</div>
				<div class="form-group">
					<label for="in_price">In Price<sup class="superr">*</sup></label>
					<input type="text" class="form-control" id="in_price" name="in_price" value="<?php echo set_value('in_price');?>" placeholder="In price" required="required">
					<?php echo form_error('in_price','<span class="error">', '</span>'); ?>
				</div>
				<div class="form-group">
					<label for="out_price">Out Price<sup class="superr">*</sup></label>
					<input type="text" class="form-control" id="out_price" name="out_price" value="<?php echo set_value('out_price');?>" placeholder="Out price" required="required">
					<?php echo form_error('out_price','<span class="error">', '</span>'); ?>
				</div>
				<div class="form-group">
					<label for="product_meta_code">Product Meta Code<sup class="superr">*</sup></label>
					<input type="text" class="form-control" id="product_meta_code" name="product_meta_code" value="<?php echo set_value('product_meta_code');?>" placeholder="Product Meta Code" required="required">
					<?php echo form_error('product_meta_code','<span class="error">', '</span>'); ?>
				</div>					
				<input type="hidden" id="counter" name="counter">
				<input type="hidden" id="product_id" name="product_id">
				</div>
              <div class="modal-footer">
				<button type="button" class="btn btn-primary" id="save_product_meta">Save</button>
                <button type="button" class="btn btn-primary" data-dismiss="modal" id="cdel2">Cancel</button>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
		
		<div class="modal" id='myModal_edit_product'>
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span></button>
                <h4 class="modal-title"><span id="product_meta_details"></span></h4>
              </div>
              <div class="modal-body" id='modalContent_edit_product' title="">
			  <span style="font-weight:bold" id="msg"></span>
				<div class="form-group">
					<label for="edit_in_price">In Price<sup class="superr">*</sup></label>
					<input type="text" class="form-control" id="edit_in_price" name="edit_in_price" value="<?php echo set_value('edit_in_price');?>" placeholder="In price" required="required">
					<?php echo form_error('edit_in_price','<span class="error">', '</span>'); ?>
				</div>
				<div class="form-group">
					<label for="edit_out_price">Out Price<sup class="superr">*</sup></label>
					<input type="text" class="form-control" id="edit_out_price" name="edit_out_price" value="<?php echo set_value('edit_out_price');?>" placeholder="Out price" required="required">
					<?php echo form_error('edit_out_price','<span class="error">', '</span>'); ?>
				</div>
				<div class="form-group">
					<label for="edit_product_meta_code">Product Meta Code<sup class="superr">*</sup></label>
					<input type="text" class="form-control" id="edit_product_meta_code" name="edit_product_meta_code" value="<?php echo set_value('edit_product_meta_code');?>" placeholder="Product Meta Code" required="required">
					<?php echo form_error('edit_product_meta_code','<span class="error">', '</span>'); ?>
				</div>	
				<div class="form-group">
					<label for="edit_loyality_point">Loyalty Points<sup class="superr">*</sup></label>
					<input type="text" class="form-control" id="edit_loyality_point" name="edit_loyality_point" value="<?php echo set_value('edit_loyality_point');?>" placeholder="Loyality Point" required="required">
					<?php echo form_error('edit_loyality_point','<span class="error">', '</span>'); ?>
				</div>
				<div class="form-group">
					<label for="edit_Rea_Camera_Lens_1">Rear Camera Lens 1<sup class="superr">*</sup></label>
					<input type="text" class="form-control" id="edit_Rea_Camera_Lens_1" name="edit_Rea_Camera_Lens_1" value="<?php echo set_value('Rea_Camera_Lens_1');?>" placeholder="Rea Camera Lens 1">
					<?php echo form_error('edit_Rea_Camera_Lens_1','<span class="error">', '</span>'); ?>
				</div>
				<div class="form-group">
					<label for="edit_Rea_Camera_Lens_2">Rear Camera Lens 2<sup class="superr">*</sup></label>
					<input type="text" class="form-control" id="edit_Rea_Camera_Lens_2" name="edit_Rea_Camera_Lens_2" value="<?php echo set_value('Rea_Camera_Lens_2');?>" placeholder="Rea Camera Lens 2">
					<?php echo form_error('edit_Rea_Camera_Lens_1','<span class="error">', '</span>'); ?>
				</div>
				<div class="form-group">
					<label for="edit_screen_size">Screen Size<sup class="superr">*</sup></label>
					<input type="text" class="form-control" id="edit_Screen_Size" name="edit_Screen_Size" value="<?php echo set_value('edit_Screen_Size');?>" placeholder="Screen Size">
					<?php echo form_error('edit_screen_size','<span class="error">', '</span>'); ?>
				</div>
				<div class="form-group">
					<label for="edit_Screen_type">Screen Type<sup class="superr">*</sup></label>
					<input type="text" class="form-control" id="edit_Screen_Type" name="edit_Screen_type" value="<?php echo set_value('edit_Screen_type');?>" placeholder="Screen Type">
					<?php echo form_error('edit_Screen_type','<span class="error">', '</span>'); ?>
				</div>
				<div class="form-group">
					<label for="edit_Battery_Power">Battery Power<sup class="superr">*</sup></label>
					<input type="text" class="form-control" id="edit_Battery_Power" name="edit_Battery_Power" value="<?php echo set_value('edit_Battery_Power');?>" placeholder="Battery Power">
					<?php echo form_error('edit_Battery_Power','<span class="error">', '</span>'); ?>
				</div>
				<div class="form-group">
					<label for="edit_Inbuilt_Storage">Inbuilt Storage<sup class="superr">*</sup></label>
					<input type="text" class="form-control" id="edit_Inbuilt_Storage" name="edit_Inbuilt_Storage" value="<?php echo set_value('edit_Inbuilt_Storage');?>" placeholder="Inbuilt Storage">
					<?php echo form_error('edit_Inbuilt_Storage','<span class="error">', '</span>'); ?>
				</div>
				<div class="form-group">
					<label for="edit_RAM">RAM<sup class="superr">*</sup></label>
					<input type="text" class="form-control" id="edit_RAM" name="edit_RAM" value="<?php echo set_value('edit_RAM');?>" placeholder="RAM">
					<?php echo form_error('edit_RAM','<span class="error">', '</span>'); ?>
				</div>
				<div class="form-group">
					<label for="edit_Expandable_Storage">Expandable Storage<sup class="superr">*</sup></label>
					<input type="text" class="form-control" id="edit_Expandable_Storage" name="edit_Expandable_Storage" value="<?php echo set_value('edit_Expandable_Storage');?>" placeholder="Expandable Storage">
					<?php echo form_error('edit_Expandable_Storage','<span class="error">', '</span>'); ?>
				</div>
				<div class="form-group">
					<label for="edit_Processor_Brand">Processor Brand<sup class="superr">*</sup></label>
					<input type="text" class="form-control" id="edit_Processor_Brand" name="edit_Processor_Brand" value="<?php echo set_value('edit_Processor_Brand');?>" placeholder="Processor Brand">
					<?php echo form_error('edit_Processor_Brand','<span class="error">', '</span>'); ?>
				</div>
				<div class="form-group">
					<label for="edit_Operating_System">Operating System<sup class="superr">*</sup></label>
					<input type="text" class="form-control" id="edit_Operating_System" name="edit_Operating_System" value="<?php echo set_value('edit_Operating_System');?>" placeholder="Operating System">
					<?php echo form_error('edit_Operating_System','<span class="error">', '</span>'); ?>
				</div>
				<input type="hidden" id="product_id_edit_product_meta" name="product_id_edit_product_meta">
				<input type="hidden" id="product_meta_id" name="product_meta_id">
				</div>
              <div class="modal-footer">
				<button type="button" class="btn btn-primary" id="edit_product_meta">Save</button>
                <button type="button" class="btn btn-primary" data-dismiss="modal" id="cdel2">Cancel</button>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
		
		<div class="modal" id='myModal_stock'>
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span></button>
                <h4 class="modal-title">Retailer List</h4>
              </div>
			  
              <div class="modal-body"  title="">
				<span style="font-weight:bold" id="msg_modal2"></span>				
				<div id='modalContent_stock'>
				</div>
               <!-- <p>Would you like to continue ?</p>-->
              </div>
              <div class="modal-footer">
			  <input type="hidden" id="stock_product_meta_id" name="stock_product_meta_id">			  
                <button type="button" class="btn btn-primary" data-dismiss="modal" id="cdel2">Cancel</button>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
		
		<div class="modal" id='myModal_edit_stock'>
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span></button>
                <h4 class="modal-title">Edit Stock</h4>
              </div>
              <div class="modal-body" id='modalContent_edit_product_stock' title="">
			  <span style="font-weight:bold" id="msg"></span>				
				 <div class="form-group">
					<label for="edit_product_meta_stock">stock<sup class="superr">*</sup></label>
					<select class="form-control" id="edit_product_meta_stock" name="edit_product_meta_stock" >
						<option value="">Select</option>
						<option value="1">In Stock</option>		
						<option value="2">Out Of Stock</option>
					</select>							  
					<?php echo form_error('edit_product_meta_stock','<span class="error">', '</span>'); ?>
				</div>		
				
				<input type="hidden" id="retailer_store_id" name="retailer_store_id">
				</div>
              <div class="modal-footer">
				<button type="button" class="btn btn-primary" id="retailer_stock_update">Save</button>
                <button type="button" class="btn btn-primary" data-dismiss="modal" id="cdel2">Cancel</button>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>

<script src="<?php echo base_url()?>public/admin_assets/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url()?>public/admin_assets/plugins/datatables/dataTables.bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.js"></script>
<script>
var  table = $('#example').dataTable({
    'bLengthChange': false,
    'searching': true,
    'paging':   true,  // Table pagination
    'ordering': false,  // Column ordering
    'info':     true,  // Bottom left status text
    'responsive': true, // https://datatables.net/extensions/responsive/examples/
    // Text translation options
    // Note the required keywords between underscores (e.g _MENU_)
    oLanguage: {
        // sSearch:      'Search all columns:',
        sLengthMenu:  '_MENU_ records per page',
        info:         'Showing page _PAGE_ of _PAGES_',
        zeroRecords:  'Nothing found - sorry',
        infoEmpty:    'No records available',
        infoFiltered: '(filtered from _MAX_ total records)'
    },
    // set columns options
    'aoColumns': [
    {'bVisible':true},
    {'bVisible':true},
    {'bVisible':true},
	{'bVisible':true},
	{'bVisible':true},
	{'bVisible':true},
	{'bVisible':true},
	{'bVisible':true},
	{'bVisible':true},
	{'bVisible':true},
	{'bVisible':true}
    ]
  });
  
  function custom_template(obj){
            var data = $(obj.element).data();
            var text = $(obj.element).text();
            if(data && data['img_src']){
                img_src = data['img_src'];
                template = $("<div><img src=\"" + img_src + "\" style=\"width:20px;height:20px;\"/></div>");
                return template;
            }
        }
    var options = {
        'templateSelection': custom_template,
        'templateResult': custom_template,
    }
    $('#id_select2_example').select2(options);
	$('#id_select2_example_new_arrival').select2(options);
    $('.select2-container--default .select2-selection--single').css({'height': '35px'});
	
	
  
  $(document).on( "click",'#view.cstm_view',function() {
    var id=$(this).prop('title');
    var content='<div class="box-body" style="height:300px;overflow-y:scroll;"><table id="product_list" class="table table-bordered">';
    $.ajax({
      type:'POST',
      url :'<?php echo base_url('admin/product/meta_list');?>',
      data:'product_id='+id,
      dataType:'json',
      success:function(result){		  
			var i=1;
			content+=' <tr><th>Sl No</th><th>Product Name</th><th>Product Meta Code</th><th>In Price</th><th>Out Price</th><th>Loyalty Points</th><th>Stock</th><th>Add Product Images</th><th>Add Gallery</th><th>Edit</th><th>Delete</th><th>Best Selling</th><th>Top Selling</th><th>Latest Product</th></tr>';
			$.each( result.responseList, function( key, value ) {				
				if(value.latest_product == 1)
				{
					latest_product = '<a class="cstm_view_latest_product" id="active" href="javascript:void(0)" title="'+value.product_meta_id+'"><span class="glyphicon glyphicon-ok"></span></a>';
				}else{
					latest_product = '<a class="cstm_view_latest_product" id="inactive" href="javascript:void(0)" title="'+value.product_meta_id+'"><span class="glyphicon glyphicon-remove"></span></a>';
				}
				if(value.top_selling_product == 1)
				{
					top_selling_product = '<a class="cstm_view_top_selling" id="active" href="javascript:void(0)" title="'+value.product_meta_id+'"><span class="glyphicon glyphicon-ok"></span></a>';
				}else{
					top_selling_product = '<a class="cstm_view_top_selling" id="inactive" href="javascript:void(0)" title="'+value.product_meta_id+'"><span class="glyphicon glyphicon-remove"></span></a>';
				}
				
				if(value.best_selling_product == 1)
				{
					best_selling_product = '<a class="cstm_view_best_selling" id="active" href="javascript:void(0)" title="'+value.product_meta_id+'"><span class="glyphicon glyphicon-ok"></span></a>';
				}else{
					best_selling_product = '<a class="cstm_view_best_selling" id="inactive" href="javascript:void(0)" title="'+value.product_meta_id+'"><span class="glyphicon glyphicon-remove"></span></a>';
				}
				
				var add_image = '<a class="cstm_view" id="add_images" href="javascript:void(0)" title="'+value.product_meta_id+'"><span class="glyphicon glyphicon-plus-sign"></span></a>';
				
				var add_image_gallery = '<a class="cstm_view" id="add_image_gallery" href="javascript:void(0)" title="'+value.product_meta_id+'"><span class="glyphicon glyphicon-plus-sign"></span></a>';
				
				delete_view = '<a class="cstm_view" id="delete_product_meta" href="javascript:void(0)" title="'+value.product_meta_id+'" class="btn btn-info"><span class="glyphicon glyphicon-minus-sign"></span></a>';
				edit_view = '<a class="cstm_view" id="edit_product_meta_view" href="javascript:void(0)" title="'+value.product_meta_id+'" class="btn btn-info"><span class="glyphicon glyphicon-pencil"></span></a>';
				
				stock_view = '<a class="cstm_view" id="stock_view" href="javascript:void(0)" title="'+value.product_meta_id+'" class="btn btn-info"><span class="glyphicon glyphicon-plus"></span></a>';
				
				content+=' <tr><td>'+i+'</td><td>'+value.product_name+'(';
				
				$.each( value.met_key_value, function( key, mvalue ) {					
					content+= mvalue+" ";					
				});
				//content+= value.met_key_value.Storage+','+value.met_key_value.Color+','+value.met_key_value.Ram
				content+= ')</td><td>'+value.product_meta_code+'</td><td>'+value.in_price+'</td><td>'+value.out_price+'</td><td>'+value.loyalty_points+'</td><td>'+stock_view+'</td><td>'+add_image+'</td><td>'+add_image_gallery+'</td><td>'+edit_view+'</td><td>'+delete_view+'</td><td>'+best_selling_product+'</td><td>'+top_selling_product+'</td><td>'+latest_product+'</td></tr>';
				
				 i++;
				 content+='</hr>';
			});
			
			content+='</table></div>';
			$('#product_id_list').val(id);
			$('#product_name').html(result.productDetails.product_name);
			$('#modalContent2').html(content);  
			$('#myModal2').modal('show');
		 },error:function(){

		  }
		});
	  });	
	  
	$(document).on( "click",'#add_product_meta.cstm_view',function() {
    var id=$(this).prop('title');
	$("#product_id").val(id);
	$('#modalContent_add_product').html();  
	$('#myModal_add_product').modal('show');
	});
	
	$(document).on( "click",'#delete_product_brand.cstm_view',function() {
		var product_id=$(this).prop('title');
		var brand_id = $(this).attr('delete_brand_id');
		$.ajax({
			  type:'POST',
			  url :'<?php echo base_url('admin/product/delete_product_brand');?>',
			   data:'product_id='+product_id+'&brand_id='+brand_id,
			  dataType:'json',
			  success:function(result){
				window.location.reload('<?php echo base_url('admin/product'); ?>');
			},error:function(){

			}
		});
	});
	
	$(document).on( "click",'#delete_product_category.cstm_view',function() {
		var product_id=$(this).prop('title');
		var category_id = $(this).attr('delete_category_id');
		$.ajax({
			  type:'POST',
			  url :'<?php echo base_url('admin/product/delete_product_category');?>',
			   data:'product_id='+product_id+'&category_id='+category_id,
			  dataType:'json',
			  success:function(result){
				window.location.reload('<?php echo base_url('admin/product'); ?>');
			},error:function(){

			}
		});
	});
	
	$(document).on( "click",'#delete_product_offer.cstm_view',function() {
		var product_id=$(this).prop('title');
		var offer_id = $(this).attr('delete_offer_id');
		$.ajax({
			  type:'POST',
			  url :'<?php echo base_url('admin/product/delete_product_offer');?>',
			   data:'product_id='+product_id+'&offer_id='+offer_id,
			  dataType:'json',
			  success:function(result){
				window.location.reload('<?php echo base_url('admin/product'); ?>');
			},error:function(){

			}
		});
	});
	
	$(document).on( "click",'#delete_product_new_arrival.cstm_view',function() {
		var product_id=$(this).prop('title');
		var new_arrival_id = $(this).attr('delete_new_arrival_id');
		$.ajax({
			  type:'POST',
			  url :'<?php echo base_url('admin/product/delete_product_new_arrival');?>',
			   data:'product_id='+product_id+'&new_arrival_id='+new_arrival_id,
			  dataType:'json',
			  success:function(result){
				window.location.reload('<?php echo base_url('admin/product'); ?>');
			},error:function(){

			}
		});
	});
  
	$( "#meta_key_id" ).change(function() {
		var content ='';
		var meta_key_id = $(this).val();
		$.ajax({
			  type:'POST',
			  url :'<?php echo base_url('admin/product/meta_key_valuelist');?>',
			   data:'meta_key_id='+meta_key_id,
			  dataType:'json',
			  success:function(result){
				$.each( result.responseList, function( key, value ) {
					content+='<option value="'+value.meta_key_value_id+'">'+value.meta_key_value+'</option>';			  
					$("#meta_key_value_id").html(content);
				});					
			},error:function(){

			}
		});
	});
	
	$( "#meta_key_id_1" ).change(function() {
		var content ='';
		var meta_key_id = $(this).val();
		$.ajax({
			  type:'POST',
			  url :'<?php echo base_url('admin/product/meta_key_valuelist');?>',
			   data:'meta_key_id='+meta_key_id,
			  dataType:'json',
			  success:function(result){
				$.each( result.responseList, function( key, value ) {
					content+='<option value="'+value.meta_key_value_id+'">'+value.meta_key_value+'</option>';			  
					$("#meta_key_value_id_1").html(content);
				});					
			},error:function(){

			}
		});
	});
	
	$( "#meta_key_id_2" ).change(function() {
		var content ='';
		var meta_key_id = $(this).val();
		$.ajax({
			  type:'POST',
			  url :'<?php echo base_url('admin/product/meta_key_valuelist');?>',
			   data:'meta_key_id='+meta_key_id,
			  dataType:'json',
			  success:function(result){
				$.each( result.responseList, function( key, value ) {
					content+='<option value="'+value.meta_key_value_id+'">'+value.meta_key_value+'</option>';			  
					$("#meta_key_value_id_2").html(content);
				});					
			},error:function(){

			}
		});
	});
	
	$(document).on( "click",'#add_images.cstm_view',function() {
		var id=$(this).prop('title');
		$("#product_meta_id_image").val(id);
		var content='<div class="box-body" style="height:300px;overflow-y:scroll;"><table id="product_meta_image_list" class="table table-bordered">';
		$.ajax({
			  type:'POST',
			  url :'<?php echo base_url('admin/product/product_meta_images');?>',
			   data:'product_meta_id='+id,
			  dataType:'json',
			  success:function(result){
				  var content_product = result.responseList.product_name+" (";
					$.each( result.responseList.met_key_value, function( key, mvalue ) {					
						content_product+= mvalue+" ";					
					});
					content_product+= ")";
			
				  $('#product_meta_images_name').html(content_product);
				if(result.cms.length == ''){
					$("#modalContentImages").html('');
					$('#myModalImages').modal('show');
				}else{					
					var i = 1;  
					content+=' <tr><th>Sl No</th><th>Image</th><th>Default Image</th><th>Delete</th></tr>';
					$.each( result.cms, function( key, value ) {
						if (value.image_type	== 1){
							var image_link = '<img src="'+value.image+'"  width="50" height="50">';
						}else{
							var image_link = '<video width="50" height="50" controls><source src="'+value.image+'" type="video/mp4"></video>';
						}
						delete_image_view = '<a class="cstm_view" id="delete_product_meta_image" href="javascript:void(0)" title="'+value.product_image_id+'" class="btn btn-info"><span class="glyphicon glyphicon-minus-sign"></span></a>';	
						if(value.default_image_flag == 1){
							default_image_flag_view = '<a class="cstm_view" id="default_image_flag" href="javascript:void(0)" title="'+value.product_image_id+'" class="btn btn-info"><span class="glyphicon glyphicon-check"></span></a>';	
						}else{
							default_image_flag_view = '<a class="cstm_view" id="default_image_flag" href="javascript:void(0)" title="'+value.product_image_id+'" class="btn btn-info"><span class="glyphicon glyphicon-unchecked"></span></a>';
						}
						content+= '<tr><td>'+i+'</td><td>'+image_link+'</td><td>'+default_image_flag_view+'</td><td>'+delete_image_view+'</td></tr>';			  
						$("#modalContentImages").html(content);						
						$('#myModalImages').modal('show');
						i++;
					});		
				}				
			},error:function(){
				$('#myModalImages').modal('show');
			}
		});
		
	});
	
	$(document).on( "click",'#add_image_gallery.cstm_view',function() {
		var id=$(this).prop('title');
		$("#product_meta_id_image").val(id);
		var content='<div class="box-body" style="height:300px;overflow-y:scroll;"><table id="product_meta_image_list" class="table table-bordered">';
		$.ajax({
			  type:'POST',
			  url :'<?php echo base_url('admin/product/product_meta_images_gallery');?>',
			   data:'product_meta_id='+id,
			  dataType:'json',
			  success:function(result){
				  var content_product = result.responseList.product_name+" (";
					$.each( result.responseList.met_key_value, function( key, mvalue ) {					
						content_product+= mvalue+" ";					
					});
					content_product+= ")";
			
				  $('#product_meta_images_name').html(content_product);
				if(result.cms.length == ''){
					$("#modalContentImagesGallery").html('');
					$('#myModalImagesGallery').modal('show');
				}else{					
					var i = 1;  
					content+=' <tr><th>Sl No</th><th>Image</th><th>Delete</th></tr>';
					$.each( result.cms, function( key, value ) {
						if (value.image_type	== 1){
							var image_link = '<img src="'+value.image+'"  width="50" height="50">';
						}else{
							var image_link = '<video width="50" height="50" controls><source src="'+value.image+'" type="video/mp4"></video>';
						}
						delete_image_view = '<a class="cstm_view" id="delete_product_meta_image_gallery" href="javascript:void(0)" title="'+value.product_image_id+'" class="btn btn-info"><span class="glyphicon glyphicon-minus-sign"></span></a>';	
						if(value.default_image_flag == 1){
							default_image_flag_view = '<a class="cstm_view" id="default_image_flag" href="javascript:void(0)" title="'+value.product_image_id+'" class="btn btn-info"><span class="glyphicon glyphicon-check"></span></a>';	
						}else{
							default_image_flag_view = '<a class="cstm_view" id="default_image_flag" href="javascript:void(0)" title="'+value.product_image_id+'" class="btn btn-info"><span class="glyphicon glyphicon-unchecked"></span></a>';
						}
						content+= '<tr><td>'+i+'</td><td>'+image_link+'</td><td>'+delete_image_view+'</td></tr>';			  
						$("#modalContentImagesGallery").html(content);						
						$('#myModalImagesGallery').modal('show');
						i++;
					});		
				}				
			},error:function(){
				$('#myModalImagesGallery').modal('show');
			}
		});
		
	});
	
	$(document).on( "click",'#default_image_flag.cstm_view',function() {
		var product_image_id=$(this).prop('title');
		var product_meta_id = $("#product_meta_id_image").val();
		var content='<div class="box-body" style="height:300px;overflow-y:scroll;"><table id="product_meta_image_list" class="table table-bordered">';
		$.ajax({
			  type:'POST',
			  url :'<?php echo base_url('admin/product/product_meta_default_image');?>',
			   data:'product_meta_id='+product_meta_id+'&product_image_id='+product_image_id,
			  dataType:'json',
			  success:function(result){
				if(result.cms.length == ''){
					$("#modalContentImages").html('');
					$('#myModalImages').modal('show');
				}else{					
					var i = 1;  
					content+=' <tr><th>Sl No</th><th>Image</th><th>Default Image</th><th>Delete</th></tr>';
					$.each( result.cms, function( key, value ) {
						delete_image_view = '<a class="cstm_view" id="delete_product_meta_image" href="javascript:void(0)" title="'+value.product_image_id+'" class="btn btn-info"><span class="glyphicon glyphicon-minus-sign"></span></a>';	
						if(value.default_image_flag == 1){
							default_image_flag_view = '<a class="cstm_view" id="default_image_flag" href="javascript:void(0)" title="'+value.product_image_id+'" class="btn btn-info"><span class="glyphicon glyphicon-check"></span></a>';	
						}else{
							default_image_flag_view = '<a class="cstm_view" id="default_image_flag" href="javascript:void(0)" title="'+value.product_image_id+'" class="btn btn-info"><span class="glyphicon glyphicon-unchecked"></span></a>';
						}
						if (value.image_type == 1){
							var image_link = '<img src="'+value.image+'"  width="50" height="50">';
						}else{
							var image_link = '<video width="50" height="50" controls><source src="'+value.image+'" type="video/mp4"></video>';
						}
						content+= '<tr><td>'+i+'</td><td>'+image_link+'</td><td>'+default_image_flag_view+'</td><td>'+delete_image_view+'</td></tr>';			  
						$("#modalContentImages").html(content);						
						$('#myModalImages').modal('show');
						i++;
					});		
				}				
			},error:function(){
				$('#myModalImages').modal('show');
			}
		});
		
	});
	
	$(document).on( "click",'#delete_product_meta_image.cstm_view',function() {
		var id=$(this).prop('title');	
		var product_meta_id = $("#product_meta_id_image").val();	
		var content='<div class="box-body" style="height:300px;overflow-y:scroll;"><table id="product_meta_image_list" class="table table-bordered">';
		$.ajax({
		  type: "POST",
		  url: '<?php echo base_url('admin/product/remove_product_meta_image')?>',
		  data: 'product_image_id='+id+'&product_meta_id='+product_meta_id,
		  dataType:'json',
		  success: function(response){
			var i = 1;  
			content+=' <tr><th>Sl No</th><th>Image</th><th>Default Image</th><th>Delete</th></tr>';
			$.each( response.cms, function( key, value ) {
				delete_image_view = '<a class="cstm_view" id="delete_product_meta_image" href="javascript:void(0)" title="'+value.product_image_id+'" class="btn btn-info"><span class="glyphicon glyphicon-minus-sign"></span></a>'	
				if(value.default_image_flag == 1){
					default_image_flag_view = '<a class="cstm_view" id="default_image_flag" href="javascript:void(0)" title="'+value.product_image_id+'" class="btn btn-info"><span class="glyphicon glyphicon-check"></span></a>';	
				}else{
					default_image_flag_view = '<a class="cstm_view" id="default_image_flag" href="javascript:void(0)" title="'+value.product_image_id+'" class="btn btn-info"><span class="glyphicon glyphicon-unchecked"></span></a>';
				}
				if (value.image_type == 1){
					var image_link = '<img src="'+value.image+'"  width="50" height="50">';
				}else{
					var image_link = '<video width="50" height="50" controls><source src="'+value.image+'" type="video/mp4"></video>';
				}
				
				content+= '<tr><td>'+i+'</td><td>'+image_link+'</td><td>'+default_image_flag_view+'</td><td>'+delete_image_view+'</td></tr>';			  
				
				$("#modalContentImages").html(content);						
				$('#myModalImages').modal('show');
				i++;
			});	
		  }
		});
	});	
	
	$(document).on( "click",'#delete_product_meta_image_gallery.cstm_view',function() {
		var id=$(this).prop('title');	
		var product_meta_id = $("#product_meta_id_image").val();	
		var content='<div class="box-body" style="height:300px;overflow-y:scroll;"><table id="product_meta_image_list" class="table table-bordered">';
		$.ajax({
		  type: "POST",
		  url: '<?php echo base_url('admin/product/remove_product_meta_image_gallery')?>',
		  data: 'product_image_id='+id+'&product_meta_id='+product_meta_id,
		  dataType:'json',
		  success: function(response){
			var i = 1;  
			content+=' <tr><th>Sl No</th><th>Image</th><th>Delete</th></tr>';
			$.each( response.cms, function( key, value ) {
				delete_image_view = '<a class="cstm_view" id="delete_product_meta_image_gallery" href="javascript:void(0)" title="'+value.product_image_id+'" class="btn btn-info"><span class="glyphicon glyphicon-minus-sign"></span></a>'	
				if(value.default_image_flag == 1){
					default_image_flag_view = '<a class="cstm_view" id="default_image_flag" href="javascript:void(0)" title="'+value.product_image_id+'" class="btn btn-info"><span class="glyphicon glyphicon-check"></span></a>';	
				}else{
					default_image_flag_view = '<a class="cstm_view" id="default_image_flag" href="javascript:void(0)" title="'+value.product_image_id+'" class="btn btn-info"><span class="glyphicon glyphicon-unchecked"></span></a>';
				}
				if (value.image_type == 1){
					var image_link = '<img src="'+value.image+'"  width="50" height="50">';
				}else{
					var image_link = '<video width="50" height="50" controls><source src="'+value.image+'" type="video/mp4"></video>';
				}
				
				content+= '<tr><td>'+i+'</td><td>'+image_link+'</td><td>'+delete_image_view+'</td></tr>';			  
				
				$("#modalContentImagesGallery").html(content);						
				$('#myModalImagesGallery').modal('show');
				i++;
			});	
		  }
		});
	});	
	
	var i = 0;
	/*$('#add_more_meta_key_value').click(function(){		
		$( "#meta_key_value" ).append('<div class="form-group"><label for="meta_key_id">Category<sup class="superr">*</sup></label><select class="form-control" id="meta_key_id'+i+'" name="meta_key_id" ><option value="">Select</option><?php foreach($meta_key_list as $meta_key){?><?php if($meta_key["meta_key_id"] == 3 || $meta_key["meta_key_id"] == 4 || $meta_key["meta_key_id"] == 5 || $meta_key["meta_key_id"] == 9){?><option value="<?php echo $meta_key["meta_key_id"]?>"><?php echo $meta_key["meta_key"]?></option><?php } }?></select></div><div class="form-group"><label for="meta_key_id">Category Values<sup class="superr">*</sup></label><select class="form-control" name="meta_key_value_id" id="meta_key_value_id'+i+'"></select></div>');
		$("#counter").val(i);
		
		$( "#meta_key_id"+i ).change(function() {
			var content ='<option value="">Select</option>';
			var meta_key_id = $(this).val();
			$.ajax({
				type:'POST',
				url :'<?php echo base_url('admin/product/meta_key_valuelist');?>',
				data:'meta_key_id='+meta_key_id,
				dataType:'json',
				success:function(result){
					$.each( result.responseList, function( key, value ) {
						content+='<option value="'+value.meta_key_value_id+'">'+value.meta_key_value+'</option>';
						var counter = $("#counter").val();
						$("#meta_key_value_id"+counter).html(content);
					});					
				},error:function(){

				}
			});
		});
	
		i++;
	});*/
	
	$('#save_product_meta').click(function(){		
		//var counter = $("#counter").val();
		//alert($("#meta_key_value_id").val());
		//alert($("#meta_key_value_id_1").val());
		//alert($("#meta_key_value_id_2").val());
		
		if($("#meta_key_value_id_1").val() != null && $("#meta_key_value_id_2").val() != null )
		{		
			//alert('hiii2');
			var counter = 2;	
		}else{
			if($("#meta_key_value_id_1").val() != null && $("#meta_key_value_id_2").val() == null){
				//alert('hiii1');
				var counter = 1;
			}else if($("#meta_key_value_id_2").val() != null && $("#meta_key_value_id_1").val() == null){
				//alert('hiii11');
				var counter = 2;
			}else{
				//alert('hiiib');
				var counter = "";
			}
		}
		//alert(counter);
		
		var met_key_text = "";		
			
		if ($("#meta_key_value_id").val() == null  && $("#meta_key_value_id_1").val() == null && $("#meta_key_value_id_2").val() == null)
		{
			var met_key_text = "";
		}else{
			if(counter != '')
			{	
				if ($("#meta_key_value_id").val() != null)
				{
					met_key_text+= $("#meta_key_value_id").val()+",";	
				}				
			}else{	
				if ($("#meta_key_value_id").val() != null)
				{
					met_key_text+=$("#meta_key_value_id").val();
				}					
			}			
			
			
			for(var i = 0;i<=counter;i++)
			{				
				$("#meta_key_value_id_"+i+" option:selected").each(function()
				{
					var meta_key_value_id = $(this).val();
					//alert(meta_key_value_id);
					
					var last_val = $("#meta_key_value_id_"+counter).val()
					
					if (meta_key_value_id == last_val)
					{
						met_key_text+=  meta_key_value_id;
					}else{
						met_key_text+=meta_key_value_id+",";
					}
				});
			}
		}
		
		//alert(met_key_text)
		/*if(counter != '')
		{
			met_key_text+= $("#meta_key_value_id").val()+",";
		}else{
			met_key_text+=$("#meta_key_value_id").val();
		}
		for(var i = 0;i<=counter;i++)
		{
			$("#meta_key_value_id"+i+" option:selected").each(function()
			{
				var meta_key_value_id = $(this).val();
				
				var last_val = $("#meta_key_value_id"+counter).val()
				
				if (meta_key_value_id == last_val)
				{
					met_key_text+=  meta_key_value_id;
				}else{
					met_key_text+=meta_key_value_id+",";
				}
			});
		}*/
		
		var product_id = $('#product_id').val();
		var in_price = $('#in_price').val();
		var out_price = $('#out_price').val();
		var product_meta_code = $('#product_meta_code').val();
		
		if (in_price == '' || out_price == '' || product_meta_code == '' || met_key_text == '')
		{
			$('#msg_product_variation').html('all fields requierd');
		}else{
			$.ajax({
				type:'POST',
				url :'<?php echo base_url('admin/product/save_product_meta');?>',
				data:'product_id='+product_id+'&meta_key_text='+met_key_text+'&in_price='+in_price+'&out_price='+out_price+'&product_meta_code='+product_meta_code,
				dataType:'json',
				success:function(result){
					alert(result.attributes.status);
					var response = result.attributes.status;
					$('#msg').html(response);
					setTimeout(function(){
						$('#myModal_add_product').modal('hide');
					},400);
					window.location.reload('<?php echo base_url('admin/product'); ?>');	
				},error:function(){

				}
			});
		}	
		
	});
	
	$('#save_product_meta_discount').click(function(){
		var ids = [];
		$('#product_list input[type=checkbox]:checked').each(function () {			   
				ids.push($(this).val());			
			});
		var discount_id = $('#discount_id').val();
		if( discount_id == '' &&  ids == ''){
			$('#msg_modal2').html('Please Select Discount Option and atleast one Product');			
		}else{
			if(discount_id == '' && ids != '')
			{
				$('#msg_modal2').html('Please Select Discount Option');
			}else if(discount_id != '' && ids == ''){
				$('#msg_modal2').html('Please Select atleast one Product');
			}else{
				$.ajax({
					type:'POST',
					url :'<?php echo base_url('admin/product/save_product_meta_discount');?>',
					data:'product_meta_id='+ids+'&discount_id='+discount_id,
					dataType:'json',
					success:function(result){												
						var product_id=$('#product_id_list').val();
						var content='<div class="box-body" style="height:300px;overflow-y:scroll;"><table id="product_list" class="table table-bordered">';
						$.ajax({
						  type:'POST',
						  url :'<?php echo base_url('admin/product/meta_list');?>',
						  data:'product_id='+product_id,
						  dataType:'json',
						  success:function(result){
								var i=1;
								content+=' <tr><th>Sl No</th><th>Product Name</th><th>Product Meta Code</th><th>In Price</th><th>Out Price</th><th>Loyalty Points</th><th>Stock</th><th>Add Images</th><th>Edit</th><th>Delete</th><th>Best Selling</th><th>Top Selling</th><th>Latest Product</th></tr>';
								$.each( result.responseList, function( key, value ) {				
									if(value.latest_product == 1)
									{
										latest_product = '<a class="cstm_view_latest_product" id="active" href="javascript:void(0)" title="'+value.product_meta_id+'"><span class="glyphicon glyphicon-ok"></span></a>';
									}else{
										latest_product = '<a class="cstm_view_latest_product" id="inactive" href="javascript:void(0)" title="'+value.product_meta_id+'"><span class="glyphicon glyphicon-remove"></span></a>';
									}
									if(value.top_selling_product == 1)
									{
										top_selling_product = '<a class="cstm_view_top_selling" id="active" href="javascript:void(0)" title="'+value.product_meta_id+'"><span class="glyphicon glyphicon-ok"></span></a>';
									}else{
										top_selling_product = '<a class="cstm_view_top_selling" id="inactive" href="javascript:void(0)" title="'+value.product_meta_id+'"><span class="glyphicon glyphicon-remove"></span></a>';
									}
									
									if(value.best_selling_product == 1)
									{
										best_selling_product = '<a class="cstm_view_best_selling" id="active" href="javascript:void(0)" title="'+value.product_meta_id+'"><span class="glyphicon glyphicon-ok"></span></a>';
									}else{
										best_selling_product = '<a class="cstm_view_best_selling" id="inactive" href="javascript:void(0)" title="'+value.product_meta_id+'"><span class="glyphicon glyphicon-remove"></span></a>';
									}
									
									var add_image = '<a class="cstm_view" id="add_images" href="javascript:void(0)" title="'+value.product_meta_id+'"><span class="glyphicon glyphicon-plus-sign"></span></a>';
									
									delete_view = '<a class="cstm_view" id="delete_product_meta" href="javascript:void(0)" title="'+value.product_meta_id+'" class="btn btn-info"><span class="glyphicon glyphicon-minus-sign"></span></a>';
									edit_view = '<a class="cstm_view" id="edit_product_meta_view" href="javascript:void(0)" title="'+value.product_meta_id+'" class="btn btn-info"><span class="glyphicon glyphicon-pencil"></span></a>';
									
									stock_view = '<a class="cstm_view" id="stock_view" href="javascript:void(0)" title="'+value.product_meta_id+'" class="btn btn-info"><span class="glyphicon glyphicon-plus"></span></a>';
									
									content+=' <tr><td>'+i+'</td><td>'+value.product_name+'(';
									
									$.each( value.met_key_value, function( key, mvalue ) {					
										content+= mvalue+" ";					
									});
									//content+= value.met_key_value.Storage+','+value.met_key_value.Color+','+value.met_key_value.Ram
									content+= ')</td><td>'+value.product_meta_code+'</td><td>'+value.in_price+'</td><td>'+value.out_price+'</td><td>'+value.loyalty_points+'</td><td>'+stock_view+'</td><td>'+add_image+'</td><td>'+edit_view+'</td><td>'+delete_view+'</td><td>'+best_selling_product+'</td><td>'+top_selling_product+'</td><td>'+latest_product+'</td></tr>';
									
									 i++;
									 content+='</hr>';
								});
								
								content+='</table></div>';
								$('#product_id_list').val(product_id);
								$('#modalContent2').html(content);  
								$('#myModal2').modal('show');
							 },error:function(){

							  }
							});
							
					},error:function(){

					}
				});
			}
		}
	});
	
	$('#id_select2_example_new_arrival').change(function(){
		new_arrival_id = $(this).val();
		var product_ids = [];
		$('#example input[type=checkbox]:checked').each(function () {			   
			product_ids.push($(this).val());			
		});
		
		if( new_arrival_id == '' &&  product_ids == ''){
			$('#msg_modal2').html('Please Select Discount Option and atleast one Product');			
		}else{
			if(new_arrival_id == '' && product_ids != '')
			{
				alert('Please Select Offer Option');
			}else if(new_arrival_id != '' && product_ids == ''){
				alert('Please Select atleast one Product');
			}else{
				$.ajax({
					type:'POST',
					url :'<?php echo base_url('admin/product/save_product_new_arrival');?>',
					data:'product_id='+product_ids+'&new_arrival_id='+new_arrival_id,
					dataType:'json',
					success:function(result){						
						window.location.reload('<?php echo base_url('admin/product'); ?>');	
					},error:function(){

					}
				});
			}
		}
		
	});
	
	$('#brand').change(function(){
		brand_id = $(this).val();
		var product_ids = [];
		$('#example input[type=checkbox]:checked').each(function () {			   
			product_ids.push($(this).val());			
		});
		
		if( brand_id == '' &&  product_ids == ''){
			$('#msg_modal2').html('Please Select Brand Option and atleast one Product');			
		}else{
			if(brand_id == '' && product_ids != '')
			{
				alert('Please Select Brand Option');
			}else if(brand_id != '' && product_ids == ''){
				alert('Please Select atleast one Product');
			}else{
				$.ajax({
					type:'POST',
					url :'<?php echo base_url('admin/product/save_product_brand');?>',
					data:'product_id='+product_ids+'&brand_id='+brand_id,
					dataType:'json',
					success:function(result){						
						window.location.reload('<?php echo base_url('admin/product'); ?>');	
					},error:function(){

					}
				});
			}
		}
		
	});
	
	$('#category').change(function(){
		category_id = $(this).val();
		var product_ids = [];
		$('#example input[type=checkbox]:checked').each(function () {			   
			product_ids.push($(this).val());			
		});
		
		if( category_id == '' &&  product_ids == ''){
			$('#msg_modal2').html('Please Select Brand Option and atleast one Product');			
		}else{
			if(category_id == '' && product_ids != '')
			{
				alert('Please Select Brand Option');
			}else if(category_id != '' && product_ids == ''){
				alert('Please Select atleast one Product');
			}else{
				$.ajax({
					type:'POST',
					url :'<?php echo base_url('admin/product/save_product_category');?>',
					data:'product_id='+product_ids+'&category_id='+category_id,
					dataType:'json',
					success:function(result){						
						window.location.reload('<?php echo base_url('admin/product'); ?>');	
					},error:function(){

					}
				});
			}
		}
		
	});
	
	
	$('#id_select2_example').change(function(){
		offer_id = $(this).val();
		var product_ids = [];
		$('#example input[type=checkbox]:checked').each(function () {			   
			product_ids.push($(this).val());			
		});
		
		if( offer_id == '' &&  product_ids == ''){
			$('#msg_modal2').html('Please Select Discount Option and atleast one Product');			
		}else{
			if(offer_id == '' && product_ids != '')
			{
				alert('Please Select Offer Option');
			}else if(offer_id != '' && product_ids == ''){
				alert('Please Select atleast one Product');
			}else{
				$.ajax({
					type:'POST',
					url :'<?php echo base_url('admin/product/save_product_offer');?>',
					data:'product_id='+product_ids+'&offer_id='+offer_id,
					dataType:'json',
					success:function(result){						
						window.location.reload('<?php echo base_url('admin/product'); ?>');	
					},error:function(){

					}
				});
			}
		}
		
	});
	
	$(document).on( "click",'#active.cstm_view_top_selling',function() {
		var p = $(this);
		p.html('---');		
		var id=$(this).prop('title');
		$.ajax({
		  type: "POST",
		  url: '<?php echo base_url('admin/product/remove_top_selling_product')?>',
		  data: 'product_meta_id='+id,
		  dataType:'json',
		  success: function(response){
			p.attr("id", "inactive");
			p.html('<span class="glyphicon glyphicon-remove"></span>');	
			//window.location.reload('<?php echo base_url('admin/feedback'); ?>');	
		  }
		});
	});
	
	$(document).on( "click",'#inactive.cstm_view_top_selling',function() {
		var pactive = $(this);
		pactive.html('---');		
		var id=$(this).prop('title');
		$.ajax({
		  type: "POST",
		  url: '<?php echo base_url('admin/product/add_top_selling_product')?>',
		  data: 'product_meta_id='+id,
		  dataType:'json',
		  success: function(response){
			pactive.attr("id","active");
			pactive.html('<span class="glyphicon glyphicon-ok"></span>');						
			//window.location.reload('<?php echo base_url('admin/feedback'); ?>');		
		  }
		});
	});
	
	$(document).on( "click",'#active.cstm_view_best_selling',function() {
		var p = $(this);
		p.html('---');		
		var id=$(this).prop('title');
		$.ajax({
		  type: "POST",
		  url: '<?php echo base_url('admin/product/remove_best_selling_product')?>',
		  data: 'product_meta_id='+id,
		  dataType:'json',
		  success: function(response){
			p.attr("id", "inactive");
			p.html('<span class="glyphicon glyphicon-remove"></span>');	
			//window.location.reload('<?php echo base_url('admin/feedback'); ?>');	
		  }
		});
	});
	
	$(document).on( "click",'#active.cstm_view_latest_product',function() {
		var p = $(this);
		p.html('---');		
		var id=$(this).prop('title');
		$.ajax({
		  type: "POST",
		  url: '<?php echo base_url('admin/product/remove_latest_product')?>',
		  data: 'product_meta_id='+id,
		  dataType:'json',
		  success: function(response){
			p.attr("id", "inactive");
			p.html('<span class="glyphicon glyphicon-remove"></span>');	
			//window.location.reload('<?php echo base_url('admin/feedback'); ?>');	
		  }
		});
	});
	
	$(document).on( "click",'#inactive.cstm_view_latest_product',function() {
		var pactive = $(this);
		pactive.html('---');		
		var id=$(this).prop('title');
		$.ajax({
		  type: "POST",
		  url: '<?php echo base_url('admin/product/add_latest_product')?>',
		  data: 'product_meta_id='+id,
		  dataType:'json',
		  success: function(response){
			pactive.attr("id","active");
			pactive.html('<span class="glyphicon glyphicon-ok"></span>');						
			//window.location.reload('<?php echo base_url('admin/feedback'); ?>');		
		  }
		});
	});
	
	$(document).on( "click",'#inactive.cstm_view_best_selling',function() {
		var pactive = $(this);
		pactive.html('---');		
		var id=$(this).prop('title');
		$.ajax({
		  type: "POST",
		  url: '<?php echo base_url('admin/product/add_best_selling_product')?>',
		  data: 'product_meta_id='+id,
		  dataType:'json',
		  success: function(response){
			pactive.attr("id","active");
			pactive.html('<span class="glyphicon glyphicon-ok"></span>');						
			//window.location.reload('<?php echo base_url('admin/feedback'); ?>');		
		  }
		});
	});
	
	$(document).on( "click",'#delete_product_meta.cstm_view',function() {
		var id=$(this).prop('title');		
		$.ajax({
		  type: "POST",
		  url: '<?php echo base_url('admin/product/remove_product_meta')?>',
		  data: 'product_meta_id='+id,
		  dataType:'json',
		  success: function(response){
				var product_id_list = $('#product_id_list').val();
				var content='<div class="box-body" style="height:300px;overflow-y:scroll;"><table id="product_list" class="table table-bordered">';
				$.ajax({
					 type:'POST',
					 url :'<?php echo base_url('admin/product/meta_list');?>',
					 data:'product_id='+product_id_list,
					 dataType:'json',
					 success:function(result){
							var i=1;
							content+=' <tr><th>Sl No</th><th>Product Name</th><th>Product Meta Code</th><th>In Price</th><th>Out Price</th><th>Loyalty Points</th><th>Stock</th><th>Add Images</th><th>Add Gallery</th><th>Edit</th><th>Delete</th><th>Best Selling</th><th>Top Selling</th><th>Latest Product</th></tr>';
							$.each( result.responseList, function( key, value ) {				
								if(value.latest_product == 1)
								{
									latest_product = '<a class="cstm_view_latest_product" id="active" href="javascript:void(0)" title="'+value.product_meta_id+'"><span class="glyphicon glyphicon-ok"></span></a>';
								}else{
									latest_product = '<a class="cstm_view_latest_product" id="inactive" href="javascript:void(0)" title="'+value.product_meta_id+'"><span class="glyphicon glyphicon-remove"></span></a>';
								}
								if(value.top_selling_product == 1)
								{
									top_selling_product = '<a class="cstm_view_top_selling" id="active" href="javascript:void(0)" title="'+value.product_meta_id+'"><span class="glyphicon glyphicon-ok"></span></a>';
								}else{
									top_selling_product = '<a class="cstm_view_top_selling" id="inactive" href="javascript:void(0)" title="'+value.product_meta_id+'"><span class="glyphicon glyphicon-remove"></span></a>';
								}
								
								if(value.best_selling_product == 1)
								{
									best_selling_product = '<a class="cstm_view_best_selling" id="active" href="javascript:void(0)" title="'+value.product_meta_id+'"><span class="glyphicon glyphicon-ok"></span></a>';
								}else{
									best_selling_product = '<a class="cstm_view_best_selling" id="inactive" href="javascript:void(0)" title="'+value.product_meta_id+'"><span class="glyphicon glyphicon-remove"></span></a>';
								}
								
								var add_image = '<a class="cstm_view" id="add_images" href="javascript:void(0)" title="'+value.product_meta_id+'"><span class="glyphicon glyphicon-plus-sign"></span></a>';
								
								var add_image_gallery = '<a class="cstm_view" id="add_image_gallery" href="javascript:void(0)" title="'+value.product_meta_id+'"><span class="glyphicon glyphicon-plus-sign"></span></a>';
								
								delete_view = '<a class="cstm_view" id="delete_product_meta" href="javascript:void(0)" title="'+value.product_meta_id+'" class="btn btn-info"><span class="glyphicon glyphicon-minus-sign"></span></a>';
								edit_view = '<a class="cstm_view" id="edit_product_meta_view" href="javascript:void(0)" title="'+value.product_meta_id+'" class="btn btn-info"><span class="glyphicon glyphicon-pencil"></span></a>';
								
								stock_view = '<a class="cstm_view" id="stock_view" href="javascript:void(0)" title="'+value.product_meta_id+'" class="btn btn-info"><span class="glyphicon glyphicon-plus"></span></a>';
								
								content+=' <tr><td>'+i+'</td><td>'+value.product_name+'(';
								
								$.each( value.met_key_value, function( key, mvalue ) {					
									content+= mvalue+" ";					
								});
								//content+= value.met_key_value.Storage+','+value.met_key_value.Color+','+value.met_key_value.Ram
								content+= ')</td><td>'+value.product_meta_code+'</td><td>'+value.in_price+'</td><td>'+value.out_price+'</td><td>'+value.loyalty_points+'</td><td>'+stock_view+'</td><td>'+add_image+'</td><td>'+add_image_gallery+'</td><td>'+edit_view+'</td><td>'+delete_view+'</td><td>'+best_selling_product+'</td><td>'+top_selling_product+'</td><td>'+latest_product+'</td></tr>';
								
								 i++;
								 content+='</hr>';
							});
							
							content+='</table></div>';
							$('#product_id_list').val(id);
							$('#modalContent2').html(content);  
							$('#myModal2').modal('show');
					},error:function(){

					}
				});
			}
		});
	});
	
	$(document).on( "click",'#edit_product_meta_view.cstm_view',function() {
		var id=$(this).prop('title');	
		$.ajax({
		  type: "POST",
		  url: '<?php echo base_url('admin/product/meta_details')?>',
		  data: 'product_meta_id='+id,
		  dataType:'json',
		  success: function(response){
			$('#edit_in_price').val(response.responseList.in_price); 
			$('#edit_out_price').val(response.responseList.out_price);
			$('#edit_product_meta_code').val(response.responseList.product_meta_code);
			$('#edit_stock').val(response.responseList.stock);
			$('#edit_loyality_point').val(response.responseList.loyalty_points);
			$('#edit_Rea_Camera_Lens_1').val(response.responseList.other_specification_json.Rear_Camera_Lens_1);
			$('#edit_Rea_Camera_Lens_2').val(response.responseList.other_specification_json.Rear_Camera_Lens_2);
			$('#edit_Screen_Size').val(response.responseList.other_specification_json.Screen_Size);
			$('#edit_Screen_Type').val(response.responseList.other_specification_json.Screen_Type);
			$('#edit_Battery_Power').val(response.responseList.other_specification_json.Battery_Power);
			$('#edit_Inbuilt_Storage').val(response.responseList.other_specification_json.Inbuilt_Storage);
			$('#edit_RAM').val(response.responseList.other_specification_json.RAM);
			$('#edit_Expandable_Storage').val(response.responseList.other_specification_json.Expandable_Storage);
			$('#edit_Processor_Brand').val(response.responseList.other_specification_json.Processor_Brand);
			$('#edit_Operating_System').val(response.responseList.other_specification_json.Operating_System);
			$('#product_meta_id').val(id);
			$('#product_id_edit_product_meta').val(response.responseList.product_id);
			var content = response.responseList.product_name+" (";
			$.each( response.responseList.met_key_value, function( key, mvalue ) {					
				content+= mvalue+" ";					
			});
			content+= ")";
			$('#product_meta_details').html(content);
			$('#myModal_edit_product').modal('show');
		  }
		});
	});
	
	$(document).on( "click",'#stock_view.cstm_view',function() {
		var id=$(this).prop('title');
		$('#stock_product_meta_id').val(id);
		var content='<div class="box-body" style="height:300px;overflow-y:scroll;"><table id="product_list" class="table table-bordered">';
		$.ajax({
		  type: "POST",
		  url: '<?php echo base_url('admin/product/get_retailerlist_with_stock')?>',
		  data: 'product_meta_id='+id,
		  dataType:'json',
		  success: function(response){
			var i = 1;			  
			content+=' <tr><th>Sl No.</th><th>Retailer Name</th><th>City</th><th>Stock</th><th>Update Stock</th></tr>';
			$.each( response.responseList, function( key, value ) {
				if( value.stock == 1)
				{
					var stock_value = "In Stock";
				}else{
					var stock_value = "Out Of Stock";
				}
				update_stock = '<a class="cstm_view" id="edit_retailer_stock" href="javascript:void(0)" title="'+value.stock+'" retailer="'+value.retailer_store_id+'" class="btn btn-info"><span class="glyphicon glyphicon-pencil"></span></a>';
				content+= '<tr><td>'+i+'</td><td>'+value.retailer_name+'</td><td>'+value.city+'</td><td>'+stock_value+'</td><td>'+update_stock+'</td></tr>';
				i++;
			});
			$('#modalContent_stock').html(content);			
			$('#myModal_stock').modal('show');
		  }
		});
	});
	
	$(document).on( "click",'#edit_retailer_stock.cstm_view',function() {
		var id=$(this).prop('title');
		var retailer_id = $(this).attr('retailer');
		$('#edit_product_meta_stock').val(id);
		$('#retailer_store_id').val(retailer_id);
		$('#myModal_edit_stock').modal('show');
	});
	
	$('#retailer_stock_update').click(function(){
		var product_meta_id = $('#stock_product_meta_id').val();
		var retailer_store_id = $('#retailer_store_id').val();
		var content='<div class="box-body" style="height:300px;overflow-y:scroll;"><table id="product_list" class="table table-bordered">';
		var stock = $('#edit_product_meta_stock').val();		
		$.ajax({
		  type: "POST",
		  url: '<?php echo base_url('admin/product/update_stock')?>',
		  data: 'product_meta_id='+product_meta_id+'&retailer_store_id='+retailer_store_id+'&stock='+stock,
		  dataType:'json',
		  success: function(response){
			$('#myModal_edit_stock').modal('hide');  
			$.ajax({
			  type: "POST",
			  url: '<?php echo base_url('admin/product/get_retailerlist_with_stock')?>',
			  data: 'product_meta_id='+product_meta_id,
			  dataType:'json',
			  success: function(response){
				var i = 1;			  
				content+=' <tr><th>Sl No.</th><th>Retailer Name</th><th>City</th><th>Stock</th><th>Update Stock</th></tr>';
				$.each( response.responseList, function( key, value ) {
					if( value.stock == 1)
					{
						var stock_value = "In Stock";
					}else{
						var stock_value = "Out Of Stock";
					}				
					update_stock = '<a class="cstm_view" id="edit_retailer_stock" href="javascript:void(0)" title="'+value.stock+'" retailer="'+value.retailer_store_id+'" class="btn btn-info"><span class="glyphicon glyphicon-pencil"></span></a>';
					content+= '<tr><td>'+i+'</td><td>'+value.retailer_name+'</td><td>'+value.city+'</td><td>'+stock_value+'</td><td>'+update_stock+'</td></tr>';
					i++;
				});
				$('#modalContent_stock').html(content);			
				$('#myModal_stock').modal('show');
			  }
			});
		  }
		});
		
	});
	
	$('#submit').click(function(){
		var content='<div class="box-body" style="height:300px;overflow-y:scroll;"><table id="product_meta_image_list" class="table table-bordered">';
		var product_meta_id_image = $('#product_meta_id_image').val();	
		var form_data = new FormData();
		   // Read selected files
		   var totalfiles = document.getElementById('files').files.length;
		   for (var index = 0; index < totalfiles; index++) {
			  form_data.append("files[]", document.getElementById('files').files[index]);
		   }
		   form_data.append("product_meta_id",product_meta_id_image);
		  $.ajax({
			 url: '<?php echo base_url('admin/product/save_product_meta_image')?>', 
			 type: 'post',
			 data: form_data,
			 dataType: 'json',
			 contentType: false,
			 processData: false,
			 success: function (response) {
				var i = 1;  
				content+=' <tr><th>Sl No</th><th>Image</th><th>Default Image</th><th>Delete</th></tr>';
				$.each( response.cms, function( key, value ) {	
					delete_image_view = '<a class="cstm_view" id="delete_product_meta_image" href="javascript:void(0)" title="'+value.product_image_id+'" class="btn btn-info"><span class="glyphicon glyphicon-minus-sign"></span></a>';	
					if(value.default_image_flag == 1){
						default_image_flag_view = '<a class="cstm_view" id="default_image_flag" href="javascript:void(0)" title="'+value.product_image_id+'" class="btn btn-info"><span class="glyphicon glyphicon-check"></span></a>';	
					}else{
						default_image_flag_view = '<a class="cstm_view" id="default_image_flag" href="javascript:void(0)" title="'+value.product_image_id+'" class="btn btn-info"><span class="glyphicon glyphicon-unchecked"></span></a>';
					}
					
					if (value.image_type == 1){
						var image_link = '<img src="'+value.image+'"  width="50" height="50">';
					}else{
						var image_link = '<video width="50" height="50" controls><source src="'+value.image+'" type="video/mp4"></video>';
					}
					content+= '<tr><td>'+i+'</td><td>'+image_link+'</td><td>'+default_image_flag_view+'</td><td>'+delete_image_view+'</td></tr>';			  
					$("#modalContentImages").html(content);
					$("#product_meta_id_image").val(product_meta_id_image);
					$('#myModalImages').modal('show');
					i++;
				});	 
			 }
		   });
	});	
	
	$('#submitG').click(function(){
		var content='<div class="box-body" style="height:300px;overflow-y:scroll;"><table id="product_meta_image_list" class="table table-bordered">';
		var product_meta_id_image = $('#product_meta_id_image').val();	
		var form_data = new FormData();
		   // Read selected files
		   var totalfiles = document.getElementById('filesg').files.length;
		   for (var index = 0; index < totalfiles; index++) {
			  form_data.append("files[]", document.getElementById('filesg').files[index]);
		   }
		   form_data.append("product_meta_id",product_meta_id_image);
		  $.ajax({
			 url: '<?php echo base_url('admin/product/save_product_meta_image_gallery')?>', 
			 type: 'post',
			 data: form_data,
			 dataType: 'json',
			 contentType: false,
			 processData: false,
			 success: function (response) {
				var i = 1;  
				content+=' <tr><th>Sl No</th><th>Image</th><th>Delete</th></tr>';
				$.each( response.cms, function( key, value ) {	
					delete_image_view = '<a class="cstm_view" id="delete_product_meta_image_gallery" href="javascript:void(0)" title="'+value.product_image_id+'" class="btn btn-info"><span class="glyphicon glyphicon-minus-sign"></span></a>';	
					if(value.default_image_flag == 1){
						default_image_flag_view = '<a class="cstm_view" id="default_image_flag" href="javascript:void(0)" title="'+value.product_image_id+'" class="btn btn-info"><span class="glyphicon glyphicon-check"></span></a>';	
					}else{
						default_image_flag_view = '<a class="cstm_view" id="default_image_flag" href="javascript:void(0)" title="'+value.product_image_id+'" class="btn btn-info"><span class="glyphicon glyphicon-unchecked"></span></a>';
					}
					
					if (value.image_type == 1){
						var image_link = '<img src="'+value.image+'"  width="50" height="50">';
					}else{
						var image_link = '<video width="50" height="50" controls><source src="'+value.image+'" type="video/mp4"></video>';
					}
					content+= '<tr><td>'+i+'</td><td>'+image_link+'</td><td>'+delete_image_view+'</td></tr>';			  
					$("#modalContentImagesGallery").html(content);
					$("#product_meta_id_image").val(product_meta_id_image);
					$('#myModalImagesGallery').modal('show');
					i++;
				});	 
			 }
		   });
	});
	
	$('#edit_product_meta').click(function(){
		var in_price = $('#edit_in_price').val();
		var out_price = $('#edit_out_price').val();
		var product_meta_code = $('#edit_product_meta_code').val();
		var id = $('#product_meta_id').val();		
		var product_id_list = $('#product_id_list').val();
		var loyalty_points = $('#edit_loyality_point').val();
		var Rea_Camera_Lens_1 = $('#edit_Rea_Camera_Lens_1').val();
		var Rea_Camera_Lens_2 = $('#edit_Rea_Camera_Lens_2').val();
		var Screen_Size = $('#edit_Screen_Size').val();		
		var Screen_Type =  $('#edit_Screen_Type').val();
		var Battery_Power = $('#edit_Battery_Power').val();
		var Inbuilt_Storage = $('#edit_Inbuilt_Storage').val();
		var RAM = $('#edit_RAM').val();
		var Expandable_Storage = $('#edit_Expandable_Storage').val();
		var Processor_Brand = $('#edit_Processor_Brand').val();
		var Operating_System = $('#edit_Operating_System').val();
		$.ajax({
		  type: "POST",
		  url: '<?php echo base_url('admin/product/update_product_meta')?>',
		  data: 'product_meta_id='+id+'&in_price='+in_price+'&out_price='+out_price+'&product_meta_code='+product_meta_code+'&loyalty_points='+loyalty_points+'&Rea_Camera_Lens_1='+Rea_Camera_Lens_1+'&Rea_Camera_Lens_2='+Rea_Camera_Lens_2+'&Screen_Size='+Screen_Size+'&Screen_Type='+Screen_Type+'&Battery_Power='+Battery_Power+'&Inbuilt_Storage='+Inbuilt_Storage+'&RAM='+RAM+'&Expandable_Storage='+Expandable_Storage+'&Processor_Brand='+Processor_Brand+'&Operating_System='+Operating_System,
		  dataType:'json',
		  success: function(response){
			var product_id = $('#product_id_edit_product_meta').val();
			var content='<div class="box-body" style="height:300px;overflow-y:scroll;"><table id="product_list" class="table table-bordered">';
			$.ajax({
			  type:'POST',
			  url :'<?php echo base_url('admin/product/meta_list');?>',
			  data:'product_id='+product_id,
			  dataType:'json',
			  success:function(result){
					$('#myModal_edit_product').modal('hide');									 
					var i=1;
					content+=' <tr><th>Sl No</th><th>Product Name</th><th>Product Meta Code</th><th>In Price</th><th>Out Price</th><th>Loyalty Points<th>Stock</th><th>Add Images</th><th>Edit</th><th>Delete</th><th>Best Selling</th><th>Top Selling</th><th>Latest Product</th></tr>';
					$.each( result.responseList, function( key, value ) {				
						if(value.latest_product == 1)
						{
							latest_product = '<a class="cstm_view_latest_product" id="active" href="javascript:void(0)" title="'+value.product_meta_id+'"><span class="glyphicon glyphicon-ok"></span></a>';
						}else{
							latest_product = '<a class="cstm_view_latest_product" id="inactive" href="javascript:void(0)" title="'+value.product_meta_id+'"><span class="glyphicon glyphicon-remove"></span></a>';
						}
						if(value.top_selling_product == 1)
						{
							top_selling_product = '<a class="cstm_view_top_selling" id="active" href="javascript:void(0)" title="'+value.product_meta_id+'"><span class="glyphicon glyphicon-ok"></span></a>';
						}else{
							top_selling_product = '<a class="cstm_view_top_selling" id="inactive" href="javascript:void(0)" title="'+value.product_meta_id+'"><span class="glyphicon glyphicon-remove"></span></a>';
						}
						
						if(value.best_selling_product == 1)
						{
							best_selling_product = '<a class="cstm_view_best_selling" id="active" href="javascript:void(0)" title="'+value.product_meta_id+'"><span class="glyphicon glyphicon-ok"></span></a>';
						}else{
							best_selling_product = '<a class="cstm_view_best_selling" id="inactive" href="javascript:void(0)" title="'+value.product_meta_id+'"><span class="glyphicon glyphicon-remove"></span></a>';
						}
						
						var add_image = '<a class="cstm_view" id="add_images" href="javascript:void(0)" title="'+value.product_meta_id+'"><span class="glyphicon glyphicon-plus-sign"></span></a>';
						
						delete_view = '<a class="cstm_view" id="delete_product_meta" href="javascript:void(0)" title="'+value.product_meta_id+'" class="btn btn-info"><span class="glyphicon glyphicon-minus-sign"></span></a>';
						edit_view = '<a class="cstm_view" id="edit_product_meta_view" href="javascript:void(0)" title="'+value.product_meta_id+'" class="btn btn-info"><span class="glyphicon glyphicon-pencil"></span></a>';
						
						stock_view = '<a class="cstm_view" id="stock_view" href="javascript:void(0)" title="'+value.product_meta_id+'" class="btn btn-info"><span class="glyphicon glyphicon-plus"></span></a>';
						
						content+=' <tr><td>'+i+'</td><td>'+value.product_name+'(';
						
						$.each( value.met_key_value, function( key, mvalue ) {					
							content+= mvalue+" ";					
						});
						//content+= value.met_key_value.Storage+','+value.met_key_value.Color+','+value.met_key_value.Ram
						content+= ')</td><td>'+value.product_meta_code+'</td><td>'+value.in_price+'</td><td>'+value.out_price+'</td><td>'+value.loyalty_points+'</td><td>'+stock_view+'</td><td>'+add_image+'</td><td>'+edit_view+'</td><td>'+delete_view+'</td><td>'+best_selling_product+'</td><td>'+top_selling_product+'</td><td>'+latest_product+'</td></tr>';
						
						 i++;
						 content+='</hr>';
					});
					
					content+='</table></div>';
					$('#product_id_list').val(product_id_list);
					$('#modalContent2').html(content);  
					$('#myModal2').modal('show');
				 },error:function(){

				}
			});
		  }
		});
	});
	
	$(document).on( "click",'#active.cstm_view_status',function() {
		var p = $(this);
		p.html('---');
		var id=$(this).prop('title');
		$.ajax({
		  type: "POST",
		  url: '<?php echo base_url('admin/product/inactive')?>',
		  data: 'product_id='+id,
		  dataType:'json',
		  success: function(response){
			p.attr("id", "inactive");
			p.html('<span class="glyphicon glyphicon-remove"></span>');				
			//window.location.reload('<?php echo base_url('admin/feedback'); ?>');	
		  }
		});
	});
	
	$(document).on( "click",'#inactive.cstm_view_status',function() {
		var pactive = $(this);
		pactive.html('---');
		var id=$(this).prop('title');
		$.ajax({
		  type: "POST",
		  url: '<?php echo base_url('admin/product/active')?>',
		  data: 'product_id='+id,
		  dataType:'json',
		  success: function(response){
			pactive.attr("id","active");		
			pactive.html('<span class="glyphicon glyphicon-ok"></span>');		
			//window.location.reload('<?php echo base_url('admin/feedback'); ?>');		
		  }
		});
	});	
 </script> 