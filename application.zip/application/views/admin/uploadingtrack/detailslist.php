<style>
.cstm_view{font-size:15px;}
</style>
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
          <h3>
            Uploading Track Details List
            
          </h3>
          <!--<ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>-->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box box-primary">
            <div class="box-header with-border">
			<div class="admin_tab">
			<ul>
				<li><a href="javascript:void(0);" onclick="window.history.back();">Back</a></li>
			</ul>
			
				 
							
							<?php if($this->session->flashdata('error_msg')){?>
								<span style="color:red; font-weight:bold"><?php echo $this->session->flashdata('error_msg');?></span>
							<?php }?>
							<?php if($this->session->flashdata('success_msg')){?>
								<span style="color:green; font-weight:bold"><?php  echo $this->session->flashdata('success_msg'); ?></span>
							<?php }?>
				</div>			 
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example" class="table table-bordered table-striped">
                <thead>
                <tr>
				  <th class="no-sort">Sl. NO.</th>
				  <th class="no-sort">Uploading File Name</th>	
				  <th class="no-sort">Upload Into s3 Bucket</th>
				  <th class="no-sort">Create Texaract</th>		
				  <th class="no-sort">Create Text File</th>	
				  <th class="no-sort">Data Save Into Database</th>
				  <th class="no-sort">View</th>
				  <th class="no-sort">Process Again</th>
                </tr>
                </thead> 
				<tbody>
					<?php $i=1; foreach($post_data as $row){ ?>
					<tr>
						<td class="text-center">
                          <?php echo $i;?>
                        </td> 
						<td class="text-center">
                          <?php echo $row['uploadig_file_name'] ;?>
                        </td> 
						<td class="text-center">
                          <?php if ($row['uploading_into_s3_bucket'] == 1){?><p><font color="green"><b><?php echo "DONE";?></b></p><?php } else{ ?><p><font color="red"><b><?php echo "PROCESSING "; ?></b></p><?php } ?>
                        </td>
						<td class="text-center">
                           <?php if ($row['converting_json_from_upoading_file'] == 1){?><p><font color="green"><b><?php echo "DONE";?></b></p><?php } else{ ?><p><font color="red"><b><?php echo "PROCESSING "; ?></b></p><?php } ?>
                        </td>
						<td class="text-center">
                           <?php if ($row['create_text_file'] == 1){?><p><font color="green"><b><?php echo "DONE";?></b></p><?php } else{ ?><p><font color="red"><b><?php echo "PROCESSING "; ?></b></p><?php } ?>
                        </td>
						<td class="text-center">
                           <?php if ($row['uploading_data_into_database'] == 1){?><p><font color="green"><b><?php echo "DONE";?></b></p><?php } else{ ?><p><font color="red"><b><?php echo "PROCESSING "; ?></b></p><?php } ?>
                        </td>
						<td class="text-center">							
							<a href="<?php echo base_url('admin/dms/esic_details/'.$row['uploading_track_details_id']); ?>" ><span class="glyphicon glyphicon-eye-open"></span></a>
						</td>						
						<td class="text-center">
							<a class="cstm_view_repeat" id="repeat" style="padding-left:5px" href="javascript:void(0)" title="<?php echo  $row['request_no']; ?>" content_type = "<?php echo $content_type; ?>"><span class="glyphicon glyphicon-repeat"></span></a>										
						</td>
					</tr>
					<?php $i++;} ?>
				</tbody>
                <tfoot>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>

<script src="<?php echo base_url()?>public/admin_assets/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url()?>public/admin_assets/plugins/datatables/dataTables.bootstrap.min.js"></script>
<script>
/*$(document).ready(function() {
    $('#example').DataTable( {
        "processing": true,
        "serverSide": true,
        "ajax": {
            "url": "<?php echo base_url('admin/metakey/all_content_list');?>",
            "type": "POST"
        },
        //Set column definition initialisation properties.
        "columnDefs": [
        { 
            "targets": 'no-sort', //1st and last column
            "orderable": false, //set not orderable
        },
        ],
    } );
	
	var dtable = $("#example").dataTable().api();
	
	$(".dataTables_filter input")
    .unbind() // Unbind previous default bindings
    .bind("input", function(e) { // Bind our desired behavior
        // If the length is 3 or more characters, or the user pressed ENTER, search
        if(this.value.length >= 3 || e.keyCode == 13) {
            // Call the API search function
            dtable.search(this.value).draw();
        }
        // Ensure we clear the search if they backspace far enough
        if(this.value == "") {
            dtable.search("").draw();
        }
        return;
    });
} );*/

var  table = $('#example').dataTable({
    'bLengthChange': false,
    'searching': true,
    'paging':   true,  // Table pagination
    'ordering': false,  // Column ordering
    'info':     true,  // Bottom left status text
    'responsive': true, // https://datatables.net/extensions/responsive/examples/
    // Text translation options
    // Note the required keywords between underscores (e.g _MENU_)
    oLanguage: {
        // sSearch:      'Search all columns:',
        sLengthMenu:  '_MENU_ records per page',
        info:         'Showing page _PAGE_ of _PAGES_',
        zeroRecords:  'Nothing found - sorry',
        infoEmpty:    'No records available',
        infoFiltered: '(filtered from _MAX_ total records)'
    },
    // set columns options
    'aoColumns': [
    {'bVisible':true},
    {'bVisible':true},
    {'bVisible':true},
	{'bVisible':true},
	{'bVisible':true},
	{'bVisible':true},
	{'bVisible':true},
	{'bVisible':true}
    ]
  });
  
 $(document).on( "click",'.cstm_view_repeat',function() {
	var request_no = $(this).prop('title');
	var content_type = $(this).attr('content_type');
	$.ajax({
      type:'POST',
      url :'<?php echo base_url('admin/dms/repeat_process');?>',
      data:'request_no='+request_no+'&content_type='+content_type,
      dataType:'json',
      success:function(result){
		window.location.reload('<?php echo base_url('admin/dms/uploading_track_details_list'); ?>'+request_no);	
      },error:function(){

      }
    });
 });	 
</script>
