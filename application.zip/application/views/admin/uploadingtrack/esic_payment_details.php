 <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
 <script src="<?php echo base_url()?>/public/validation/js/jquery.validate.js"></script>
<!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h3>
            Esic Payment Data
            
          </h3>         
        </section>

        <!-- Main content -->
        <section class="content"> 
			<div class="row">
				<div class="col-md-6">										
					<div class="embed-responsive embed-responsive-4by3">
						<iframe class="embed-responsive-item" src="<?php echo base_url()."/public/images/".$uploadig_file_name; ?>" allowfullscreen></iframe>
					</div>
				</div>
				<!-- general form elements -->
				<div class="col-md-6">
					  <div class="box box-primary ex1">						 
						<div class="box-header with-border">						
						  <h3 class="box-title"></h3>
						  <?php if($this->session->flashdata('error_msg')){?>
								<span style="color:red; font-weight:bold"><?php echo $this->session->flashdata('error_msg');?></span>
							<?php }?>
							<?php if($this->session->flashdata('success_msg')){?>
								<span style="color:green; font-weight:bold"><?php  echo $this->session->flashdata('success_msg'); ?></span>
							<?php }?>
						</div>
						<!-- /.box-header -->
						<!-- form start -->
						<form id="signupForm" role="form" class="mtbresize" method="post" action="<?php echo base_url()."admin/dms/esic_payment_data_update"; ?>" enctype="multipart/form-data" autocomplete="off">
						  <div class="box-body">							
							<div class="form-group">
							  <label for="transaction_status">Transaction Status<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="transaction_status" name="transaction_status" value="<?php echo $cms['transaction_status'];?>" placeholder="Transaction Status" required="required">
							  <?php echo form_error('transaction_status','<span class="error">', '</span>'); ?>
							</div>	
							<div class="form-group">
							  <label for="employers_code_no">Employers Code No<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="employers_code_no" name="employers_code_no" value="<?php echo $cms['employers_code_no'];?>" placeholder="Employers Code No" required="required">
							  <?php echo form_error('employers_code_no','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="employers_name">Employers Name<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="employers_name" name="employers_name" value="<?php echo $cms['employers_name'];?>" placeholder="Employers Name" required="required">
							  <?php echo form_error('employers_name','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="challan_period">Challan Period<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="challan_period" name="challan_period" value="<?php echo $cms['challan_period'];?>" placeholder="Challan Period" required="required">
							  <?php echo form_error('challan_period','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="challan_number">Challan Number<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="challan_number" name="challan_number" value="<?php echo $cms['challan_number'];?>" placeholder="Challan Number" required="required">
							  <?php echo form_error('challan_number','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="challan_created_date">Challan Created Date<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="challan_created_date" name="challan_created_date" value="<?php echo $cms['challan_created_date'];?>" placeholder="Challan Created Date" required="required">
							  <?php echo form_error('challan_created_date','<span class="error">', '</span>'); ?>
							</div>							
							<div class="form-group">
							  <label for="challan_submited_date">Challan Submited Date<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="challan_submited_date" name="challan_submited_date" value="<?php echo $cms['challan_submited_date'];?>" placeholder="Challan Submited Date" required="required">
							  <?php echo form_error('challan_submited_date','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="amount_paid">Amount Paid<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="amount_paid" name="amount_paid" value="<?php echo $cms['amount_paid'];?>" placeholder="Amount Paid" required="required">
							  <?php echo form_error('amount_paid','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="transaction_number">Transaction Number<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="transaction_number" name="transaction_number" value="<?php echo $cms['transaction_number'];?>" placeholder="Transaction Number" required="required">
							  <?php echo form_error('transaction_number','<span class="error">', '</span>'); ?>
							</div>
						  </div>
						  <div class="box-footer">
							<input type="hidden" id="esic_payment_id" name="esic_payment_id" value="<?php echo $cms['esic_payment_id']; ?>">
							<input type="hidden" id="uploading_track_details_id" name="uploading_track_details_id" value="<?php echo $cms['uploading_track_details_id']; ?>">
							<button type="submit" class="btn btn-sm btn-primary">Submit</button>
						  </div>
						</form>						
						  <!-- /.box-body -->						  
					  </div>
				</div>
          <!-- /.box -->
          </div><!-- /.row -->	
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
	  
<div class="modal" id='myModal2'>
    <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span></button>
                <h4 class="modal-title">Esic Table Data</h4>
              </div>
              <div class="modal-body" id='modalContent2' title="">
				<div class="form-group">
					<label for="is_disable">Is Disable<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Is disable" id="is_disable" name="is_disable" >
				</div>
				<div class="form-group">
					<label for="ip_number">Ip Number<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Ip Number" id="ip_number" name="ip_number" >
				</div>
				<div class="form-group">
					<label for="ip_name">Ip Name<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Ip Name" id="ip_name" name="ip_name" >
				</div>
				<div class="form-group">
					<label for="no_of_days">No Of Days<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="No Of Days" id="no_of_days" name="no_of_days" >
				</div>
				<div class="form-group">
					<label for="total_wages">Total Wages<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Total Wages" id="total_wages" name="total_wages" >
				</div>
				<div class="form-group">
					<label for="ip_contribution">Ip Contribution<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="ip_contribution" id="ip_contribution" name="ip_contribution" >
				</div>
				<div class="form-group">
					<label for="reason">Reason<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="reason" id="reason" name="reason" >
				</div>
				<input type='hidden' class="form-control" id="esic_table_data_id">
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal" id="cdel2">save</button>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
		
<div class="modal" id='myModal3'>
    <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span></button>
                <h4 class="modal-title">Esic Table Data</h4>
              </div>
              <div class="modal-body" id='modalContent2' title="">
				<div class="form-group">
					<label for="is_disable">Is Disable<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Is disable" id="is_disable_add" name="is_disable_add" >
				</div>
				<div class="form-group">
					<label for="ip_number">Ip Number<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Ip Number" id="ip_number_add" name="ip_number_add" >
				</div>
				<div class="form-group">
					<label for="ip_name">Ip Name<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Ip Name" id="ip_name_add" name="ip_name_add" >
				</div>
				<div class="form-group">
					<label for="no_of_days">No Of Days<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="No Of Days" id="no_of_days_add" name="no_of_days_add" >
				</div>
				<div class="form-group">
					<label for="total_wages">Total Wages<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Total Wages" id="total_wages_add" name="total_wages_add" >
				</div>
				<div class="form-group">
					<label for="ip_contribution">Ip Contribution<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Ip Contribution" id="ip_contribution_add" name="ip_contribution_add" >
				</div>
				<div class="form-group">
					<label for="reason">Reason<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="reason" id="reason_add" name="reason_add" >
				</div>
				<input type='hidden' class="form-control" id="esic_basic_data_id">
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal" id="cdel2_add">save</button>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
		
<script src="https://cdn.ckeditor.com/4.5.7/standard/ckeditor.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-show-password/1.0.3/bootstrap-show-password.min.js"></script>
<script>
$( "#signupForm" ).validate( {
					rules: {
						product_name: "required",
						meta_key_id:"required",
						brand_id:"required"
						
						
					},
					messages: {						
						product_name: {required:"name field is required"},
						meta_key_id: {required:"Category field is required"},
						brand_id: {required:"Brand field is required"}
						
					},
					errorElement: "em",
					
					highlight: function ( element, errorClass, validClass ) {
						$( element ).parents( ".form-control" ).addClass( "has-error" ).removeClass( "has-success" );
					},
					unhighlight: function (element, errorClass, validClass) {
						$( element ).parents( ".form-control" ).addClass( "has-success" ).removeClass( "has-error" );
					}
				} );
				
$(document).on( "click",'.cstm_view',function() {
    var esic_table_data_id=$(this).prop('title');
    var content='<div class="box-body"><table class="table table-bordered">';
	 $.ajax({
      type:'POST',
      url :'<?php echo base_url('admin/dms/esic_table_details');?>',
      data:'esic_table_data_id='+esic_table_data_id,
      dataType:'json',
      success:function(result){
		$("#is_disable").val(result.responseList.is_disable);
		$("#ip_number").val(result.responseList.ip_number);
		$("#ip_name").val(result.responseList.ip_name);
		$("#no_of_days").val(result.responseList.no_of_days);
		$("#total_wages").val(result.responseList.total_wages);
		$("#ip_contribution").val(result.responseList.ip_contribution);
		$("#reason").val(result.responseList.reason);
		$("#esic_table_data_id").val(result.responseList.esic_table_data_id);
      },error:function(){

      }
    });
	$('#myModal2').modal('show');
  });
  
 $("#cdel2").click(function(){
	var  is_disable = $("#is_disable").val();
	var ip_number  = $("#ip_number").val();
	var ip_name = $("#ip_name").val();
	var no_of_days = $("#no_of_days").val();
	var total_wages = $("#total_wages").val();
	var ip_contribution = $("#ip_contribution").val();
	var reason = $("#reason").val();
	var esic_table_data_id = $("#esic_table_data_id").val();
	 $.ajax({
      type:'POST',
      url :'<?php echo base_url('admin/dms/update_esic_table_data');?>',
      data:'esic_table_data_id='+esic_table_data_id+'&is_disable='+is_disable+'&ip_number='+ip_number+'&ip_name='+ip_name+'&no_of_days='+no_of_days+'&total_wages='+total_wages+'&ip_contribution='+ip_contribution+'&reason='+reason,
      dataType:'json',
      success:function(result){
		window.location.reload('<?php echo base_url('admin/dms/esic_details'); ?>'+result.responseList.esic_basic_data_id);	
      },error:function(){

      }
    });
 });
 
 $(document).on( "click",'.cstm_view_esic_table',function() {
	var esic_basic_data_id=$(this).prop('title');
	$('#esic_basic_data_id').val(esic_basic_data_id);
	$('#myModal3').modal('show');
 });
 
  $("#cdel2_add").click(function(){
	var is_disable = $("#is_disable_add").val();
	var ip_number  = $("#ip_number_add").val();
	var ip_name = $("#ip_name_add").val();
	var no_of_days = $("#no_of_days_add").val();
	var total_wages = $("#total_wages_add").val();
	var ip_contribution = $("#ip_contribution_add").val();
	var esic_basic_data_id = $("#esic_basic_data_id").val();
	var reason = $("#reason_add").val();  
	$.ajax({
      type:'POST',
      url :'<?php echo base_url('admin/dms/add_esic_table_data');?>',
      data:'esic_basic_data_id='+esic_basic_data_id+'&is_disable='+is_disable+'&ip_number='+ip_number+'&ip_name='+ip_name+'&no_of_days='+no_of_days+'&total_wages='+total_wages+'&ip_contribution='+ip_contribution+'&reason='+reason,
      dataType:'json',
      success:function(result){
		window.location.reload('<?php echo base_url('admin/dms/esic_details'); ?>'+result.responseList.esic_basic_data_id);	
      },error:function(){

      }
    });
  });
  
 $(document).on( "click",'.delete_data',function() {
	var esic_basic_data_id=$(this).attr('basic_data_id'); 
	var esic_table_data_id = $(this).prop('title');
	alert(esic_table_data_id);
	$.ajax({
      type:'POST',
      url :'<?php echo base_url('admin/dms/delete_esic_table_data');?>',
      data:'esic_basic_data_id='+esic_basic_data_id+'&esic_table_data_id='+esic_table_data_id,
      dataType:'json',
      success:function(result){
		window.location.reload('<?php echo base_url('admin/dms/esic_details'); ?>'+result.responseList.esic_basic_data_id);	
      },error:function(){

      }
    });
 });
  
  
</script>
<style>
div.ex1 {
  overflow: scroll;
  height: 420px;
}
</style>