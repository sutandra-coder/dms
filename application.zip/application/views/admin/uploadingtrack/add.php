 <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
 <script src="<?php echo base_url()?>/public/validation/js/jquery.validate.js"></script>
<!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h3>
            Upload File
            
          </h3>         
        </section>

        <!-- Main content -->
        <section class="content"> 
			<div class="row">
				<!-- general form elements -->
				<div class="col-md-12">
					  <div class="box box-primary">						 
						<div class="box-header with-border">
						 <div class="admin-tab-wrapper">
							<div class="admin_tab">
								<!--<button class="btn btn-primary dropdown-toggle btn-algnmt" type="button" data-toggle="dropdown">Action
								<span class="caret"></span></button>-->
								<ul>
									<li><a href="javascript:void(0);" onclick="window.history.back();">Back</a></li>
								</ul>
							</div>
						</div>
						  <h3 class="box-title"></h3>
						  <?php if($this->session->flashdata('error_msg')){?>
								<span style="color:red; font-weight:bold"><?php echo $this->session->flashdata('error_msg');?></span>
							<?php }?>
							<?php if($this->session->flashdata('success_msg')){?>
								<span style="color:green; font-weight:bold"><?php  echo $this->session->flashdata('success_msg'); ?></span>
							<?php }?>
						</div>
						<!-- /.box-header -->
						<!-- form start -->
						<form id="signupForm" role="form" class="mtbresize" method="post" action="<?php echo base_url()."admin/dms/add_content"; ?>" enctype="multipart/form-data" autocomplete="off">
						  <div class="box-body">
							<div class="form-group">
								<label for="file_type">Uploading Type<sup class="superr">*</sup></label>
								<select class="form-control" id="file_type" name="file_type" >
									<option value="">Select</option>									
									<option value="pdf">PDF</option>									
								</select>							  
								<?php echo form_error('file_type','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
								<label for="content_type">Content Type<sup class="superr">*</sup></label>
								<select class="form-control" id="content_type" name="content_type" >
									<option value="">Select</option>									
									<option value="challan">Challan</option>	
									<option value="payment">Payment</option>
								</select>							  
								<?php echo form_error('content_type','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">							
							  <label for="imgInp">Upload<sup class="superr">*</sup></label>
							  <input name="files[]" type="file" multiple="multiple" id="files" />
							  <?php echo form_error('files','<span class="error">', '</span>'); ?>
							</div>
						  </div>
						  <!-- /.box-body -->
						  <div class="box-footer">							
							<button type="submit" class="btn btn-sm btn-primary">Submit</button>
						  </div>
						</form>
					  </div>
				</div>
          <!-- /.box -->
          </div><!-- /.row -->	
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-show-password/1.0.3/bootstrap-show-password.min.js"></script>
<script>
$( "#signupForm" ).validate( {
					rules: {
						file_type: "required",
						content_type: "required",
						files:"required"
					},
					messages: {						
						file_type: {required:"Uploading Type field is required"},
						content_type: {required:"Content Type field is required"},
						files: {required:"Upload field is required"},
					},
					errorElement: "em",
					
					highlight: function ( element, errorClass, validClass ) {
						$( element ).parents( ".form-control" ).addClass( "has-error" ).removeClass( "has-success" );
					},
					unhighlight: function (element, errorClass, validClass) {
						$( element ).parents( ".form-control" ).addClass( "has-success" ).removeClass( "has-error" );
					}
				} );
</script>