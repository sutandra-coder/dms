<style>
.cstm_view{font-size:15px;}
</style>
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
          <h3>
            Brand List
            
          </h3>
          <!--<ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>-->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box box-primary">
            <div class="box-header with-border">
			<div class="admin_tab">
			<ul>
				<li><a href="javascript:void(0);" onclick="window.history.back();">Back</a></li>				
			</ul>
			
				 
							
							<?php if($this->session->flashdata('error_msg')){?>
								<span style="color:red; font-weight:bold"><?php echo $this->session->flashdata('error_msg');?></span>
							<?php }?>
							<?php if($this->session->flashdata('success_msg')){?>
								<span style="color:green; font-weight:bold"><?php  echo $this->session->flashdata('success_msg'); ?></span>
							<?php }?>
				</div>			 
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example" class="table table-bordered table-striped">
                <thead>
                <tr>
				  <th>Sl. NO.</th>
				  <th>Brand</th>
				  <th>Image</th>
				  <th>Home Brand</th>				  
                </tr>
                </thead>
                <tbody>
				<?php $i=1; foreach($post_data as $row){ ?>
					<tr>
						<td><?php echo $i;?></td>						
						<td class="text-center">
                          <?php echo $row['meta_key_value'];?>
                        </td> 
						<td class="text-center">
						<?php if(!empty($row['image'])){?>
						  <img src="<?php echo $row['image'];?>"  width="50" height="60">	
						<?php } ?> 
						</td> 
						<td class="text-center">
                          <?php 
							if($row['home_brand']==1)
							{
								echo '<a class="cstm_view" id="active" href="javascript:void(0)" title="'.$row['meta_key_value_id'].'"><span class="glyphicon glyphicon-ok"></span></a>';
							}else{
								echo '<a class="cstm_view" id="inactive" href="javascript:void(0)" title="'.$row['meta_key_value_id'].'"><span class="glyphicon glyphicon-remove"></span></a>';
							}
						  ?>
                        </td>						
					</tr>
				<?php $i++;} ?>
                </tbody>
                <tfoot>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>

<script src="<?php echo base_url()?>public/admin_assets/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url()?>public/admin_assets/plugins/datatables/dataTables.bootstrap.min.js"></script>
<script>
var  table = $('#example').dataTable({
    'bLengthChange': false,
    'searching': true,
    'paging':   true,  // Table pagination
    'ordering': false,  // Column ordering
    'info':     true,  // Bottom left status text
    'responsive': true, // https://datatables.net/extensions/responsive/examples/
    // Text translation options
    // Note the required keywords between underscores (e.g _MENU_)
    oLanguage: {
        // sSearch:      'Search all columns:',
        sLengthMenu:  '_MENU_ records per page',
        info:         'Showing page _PAGE_ of _PAGES_',
        zeroRecords:  'Nothing found - sorry',
        infoEmpty:    'No records available',
        infoFiltered: '(filtered from _MAX_ total records)'
    },
    // set columns options
    'aoColumns': [
    {'bVisible':true},
    {'bVisible':true},
    {'bVisible':true},
	{'bVisible':true}
    ]
  });
	
	$(document).on( "click",'#active.cstm_view',function() {
		var p = $(this);
		p.html('---');		
		var id=$(this).prop('title');
		$.ajax({
		  type: "POST",
		  url: '<?php echo base_url('admin/productbrand/remove_home_brand')?>',
		  data: 'meta_key_value_id='+id,
		  dataType:'json',
		  success: function(response){
			p.attr("id", "inactive");
			p.html('<span class="glyphicon glyphicon-remove"></span>');	
			//window.location.reload('<?php echo base_url('admin/feedback'); ?>');	
		  }
		});
	});
	
	$(document).on( "click",'#inactive.cstm_view',function() {
		var pactive = $(this);
		pactive.html('---');		
		var id=$(this).prop('title');
		$.ajax({
		  type: "POST",
		  url: '<?php echo base_url('admin/productbrand/add_home_brand')?>',
		  data: 'meta_key_value_id='+id,
		  dataType:'json',
		  success: function(response){
			pactive.attr("id","active");
			pactive.html('<span class="glyphicon glyphicon-ok"></span>');						
			//window.location.reload('<?php echo base_url('admin/feedback'); ?>');		
		  }
		});
	});
	
	$(document).on( "click",'#delete_meta_key_value.cstm_view',function() {
		var meta_key_value_id=$(this).prop('title');		
		$.ajax({
			  type:'POST',
			  url :'<?php echo base_url('admin/metakeyvalue/delete_meta_key_value');?>',
			   data:'meta_key_value_id='+meta_key_value_id,
			  dataType:'json',
			  success:function(result){
				window.location.reload('<?php echo base_url('admin/metakeyvalue'); ?>');
			},error:function(){

			}
		});
	});
</script>