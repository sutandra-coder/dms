<style>
td.details-control {
    background: url('https://cdn.rawgit.com/DataTables/DataTables/6c7ada53ebc228ea9bc28b1b216e793b1825d188/examples/resources/details_open.png') no-repeat center center;
    cursor: pointer;
}
tr.shown td.details-control {
    background: url('https://cdn.rawgit.com/DataTables/DataTables/6c7ada53ebc228ea9bc28b1b216e793b1825d188/examples/resources/details_close.png') no-repeat center center;
}
</style>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
          <h3>
            Customer Exchange List
            
          </h3>
          <!--<ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>-->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box box-primary">
            <div class="box-header with-border">
			<div class="admin_tab">
			<ul>
				<li><a href="javascript:void(0);" onclick="window.history.back();">Back</a></li>				
			</ul>
			
				 
							
							<?php if($this->session->flashdata('error_msg')){?>
								<span style="color:red; font-weight:bold"><?php echo $this->session->flashdata('error_msg');?></span>
							<?php }?>
							<?php if($this->session->flashdata('success_msg')){?>
								<span style="color:green; font-weight:bold"><?php  echo $this->session->flashdata('success_msg'); ?></span>
							<?php }?>
			</div>			
            <!-- /.box-header -->
            <div class="box-body">
				<table id="example" class="table table-bordered table-striped">
					<thead>
						<tr>
									<th></th>
							<th>Amount</th>
							<th>Customer Name</th>
							<th>Exchange Date</th>							
						</tr>
					</thead>
					<tfoot>
						<tr>
									<th></th>
							<th>Amount</th>
							<th>Customer Name</th>
							<th>Exchange Date</th>	
						</tr>
					</tfoot>
				</table>
				
				 </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>

<script src="<?php echo base_url()?>public/admin_assets/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url()?>public/admin_assets/plugins/datatables/dataTables.bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>
<script>
/* Formatting function for row details - modify as you need */
function format ( d ) {
	content = '<table class="table table-bordered table-striped">';	
	content+=' <tr><th>Qsuestion</th><th>Question Description</th><th>Ans</th><th>Ans Image</th></tr>';
	$.each( d.questions, function( key, value ) {   
		if(value.ans_image == '')
		{
			image = '';
		}else{
			image = '<img src="'+value.ans_image+'"  width="50" height="50">';
			
		}
		content+='<tr><td>'+value.question+'</td><td>'+value.question_desc+'</td><td>'+value.ans+'</td><td>'+image+'</td>';
		content+="</tr>";
	});
	content+= '</table>';
	return content;
}

$(document).ready(function() {	
    var table = $('#example').DataTable({
		"processing": true,
		"ajax": {            
			"url": "<?php echo site_url('admin/customerexchange/all_content_list')?>",
			"type": "POST"			
        },
        'columns': [
            {
                'className':      'details-control',
                'orderable':      false,
                'data':           null,
                'defaultContent': ''
            },
            { 'data': 'amount' },
			{ 'data': 'first_name'},
			{ 'data':'last_update_ts'}
        ],
        'order': [[1, 'asc']]
    } );
	
	

    // Add event listener for opening and closing details
    $('#example tbody').on('click', 'td.details-control', function(){
        var tr = $(this).closest('tr');
        var row = table.row( tr );

        if(row.child.isShown()){
            // This row is already open - close it
            row.child.hide();
            tr.removeClass('shown');
        } else {
            // Open this row
            row.child(format(row.data())).show();
            tr.addClass('shown');
        }
    });

    // Handle click on "Expand All" button
    $('#btn-show-all-children').on('click', function(){
        // Enumerate all rows
        table.rows().every(function(){
            // If row has details collapsed
            if(!this.child.isShown()){
                // Open this row
                this.child(format(this.data())).show();
                $(this.node()).addClass('shown');
            }
        });
    });

    // Handle click on "Collapse All" button
    $('#btn-hide-all-children').on('click', function(){
        // Enumerate all rows
        table.rows().every(function(){
            // If row has details expanded
            if(this.child.isShown()){
                // Collapse row details
                this.child.hide();
                $(this.node()).removeClass('shown');
            }
        });
    });
});

</script>
