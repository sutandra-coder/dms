 <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
 <script src="<?php echo base_url()?>/public/validation/js/jquery.validate.js"></script>
<!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h3>
            Audience Settings
            
          </h3>         
        </section>

        <!-- Main content -->
        <section class="content"> 
			<div class="row">
				<!-- general form elements -->
				<div class="col-md-12">
					  <div class="box box-primary">						 
						<div class="box-header with-border">
						 <div class="admin-tab-wrapper">
							<div class="admin_tab">
								<!--<button class="btn btn-primary dropdown-toggle btn-algnmt" type="button" data-toggle="dropdown">Action
								<span class="caret"></span></button>-->
								<ul>
									<li><a href="javascript:void(0);" onclick="window.history.back();">Back</a></li>
								</ul>
							</div>
						</div>
						  <h3 class="box-title"></h3>
						  <?php if($this->session->flashdata('error_msg')){?>
								<span style="color:red; font-weight:bold"><?php echo $this->session->flashdata('error_msg');?></span>
							<?php }?>
							<?php if($this->session->flashdata('success_msg')){?>
								<span style="color:green; font-weight:bold"><?php  echo $this->session->flashdata('success_msg'); ?></span>
							<?php }?>
						</div>
						<!-- /.box-header -->
						<!-- form start -->
						<form id="signupForm" role="form" class="mtbresize" method="post" action="<?php echo base_url('admin/audience/update');?>" enctype="multipart/form-data" autocomplete="off">
						  <div class="box-body">
							<div class="form-group">
							  <label for="audience_name">Name<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="audience_name" name="audience_name" value="<?php echo $cms['audience_name'];?>" placeholder="Audience Name" required="required">
							  <?php echo form_error('audience_name','<span class="error">', '</span>'); ?>
							</div>
							<?php if(!empty($cms['less_value']) && !empty($cms['gretter_value'])){?>
							<div class="form-check">
								<input type="checkbox" class="form-check-input" id="user_value_check" name="user_value_check" value="1" checked>
								<label class="form-check-label" for="exampleCheck1">User Value</label>
							</div>
							<?php }else{ ?>
							<div class="form-check">
								<input type="checkbox" class="form-check-input" id="user_value_check" name="user_value_check" value="1">
								<label class="form-check-label" for="exampleCheck1">User Value</label>
							</div>
							<?php }?>
							<?php if(!empty($cms['less_value']) && !empty($cms['gretter_value'])){?>
							<div id="user_value_box">
								<div class="form-group">
								  <label for="gretter_value">Greater Than Value</label>
								  <input type="text" class="form-control" id="gretter_value" name="gretter_value" value="<?php echo $cms['gretter_value'];?>" placeholder="Gretter Value">
								  <?php echo form_error('gretter_value','<span class="error">', '</span>'); ?>
								</div>
								<div class="form-group">
								  <label for="gretter_value">Less Than Value</label>
								  <input type="text" class="form-control" id="less_value" name="less_value" value="<?php echo $cms['less_value'];?>" placeholder="Less Value">
								  <?php echo form_error('less_value','<span class="error">', '</span>'); ?>
								</div>
							</div>
							<?php }else{ ?> 
							<div id="user_value_box">
								<div class="form-group">
								  <label for="gretter_value">Greater Than Value</label>
								  <input type="text" class="form-control" id="gretter_value" name="gretter_value" value="<?php echo set_value('gretter_value');?>" placeholder="Gretter Value">
								  <?php echo form_error('gretter_value','<span class="error">', '</span>'); ?>
								</div>
								<div class="form-group">
								  <label for="gretter_value">Less Than Value</label>
								  <input type="text" class="form-control" id="less_value" name="less_value" value="<?php echo set_value('less_value');?>" placeholder="Less Value">
								  <?php echo form_error('less_value','<span class="error">', '</span>'); ?>
								</div>
							</div>
							<?php } ?>
							<?php if(!empty($cms['brand_id'])){?>
							<div class="form-check">
								<input type="checkbox" class="form-check-input" id="user_brand_check" name="user_brand_check" value="1" checked>
								<label class="form-check-label" for="exampleCheck1">User Brand</label>
							</div>
							<?php }else{ ?>
							<div class="form-check">
								<input type="checkbox" class="form-check-input" id="user_brand_check" name="user_brand_check" value="1">
								<label class="form-check-label" for="exampleCheck1">User Brand</label>
							</div>
							<?php } ?>
							<?php if(!empty($cms['brand_id'])){?>
							<div id="user_brand_box">
								<div class="form-group">
							  <label for="audience_user_brand_id">Brand</label>
							  <select class="form-control" id="audience_user_brand_id" name="audience_user_brand_id" >
								<option value="">Select</option>
								<?php foreach($brand_list as $brand){?>									
								<option value="<?php echo $brand['meta_key_value_id']?>" <?php if($brand['meta_key_value_id'] == $cms['brand_id']){echo "selected"; }?>><?php echo $brand['meta_key_value']?></option>									
								<?php } ?>
							 </select>							  
							</div>
							</div>
							<?php }else{ ?>
							<div id="user_brand_box">
								<div class="form-group">
							  <label for="audience_user_brand_id">Brand</label>
							  <select class="form-control" id="audience_user_brand_id" name="audience_user_brand_id" >
								<option value="">Select</option>
								<?php foreach($brand_list as $brand){?>									
								<option value="<?php echo $brand['meta_key_value_id']?>"><?php echo $brand['meta_key_value']?></option>									
								<?php } ?>
							 </select>							  
							</div>
							</div>
							<?php } ?>
							<?php if(!empty($cms['retailer_id'])){?>
							<div class="form-check">
								<input type="checkbox" class="form-check-input" id="user_retailer_check" name="user_retailer_check" value="1" checked>
								<label class="form-check-label" for="exampleCheck1">User Retailer</label>
							</div>
							<?php }else{ ?>
							<div class="form-check">
								<input type="checkbox" class="form-check-input" id="user_retailer_check" name="user_retailer_check" value="1">
								<label class="form-check-label" for="exampleCheck1">User Retailer</label>
							</div>
							<?php } ?>
							<?php if(!empty($cms['retailer_id'])){?>
							<div id="user_retailer_box">
								<div class="form-group">
							  <label for="audience_user_retailer_id">Retailer</label>
							  <select class="form-control" id="audience_user_retailer_id" name="audience_user_retailer_id" >
								<option value="">Select</option>
								<?php foreach($retailer_list as $retailer){?>									
								<option value="<?php echo $retailer['retailer_store_id']?>" <?php if($cms['retailer_id'] == $retailer['retailer_store_id']){echo "selected";}?>><?php echo $retailer['city']?></option>									
								<?php } ?>
							 </select>							  
							</div>
							</div>
							<?php }else{ ?>
							<div id="user_retailer_box">
								<div class="form-group">
							  <label for="audience_user_retailer_id">Retailer</label>
							  <select class="form-control" id="audience_user_retailer_id" name="audience_user_retailer_id" >
								<option value="">Select</option>
								<?php foreach($retailer_list as $retailer){?>									
								<option value="<?php echo $retailer['retailer_store_id']?>"><?php echo $retailer['city']?></option>									
								<?php } ?>
							 </select>							  
							</div>
							</div>
							<?php } ?>
							<?php if(!empty($cms['last_purchase_date'])){?>
							<div class="form-check">
								<input type="checkbox" class="form-check-input" id="user_last_purchase_date_check" name="user_last_purchase_date_check" value="1" checked>
								<label class="form-check-label" for="exampleCheck1">User Last Purchase Date</label>
							</div>
							<?php }else{ ?>
							<div class="form-check">
								<input type="checkbox" class="form-check-input" id="user_last_purchase_date_check" name="user_last_purchase_date_check" value="1">
								<label class="form-check-label" for="exampleCheck1">User Last Purchase Date</label>
							</div>
							<?php } ?>
							<?php if(!empty($cms['last_purchase_date'])){?>
							<div id="user_last_purchase_date_box">
								<div class="form-group">
									<label>Last Purchase Date</label>
									<div class='input-group date'>
										<input type='text' class="form-control" placeholder="Last Purchase Date" value="<?php echo $cms['last_purchase_date'];?>" id="last_purchase_date" name="audience_last_purchase_date"/>
										<span class="input-group-addon">
											<span class="glyphicon glyphicon-calendar"></span>
										</span>
									</div>
								</div>
							</div>
							<?php }else{ ?>
							<div id="user_last_purchase_date_box">
								<div class="form-group">
									<label>Last Purchase Date</label>
									<div class='input-group date'>
										<input type='text' class="form-control" placeholder="Last Purchase Date"  id="last_purchase_date" name="audience_last_purchase_date"/>
										<span class="input-group-addon">
											<span class="glyphicon glyphicon-calendar"></span>
										</span>
									</div>
								</div>
							</div>
							<?php } ?>
						  </div>
						  <!-- /.box-body -->
						  <div class="box-footer">		
							<input type="hidden" id="audience_id" name="audience_id" value="<?php echo $cms['audience_id']; ?>">
							<button type="submit" class="btn btn-sm btn-primary">Submit</button>
						  </div>
						</form>
					  </div>
				</div>
          <!-- /.box -->
          </div><!-- /.row -->	
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-show-password/1.0.3/bootstrap-show-password.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>
<script>
$( "#signupForm" ).validate( {
					rules: {
						audience_name: "required"
					},
					messages: {						
						audience_name: {required:"Audience Name field is required"}
					},
					errorElement: "em",
					
					highlight: function ( element, errorClass, validClass ) {
						$( element ).parents( ".form-control" ).addClass( "has-error" ).removeClass( "has-success" );
					},
					unhighlight: function (element, errorClass, validClass) {
						$( element ).parents( ".form-control" ).addClass( "has-success" ).removeClass( "has-error" );
					}
				} );
				
$('#user_value_check').click(function(){
    if($(this).prop("checked") == true){
		$("#user_value_box").show();
    }else{
		$("#user_value_box").hide();
	}
});

$('#user_brand_check').click(function(){
    if($(this).prop("checked") == true){
		$("#user_brand_box").show();
    }else{
		$("#user_brand_box").hide();
	}
});

$('#user_retailer_check').click(function(){
    if($(this).prop("checked") == true){
		$("#user_retailer_box").show();
    }else{
		$("#user_retailer_box").hide();
	}
});

$('#user_last_purchase_date_check').click(function(){
    if($(this).prop("checked") == true){
		$("#user_last_purchase_date_box").show();
    }else{
		$("#user_last_purchase_date_box").hide();
	}
});

$( document ).ready(function() {
   if($('#user_value_check').prop("checked") == true){
		$("#user_value_box").show();
    }else{
		$("#user_value_box").hide();
	}
	if($('#user_brand_check').prop("checked") == true){
		$("#user_brand_box").show();
    }else{
		$("#user_brand_box").hide();
	}
	if($('#user_retailer_check').prop("checked") == true){
		$("#user_retailer_box").show();
    }else{
		$("#user_retailer_box").hide();
	}
	if($('#user_last_purchase_date_check').prop("checked") == true){
		$("#user_last_purchase_date_box").show();
    }else{
		$("#user_last_purchase_date_box").hide();
	}
});

$('#last_purchase_date').datepicker({
	maxDate: '0',
	format: 'yyyy-mm-dd',
	setDate: new Date()
});
</script>