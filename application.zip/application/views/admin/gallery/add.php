<!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h3>
            Upload Settings
            
          </h3>
          <!--<ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>-->
        </section>
        <!-- Main content -->
        <section class="content"> 
			<div class="row">
				<!-- general form elements -->
				<div class="col-md-12">
					  <div class="box box-primary">
						<div class="box-header with-border">
						  <h3 class="box-title"></h3>
						   <div class="status"></div>
						</div>
						<!-- /.box-header -->
						<!-- form start -->
						<form role="form" class="mtbresize" method="post" action="<?php echo base_url('admin/gallery/contenta');?>" autocomplete="off" enctype="multipart/form-data">
						  <div class="box-body">
						  
							<div class="form-group">
							  <label>Course</label>
							  <select class="form-control" name="course_id" id="course_id">
								<option value="168">Physics11thNCERTSolution</option>
								<option value="169">Physics11thNCERTBook</option>
								<option value="170">Physics11thNOTES</option>
								<option value="171">Physics12thNCERTSolution</option>
								<option value="172">Physics12thNCERTBook</option>
								<option value="173">Physics12thNOTES</option>
								<option value="174">PhysicsNEET/JEE</option>
								<option value="130">Chemistry11thNCERTSolution</option>
								<option value="131">Chemistry11thNCERTBook</option>
								<option value="132">Chemistry11thNOTES</option>
								<option value="133">Chemistry12thNCERTSolution</option>
								<option value="134">Chemistry12thNCERTBook</option>
								<option value="135">Chemistry12thNOTES</option>
								<option value="136">ChemistryNEET/JEE</option>
								<option value="137">Mathematics11thNCERTSolution</option>
								<option value="138">Mathematics11thNCERTBook</option>
								<option value="139">Mathematics11thNOTES</option>
								<option value="140">Mathematics12thNCERTSolution</option>
								<option value="141">Mathematics12thNCERTBook</option>
								<option value="142">Mathematics12thNOTES</option>
								<option value="143">MathematicsNEET/JEE</option>
								<option value="144">Biology11thNCERTSolution</option>
								<option value="145">Biology11thNCERTBook</option>
								<option value="146">Biology11thNOTES</option>
								<option value="148">Biology12thNCERTSolution</option>
								<option value="149">Biology12thNCERTBook</option>
								<option value="150">Biology12thNOTES</option>
								<option value="147">BiologyNEET/JEE</option>
								<option value="175">HC Verma Solution 1</option>
								<option value="176">HC Verma Solution 2</option>
							  </select>
							</div>
							
							<div class="form-group">
							
							  <label for="imgInp">Upload<sup class="superr">*</sup></label>
							  <input name="files[]" type="file" multiple="multiple" />
							  <?php echo form_error('files','<span class="error">', '</span>'); ?>
							 
							  <div class="progress"> 
								<div class="bar">&nbsp;</div >								 
								<div class="percent">0%</div >
								</div>  
							</div>
							<div id="ftr-btn">																				
						  <!-- /.box-body -->
							
						  <div class="box-footer" style="padding-top:20px;">
							<button type="submit" class="btn btn-sm btn-primary">Submit</button>
						  </div>
						  </div>
						</form>
					  </div>
				</div>
          <!-- /.box -->
          </div><!-- /.row -->	
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery.form/4.3.0/jquery.form.js"></script>
<style>
.container {
  background: #fff;
  border: 1px solid #ccc;
  -webkit-border-radius: 5px;
  -moz-border-radius: 5px;
  border-radius: 5px;
  margin: 10px auto;
  padding: 10px 0;
  text-align: center;
  width: 600px;
}
.status {
  background: #008000;
  color: #fff;
  display: none;
  margin: 8px 0;
  padding: 5px;
}
.progress {
  margin: 10px auto;
  position: relative;
  width: 90%;
}
.bar {
  background: #008DE6;
  height: 20px;
  -webkit-border-radius: 5px;
  -moz-border-radius: 5px;
  border-radius: 5px;
  transition: width 0.3s ease 0s;
  width: 0;
}
.percent {
  color: #333;
  left: 48%;
  position: absolute;
  top: 0;
}
.button{
  margin: 5px 0;
}
</style>
<script>
$(function() {
  var status = $('.status');
  var percent = $('.percent');
  var bar = $('.bar');
 
  $('form').ajaxForm({
    dataType:'json',
    beforeSend: function() {
        status.fadeOut();
        bar.width('0%');
        percent.html('0%');
    },
 
    /* progress bar call back*/
    uploadProgress: function(event, position, total, percentComplete) {
        var pVel = percentComplete + '%';
        bar.width(pVel);
        percent.html(pVel);
    },
 
    /* complete call back */
    complete: function() {
        status.html('Files uploaded!').fadeIn();
    }
 
  });
});
</script>
