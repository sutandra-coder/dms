<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Admin Panel</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="<?php echo base_url()?>/public/admin_assets/bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="<?php echo base_url()?>/public/admin_assets/plugins/datatables/dataTables.bootstrap.css">
  <link rel="stylesheet" href="<?php echo base_url()?>/public/admin_assets/plugins/datatables/buttons.dataTables.min.css">
  <link rel="stylesheet" href="<?php echo base_url()?>public/admin_assets/plugins/select2/select2.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url()?>/public/admin_assets/dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="<?php echo base_url()?>/public/admin_assets/dist/css/skins/_all-skins.min.css">
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
  <style>
  .mtbresize {
    margin: 0 auto;
    width: 800px;
  }
  .error{color:red;}
  .cstm_view{
	font-size:20px;
	}
   .hite{
	   height:50px;
	   width:900px;
   }
   .superr{
	   color:red;
	   font-size:18px;
	   top: -.1px;
   }
   
.admin_tab ul{padding-left:0;}
.admin_tab ul li{display:inline-block;list-style:none;width:9%;text-align:center;}
.admin_tab ul li a{color:#fff;background:#367fa9;padding:6px 12px;border-radius:3px;display:block;margin-right:10px;}
.admin_tab ul li a:hover{background:#367fa9;}
.admin-tab-wrapper{padding:7px 10px;background:#fff;}
</style>
<!-- jQuery 2.2.3 -->
<script src="<?php echo base_url()?>/public/admin_assets/plugins/jQuery/jquery-2.2.3.min.js"></script>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
	<?php $admin=$this->session->userdata('admin'); ?>
    <!-- Logo -->
    <a href="<?php echo base_url('admin');?>" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>A</b>DP</span>
	  <img src="<?php echo $admin['logo'];?>" style="width:80px;">
      <!-- logo for regular state and mobile devices -->
    </a>

    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
      <!-- Navbar Right Menu -->
	<div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
         <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
            <?php if(!empty($admin['logo'])){?>
            <img src="<?php echo $admin['logo'];?>" class="user-image" alt="User Image">
            <?php }else{?>
            <img src="<?php echo base_url()?>public/admin_assets/images/profilepics/Dummy.jpg?>" class="user-image" alt="User Image">
            <?php }?>
              <span class="hidden-xs"><?php echo $admin['user_name'];?></span>
            </a>
            <ul class="dropdown-menu">
            
              <li class="user-header">
                <?php if(!empty($admin['logo'])){?>
                <img src="<?php echo $admin['logo'];?>" class="img-circle" alt="User Image">
                <?php }else{?>
                <img src="<?php echo base_url()?>public/admin_assets/images/profilepics/Dummy.jpg" class="img-circle" alt="User Image">
                <?php }?>
                <p>
                  <?php echo $admin['user_name'];?>
                  <small><?php echo $admin['email'];?></small>
                </p>
              </li>
             
             
              <li class="user-footer">
                <div class="pull-right">
                  <a href="<?php echo base_url('admin/logout');?>" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li> 
        </ul>
      </div>

    </nav>
  </header>