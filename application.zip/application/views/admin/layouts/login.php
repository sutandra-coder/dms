<?php
$this->load->view('admin/layouts/header_login');
$this->load->view($content);
$this->load->view('admin/layouts/footer_login');