<!-- Left side column. contains the logo and sidebar -->
<?php $admin=$this->session->userdata('admin'); ?>
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <?php if(!empty($admin['logo'])) {?>
          <img src="<?php echo $admin['logo'];?>" class="img-circle" alt="User Image">
          <?php }else{?>
          <img src="<?php echo base_url()?>public/admin_assets/images/profilepics/Dummy.jpg" class="img-circle" alt="User Image">
          <?php }?>
          
        </div>
        <div class="pull-left info">
          <p>Hello <?php echo $admin['organization_name'];?></p>
          <!--<a href="#"><i class="fa fa-circle text-success"></i> Online</a>-->
        </div>
      </div>
      <!-- search form -->
     <!-- <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Search...">
              <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                </button>
              </span>
        </div>
      </form> -->
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
	 
	 
       <ul class="sidebar-menu">
		<li class="treeview">
          <a href="#">
            <i class="fa fa-bolt"></i>
            <span>CMS</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url('admin/newarrival');?>"><i class="fa fa-circle-o"></i>New Arrival</a></li>
			<li><a href="<?php echo base_url('admin/productcategory');?>"><i class="fa fa-circle-o"></i>Product Catgeory</a></li>
			<li><a href="<?php echo base_url('admin/productbrand');?>"><i class="fa fa-circle-o"></i>Product Brand</a></li>	
			<li><a href="<?php echo base_url('admin/offersection');?>"><i class="fa fa-circle-o"></i>Offer Section</a></li>
          </ul>
        </li>
		<li class="treeview">
          <a href="#">
            <i class="fa fa-percent"></i>
            <span>Campaign Management</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
			<li><a href="<?php echo base_url('admin/campaign');?>"><i class="fa fa-circle-o"></i>Create Campaign</a></li>
			<li><a href="<?php echo base_url('admin/audience');?>"><i class="fa fa-circle-o"></i>Create Audience</a></li>
            <li><a href="<?php echo base_url('admin/offer');?>"><i class="fa fa-circle-o"></i>Offer</a></li>	
			<li><a href="<?php echo base_url('admin/referalloyalty');?>"><i class="fa fa-circle-o"></i>Referal Value</a></li>
          </ul>
        </li>
		<li class="treeview">
          <a href="#">
            <i class="fa fa-product-hunt"></i>
            <span>Product Management</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
			<?php if ($admin['organisation_id'] == 1){ ?>
				<li><a href="<?php echo base_url('admin/metakey');?>"><i class="fa fa-circle-o"></i>Tag</a></li>
				<li><a href="<?php echo base_url('admin/metakeyvalue');?>"><i class="fa fa-circle-o"></i>Tag Values</a></li>
			<?php } ?>
			<li><a href="<?php echo base_url('admin/catalog');?>"><i class="fa fa-circle-o"></i>Catalog</a></li>
			<li><a href="<?php echo base_url('admin/product');?>"><i class="fa fa-circle-o"></i>Product</a></li>			
          </ul>
        </li>
		<li class="treeview">
          <a href="#">
            <i class="fa fa-user"></i>
            <span>Customer Management</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url('admin/customer');?>"><i class="fa fa-circle-o"></i>Customer List</a></li>		
          </ul>
        </li>
		<li class="treeview">
          <a href="#">
            <i class="fa fa-shopping-cart"></i>
            <span>Order Management</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">           	
			<li><a href="<?php echo base_url('admin/customerorder');?>"><i class="fa fa-circle-o"></i>Order List</a></li>	
          </ul>
        </li>
		<li class="treeview">
          <a href="#">
            <i class="fa fa-question-circle"></i>
            <span>Enquiry management</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu"> 
			<li><a href="<?php echo base_url('admin/enquierytype');?>"><i class="fa fa-circle-o"></i>Enquiry Type List</a></li>
			<li><a href="<?php echo base_url('admin/enquiery');?>"><i class="fa fa-circle-o"></i>User Enquiry List</a></li>	
          </ul>
        </li>
		<li class="treeview">
          <a href="#">
			<i class="fa fa-phone"></i>
            <span>Exchange Management</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">           	
			<li><a href="<?php echo base_url('admin/customerexchange');?>"><i class="fa fa-circle-o"></i>Customer Exchange</a></li>	
          </ul>
        </li>
      </ul> 
    </section>
    <!-- /.sidebar -->
  </aside>