 <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
 <script src="<?php echo base_url()?>/public/validation/js/jquery.validate.js"></script>
<!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h3>
            TDS Challan Data
            
          </h3>         
        </section>

        <!-- Main content -->
        <section class="content"> 
			<div class="row">
				<div class="col-md-6">										
					<div class="embed-responsive embed-responsive-4by3">
					<?php echo base_url()."/public/images/".$uploadig_file_name; ?>
						<iframe class="embed-responsive-item" src="<?php echo base_url()."/public/images/".$uploadig_file_name; ?>" allowfullscreen></iframe>
					</div>
				</div>
				<!-- general form elements -->
				<div class="col-md-6">
					  <div class="box box-primary ex1">						 
						<div class="box-header with-border">						
						  <h3 class="box-title"></h3>
						  <?php if($this->session->flashdata('error_msg')){?>
								<span style="color:red; font-weight:bold"><?php echo $this->session->flashdata('error_msg');?></span>
							<?php }?>
							<?php if($this->session->flashdata('success_msg')){?>
								<span style="color:green; font-weight:bold"><?php  echo $this->session->flashdata('success_msg'); ?></span>
							<?php }?>
						</div>
						<!-- /.box-header -->
						<!-- form start -->
						<form id="signupForm" role="form" class="mtbresize" method="post" action="<?php echo base_url()."admin/tdsdms/tds_challan_data_update"; ?>" enctype="multipart/form-data" autocomplete="off">
						  <div class="box-body">							
							<div class="form-group">
							  <label for="name_of_the_assessee_data">Name of the Assessee<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="name_of_the_assessee_data" name="name_of_the_assessee_data" value="<?php echo $cms['name_of_the_assessee_data'];?>" placeholder="Name Of The Assessee Data" required="required">
							  <?php echo form_error('name_of_the_assessee_data','<span class="error">', '</span>'); ?>
							</div>	
							<div class="form-group">
							  <label for="complete_address">Complete Address<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="complete_address" name="complete_address" value="<?php echo $cms['complete_address'];?>" placeholder="Complete Address" required="required">
							  <?php echo form_error('complete_address','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="tan_data">Tan<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="tan_data" name="tan_data" value="<?php echo $cms['tan_data'];?>" placeholder="Tan Data" required="required">
							  <?php echo form_error('tan_data','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="major_head_data">Major Head<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="major_head_data" name="major_head_data" value="<?php echo $cms['major_head_data'];?>" placeholder="Major Head Data" required="required">
							  <?php echo form_error('due_for_the_wages_month_of_data','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="minor_head_data">Minor Head<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="minor_head_data" name="minor_head_data" value="<?php echo $cms['minor_head_data'];?>" placeholder="Minor Head Data" required="required">
							  <?php echo form_error('minor_head_data','<span class="error">', '</span>'); ?>
							</div>		
							<div class="form-group">
							  <label for="nature_of_the_payment_data">Nature Of The Payment Data<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="nature_of_the_payment_data" name="nature_of_the_payment_data" value="<?php echo $cms['nature_of_the_payment_data'];?>" placeholder="Nature of the payment data" required="required">
							  <?php echo form_error('nature_of_the_payment_data','<span class="error">', '</span>'); ?>
							</div>
							<div class="col-md-6">			
								<table class="table">
								  <thead>
									<tr>
									  <th scope="col">Description Of Tax</th>
									  <th scope="col">Amount Of Rupees</th>								  
									</tr>
								  </thead>
								  <tbody>
									<tr>								 
									  <td>Basic Tax</td>
									  <td><input type="text" class="form-control" id="basic_tax_data" name="basic_tax_data" value="<?php echo $cms['basic_tax_data'];?>" placeholder="Basic Tax" required="required"></td>								  
									</tr>
									<tr>								  
									  <td>Surcharge</td>
									  <td><input type="text" class="form-control" id="surcharge_data" name="surcharge_data" value="<?php echo $cms['surcharge_data'];?>" placeholder="Surcharge" required="required"></td>									  
									</tr>
									<tr>								  
									  <td>Education Cess</td>
									  <td><input type="text" class="form-control" id="education_cess_data" name="education_cess_data" value="<?php echo $cms['education_cess_data'];?>" placeholder="Education Cess" required="required"></td>									  
									</tr>
									<tr>								  
									  <td>Penalty</td>
									  <td><input type="text" class="form-control" id="penalty_data" name="penalty_data" value="<?php echo $cms['penalty_data'];?>" placeholder="Penalty" required="required"></td>									  
									</tr>
									<tr>								  
									  <td>Others</td>
									  <td><input type="text" class="form-control" id="oters_data" name="oters_data" value="<?php echo $cms['oters_data'];?>" placeholder="Others" required="required"></td>									  
									</tr>
									<tr>								  
									  <td>Interest</td>
									  <td><input type="text" class="form-control" id="interest_data" name="interest_data" value="<?php echo $cms['interest_data'];?>" placeholder="Interest" required="required"></td>									  
									</tr>
									<tr>								  
									  <td>Fee Under Sec. 234 E</td>
									  <td><input type="text" class="form-control" id="fee_under_Sec_e_data" name="fee_under_Sec_e_data" value="<?php echo $cms['fee_under_Sec_e_data'];?>" placeholder="Fee Under Sec. 234 E" required="required"></td>									  
									</tr>
									<tr>								  
									  <td>Total</td>
									  <td><input type="text" class="form-control" id="total_data" name="total_data" value="<?php echo $cms['total_data'];?>" placeholder="Total" required="required"></td>									  
									</tr>
								  </tbody>
								</table>
							</div>	
							<div class="col-md-6">
								<table class="table">
									 <thead>
										<tr>
											<th scope="col" colspan=2>HDFC BANK LIMITED</th>
										</tr>
									 </thead>
									 <tbody>
										<tr>
											<td>Challan No</td>
											<td><input type="text" class="form-control" id="challan_no_data" name="challan_no_data" value="<?php echo $cms['challan_no_data'];?>" placeholder="Challan No" required="required"></td>
										</tr>
										<tr>
											<td>BSR Code</td>
											<td><input type="text" class="form-control" id="bsr_code_data" name="bsr_code_data" value="<?php echo $cms['bsr_code_data'];?>" placeholder="Bsr Code" required="required"></td>
										</tr>
										<tr>
											<td>Date Of Receipt</td>
											<td><input type="text" class="form-control" id="date_of_receipt_data" name="date_of_receipt_data" value="<?php echo $cms['date_of_receipt_data'];?>" placeholder="Date Of Receipt" required="required"></td>
										</tr>
										<tr>
											<td>Challan Serial No</td>
											<td><input type="text" class="form-control" id="challan_serial_no_data" name="challan_serial_no_data" value="<?php echo $cms['challan_serial_no_data'];?>" placeholder="Challan Serial No" required="required"></td>
										</tr>
										<tr>
											<td>Assessment Year</td>
											<td><input type="text" class="form-control" id="assessment_year_data" name="assessment_year_data" value="<?php echo $cms['assessment_year_data'];?>" placeholder="Assessment Year" required="required"></td>
										</tr>
										<tr>
											<td>Bank Reference Data</td>
											<td><input type="text" class="form-control" id="bank_reference_data" name="bank_reference_data" value="<?php echo $cms['bank_reference_data'];?>" placeholder="Bank Reference Data" required="required"></td>
										</tr>
										<tr>
											<td>Drawn On</td>
											<td><input type="text" class="form-control" id="drawn_on_data" name="drawn_on_data" value="<?php echo $cms['drawn_on_data'];?>" placeholder="Drawn On" required="required"></td>
										</tr>
										<tr>
											<td>&nbsp;</td>
											<td>&nbsp;</td>
										</tr>
										<tr>
											<td>&nbsp;</td>
											<td>&nbsp;</td>
										</tr>
									 </tbody>
								</table>
							</div>							
							<div class="form-group">
							  <label for="rupees_in_words_data">Rupees (In words)<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="rupees_in_words_data" name="rupees_in_words_data" value="<?php echo $cms['rupees_in_words_data'];?>" placeholder="Rupees (In words)" required="required">
							  <?php echo form_error('rupees_in_words_data','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="cin_data">CIN<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="cin_data" name="cin_data" value="<?php echo $cms['cin_data'];?>" placeholder="CIN" required="required">
							  <?php echo form_error('cin_data','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="debit_acount_no_data">Debit Account No.<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="debit_acount_no_data" name="debit_acount_no_data" value="<?php echo $cms['debit_acount_no_data'];?>" placeholder="Debit Acount No" required="required">
							  <?php echo form_error('debit_acount_no_data','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="payment_realization_date_data">Payment Realization Date<sup class="superr">*</sup></label>
							  <input type="text" class="form-control" id="payment_realization_date_data" name="payment_realization_date_data" value="<?php echo $cms['payment_realization_date_data'];?>" placeholder="Payment realization date data" required="required">
							  <?php echo form_error('payment_realization_date_data','<span class="error">', '</span>'); ?>
							</div>
						  </div>
						  <div class="box-footer">
							<input type="hidden" id="tds_challan_id" name="tds_challan_id" value="<?php echo $cms['tds_challan_id']; ?>">
							<input type="hidden" id="uploading_track_details_id" name="uploading_track_details_id" value="<?php echo $cms['uploading_track_details_id']; ?>">
							<button type="submit" class="btn btn-sm btn-primary">Submit</button>
						  </div>
						</form>						
						  <!-- /.box-body -->						  
					  </div>
				</div>
          <!-- /.box -->
          </div><!-- /.row -->	
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
	  
<div class="modal" id='myModal2'>
    <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span></button>
                <h4 class="modal-title">Esic Table Data</h4>
              </div>
              <div class="modal-body" id='modalContent2' title="">
				<div class="form-group">
					<label for="is_disable">Is Disable<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Is disable" id="is_disable" name="is_disable" >
				</div>
				<div class="form-group">
					<label for="ip_number">Ip Number<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Ip Number" id="ip_number" name="ip_number" >
				</div>
				<div class="form-group">
					<label for="ip_name">Ip Name<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Ip Name" id="ip_name" name="ip_name" >
				</div>
				<div class="form-group">
					<label for="no_of_days">No Of Days<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="No Of Days" id="no_of_days" name="no_of_days" >
				</div>
				<div class="form-group">
					<label for="total_wages">Total Wages<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Total Wages" id="total_wages" name="total_wages" >
				</div>
				<div class="form-group">
					<label for="ip_contribution">Ip Contribution<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="ip_contribution" id="ip_contribution" name="ip_contribution" >
				</div>
				<div class="form-group">
					<label for="reason">Reason<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="reason" id="reason" name="reason" >
				</div>
				<input type='hidden' class="form-control" id="esic_table_data_id">
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal" id="cdel2">save</button>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
		
<div class="modal" id='myModal3'>
    <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span></button>
                <h4 class="modal-title">Esic Table Data</h4>
              </div>
              <div class="modal-body" id='modalContent2' title="">
				<div class="form-group">
					<label for="is_disable">Is Disable<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Is disable" id="is_disable_add" name="is_disable_add" >
				</div>
				<div class="form-group">
					<label for="ip_number">Ip Number<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Ip Number" id="ip_number_add" name="ip_number_add" >
				</div>
				<div class="form-group">
					<label for="ip_name">Ip Name<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Ip Name" id="ip_name_add" name="ip_name_add" >
				</div>
				<div class="form-group">
					<label for="no_of_days">No Of Days<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="No Of Days" id="no_of_days_add" name="no_of_days_add" >
				</div>
				<div class="form-group">
					<label for="total_wages">Total Wages<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Total Wages" id="total_wages_add" name="total_wages_add" >
				</div>
				<div class="form-group">
					<label for="ip_contribution">Ip Contribution<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="Ip Contribution" id="ip_contribution_add" name="ip_contribution_add" >
				</div>
				<div class="form-group">
					<label for="reason">Reason<sup class="superr">*</sup></label>
					<input type='text' class="form-control" placeholder="reason" id="reason_add" name="reason_add" >
				</div>
				<input type='hidden' class="form-control" id="esic_basic_data_id">
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal" id="cdel2_add">save</button>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
		
<script src="https://cdn.ckeditor.com/4.5.7/standard/ckeditor.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-show-password/1.0.3/bootstrap-show-password.min.js"></script>
<script>
$( "#signupForm" ).validate( {
					rules: {
						product_name: "required",
						meta_key_id:"required",
						brand_id:"required"
						
						
					},
					messages: {						
						product_name: {required:"name field is required"},
						meta_key_id: {required:"Category field is required"},
						brand_id: {required:"Brand field is required"}
						
					},
					errorElement: "em",
					
					highlight: function ( element, errorClass, validClass ) {
						$( element ).parents( ".form-control" ).addClass( "has-error" ).removeClass( "has-success" );
					},
					unhighlight: function (element, errorClass, validClass) {
						$( element ).parents( ".form-control" ).addClass( "has-success" ).removeClass( "has-error" );
					}
				} );
				
$(document).on( "click",'.cstm_view',function() {
    var esic_table_data_id=$(this).prop('title');
    var content='<div class="box-body"><table class="table table-bordered">';
	 $.ajax({
      type:'POST',
      url :'<?php echo base_url('admin/dms/esic_table_details');?>',
      data:'esic_table_data_id='+esic_table_data_id,
      dataType:'json',
      success:function(result){
		$("#is_disable").val(result.responseList.is_disable);
		$("#ip_number").val(result.responseList.ip_number);
		$("#ip_name").val(result.responseList.ip_name);
		$("#no_of_days").val(result.responseList.no_of_days);
		$("#total_wages").val(result.responseList.total_wages);
		$("#ip_contribution").val(result.responseList.ip_contribution);
		$("#reason").val(result.responseList.reason);
		$("#esic_table_data_id").val(result.responseList.esic_table_data_id);
      },error:function(){

      }
    });
	$('#myModal2').modal('show');
  });
  
 $("#cdel2").click(function(){
	var  is_disable = $("#is_disable").val();
	var ip_number  = $("#ip_number").val();
	var ip_name = $("#ip_name").val();
	var no_of_days = $("#no_of_days").val();
	var total_wages = $("#total_wages").val();
	var ip_contribution = $("#ip_contribution").val();
	var reason = $("#reason").val();
	var esic_table_data_id = $("#esic_table_data_id").val();
	 $.ajax({
      type:'POST',
      url :'<?php echo base_url('admin/dms/update_esic_table_data');?>',
      data:'esic_table_data_id='+esic_table_data_id+'&is_disable='+is_disable+'&ip_number='+ip_number+'&ip_name='+ip_name+'&no_of_days='+no_of_days+'&total_wages='+total_wages+'&ip_contribution='+ip_contribution+'&reason='+reason,
      dataType:'json',
      success:function(result){
		window.location.reload('<?php echo base_url('admin/dms/esic_details'); ?>'+result.responseList.esic_basic_data_id);	
      },error:function(){

      }
    });
 });
 
 $(document).on( "click",'.cstm_view_esic_table',function() {
	var esic_basic_data_id=$(this).prop('title');
	$('#esic_basic_data_id').val(esic_basic_data_id);
	$('#myModal3').modal('show');
 });
 
  $("#cdel2_add").click(function(){
	var is_disable = $("#is_disable_add").val();
	var ip_number  = $("#ip_number_add").val();
	var ip_name = $("#ip_name_add").val();
	var no_of_days = $("#no_of_days_add").val();
	var total_wages = $("#total_wages_add").val();
	var ip_contribution = $("#ip_contribution_add").val();
	var esic_basic_data_id = $("#esic_basic_data_id").val();
	var reason = $("#reason_add").val();  
	$.ajax({
      type:'POST',
      url :'<?php echo base_url('admin/dms/add_esic_table_data');?>',
      data:'esic_basic_data_id='+esic_basic_data_id+'&is_disable='+is_disable+'&ip_number='+ip_number+'&ip_name='+ip_name+'&no_of_days='+no_of_days+'&total_wages='+total_wages+'&ip_contribution='+ip_contribution+'&reason='+reason,
      dataType:'json',
      success:function(result){
		window.location.reload('<?php echo base_url('admin/dms/esic_details'); ?>'+result.responseList.esic_basic_data_id);	
      },error:function(){

      }
    });
  });
  
 $(document).on( "click",'.delete_data',function() {
	var esic_basic_data_id=$(this).attr('basic_data_id'); 
	var esic_table_data_id = $(this).prop('title');
	alert(esic_table_data_id);
	$.ajax({
      type:'POST',
      url :'<?php echo base_url('admin/dms/delete_esic_table_data');?>',
      data:'esic_basic_data_id='+esic_basic_data_id+'&esic_table_data_id='+esic_table_data_id,
      dataType:'json',
      success:function(result){
		window.location.reload('<?php echo base_url('admin/dms/esic_details'); ?>'+result.responseList.esic_basic_data_id);	
      },error:function(){

      }
    });
 });
  
  
</script>
<style>
div.ex1 {
  overflow: scroll;
  height: 420px;
}
</style>