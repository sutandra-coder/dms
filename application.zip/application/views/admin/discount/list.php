<style>
.cstm_view{font-size:15px;}
</style>
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
          <h3>
            Discount List
            
          </h3>
          <!--<ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>-->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box box-primary">
            <div class="box-header with-border">
			<div class="admin_tab">
			<ul>
				<li><a href="javascript:void(0);" onclick="window.history.back();">Back</a></li>
				<li><a href="discount/add">Add</a></li>
			</ul>
			
				 
							
							<?php if($this->session->flashdata('error_msg')){?>
								<span style="color:red; font-weight:bold"><?php echo $this->session->flashdata('error_msg');?></span>
							<?php }?>
							<?php if($this->session->flashdata('success_msg')){?>
								<span style="color:green; font-weight:bold"><?php  echo $this->session->flashdata('success_msg'); ?></span>
							<?php }?>
				</div>			 
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
				  <th>Sl. NO.</th>
				  <th>Discount Imgae</th>
				  <th>Discount(%)</th>
				  <th class="no-sort">Action</th>
                </tr>
                </thead>
               <tbody>
					<?php $i=1; foreach($post_data as $row){ ?>
					<tr>
						<td class="text-center">
                          <?php echo $i;?>
                        </td> 
						<td class="text-center">
						 <?php if(!empty($row['discount_image'])){?>
                          <img src="<?php echo $row['discount_image'];?>"  width="50" height="60">
						 <?php } ?>
                        </td> 
						<td>
							<?php echo $row['discount'];?>
						</td>
						<td class="text-center">
                          <a href="<?php echo base_url('admin/discount/details/'.$row['discount_id']); ?>" title="Edit"><span class="glyphicon glyphicon-pencil"></span></a>
						  <!-- <a href="javascript:void(0)" title="<?php echo $row['offer_id'];?>" class="cstm_view" id="delete_offer"><span class="glyphicon glyphicon-minus"></span></a> -->
                        </td>
						
					</tr>
					<?php $i++;} ?>
				</tbody>
                <tfoot>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>

<script src="<?php echo base_url()?>public/admin_assets/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url()?>public/admin_assets/plugins/datatables/dataTables.bootstrap.min.js"></script>
