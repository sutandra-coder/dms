<!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h3>
            Password settings
            
          </h3>
          <!--<ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>-->
        </section>

        <!-- Main content -->
        <section class="content"> 
			<div class="row">
				<!-- general form elements -->
				<div class="col-md-12">
					  <div class="box box-primary">
						<div class="box-header with-border">
						<?php if($this->session->flashdata('error_msg')){?>
								<span style="color:red; font-weight:bold"><?php echo $this->session->flashdata('error_msg');?></span>
							<?php }?>
							<?php if($this->session->flashdata('success_msg')){?>
								<span style="color:green; font-weight:bold"><?php  echo $this->session->flashdata('success_msg'); ?></span>
							<?php }?>
						</div>
						<!-- /.box-header -->
						<!-- form start -->
						<form role="form" class="mtbresize" method="post" action="<?php echo base_url('admin/settings/changeuserpasswd');?>">
						  <div class="box-body">
							<div class="form-group">
							  <label for="oldpassw1">Old Password</label>
							  <input type="password" class="form-control" id="oldpassw1" name="oldpassw" placeholder="old password" value="<?php echo set_value('oldpassw');?>" required="required">
							  <?php echo form_error('oldpassw'); ?>
							</div>
							<div class="form-group">
							  <label for="exampleInputPassword1">New Password</label>
							  <input type="password" class="form-control" id="exampleInputPassword1" name="newpassw" value="<?php echo set_value('newpassw');?>" placeholder="new password" required="required">
							  <?php echo form_error('newpassw'); ?>
							</div>
							<div class="form-group">
							  <label for="exampleInputPassword2">Confirm Password</label>
							  <input type="password" class="form-control" id="exampleInputPassword2" name="confpassw" placeholder="confirm password" value="<?php echo set_value('confpassw');?>" required="required">
							  <?php echo form_error('confpassw'); ?>
							</div>
						  </div>
						  <!-- /.box-body -->
						 <?php $admin=$this->session->userdata('admin');?>	
						  <div class="box-footer">
						  	<inpu type="hidden" name="user_id" value="<?php echo $admin['admin_id'];?>">
							<button type="submit" class="btn btn-sm btn-primary">Submit</button>
						  </div>
						</form>
					  </div>
				</div>
          <!-- /.box -->
          </div><!-- /.row -->	
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->