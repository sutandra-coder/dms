<style>
.cstm_view{font-size:15px;}
</style>
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
          <h3>
            Enquiery Type List
            
          </h3>
          <!--<ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>-->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box box-primary">
            <div class="box-header with-border">
			<div class="admin_tab">
			<ul>
				<li><a href="javascript:void(0);" onclick="window.history.back();">Back</a></li>
				<li><a href="<?php echo base_url();?>admin/enquierytype/add">Add</a></li>	
			</ul>
			
				 
							
							<?php if($this->session->flashdata('error_msg')){?>
								<span style="color:red; font-weight:bold"><?php echo $this->session->flashdata('error_msg');?></span>
							<?php }?>
							<?php if($this->session->flashdata('success_msg')){?>
								<span style="color:green; font-weight:bold"><?php  echo $this->session->flashdata('success_msg'); ?></span>
							<?php }?>
				</div>			 
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example" class="table table-bordered table-striped">
                <thead>
                <tr>
				  <th>Sl. NO.</th>
				  <th>Enquiery Type</th>
				  <th>Date</th>		
				  <th>Edit</th>	
                </tr>
                </thead> 
				<tbody>
					<?php $i=1; foreach($post_data as $row){ ?>
					<tr>
						<td class="text-center">
                          <?php echo $i;?>
                        </td> 
						<td class="text-center">
                          <?php echo $row['enquiry_type'];?>
                        </td>						
						<td class="text-center">
                          <?php echo $row['last_update_ts'];?>
                        </td>
						<td class="text-center">
                          <a href="<?php echo base_url('admin/enquierytype/details/'.$row['enquiry_type_id']); ?>" title="Edit"><span class="glyphicon glyphicon-pencil"></span></a>
                        </td>
						
					</tr>
					<?php $i++;} ?>
				</tbody>
                <tfoot>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  

<script src="<?php echo base_url()?>public/admin_assets/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url()?>public/admin_assets/plugins/datatables/dataTables.bootstrap.min.js"></script>
<script>
/*$(document).ready(function() {
    $('#example').DataTable( {
        "processing": true,
        "serverSide": true,
        "ajax": {
            "url": "<?php echo base_url('admin/metakey/all_content_list');?>",
            "type": "POST"
        },
        //Set column definition initialisation properties.
        "columnDefs": [
        { 
            "targets": 'no-sort', //1st and last column
            "orderable": false, //set not orderable
        },
        ],
    } );
	
	var dtable = $("#example").dataTable().api();
	
	$(".dataTables_filter input")
    .unbind() // Unbind previous default bindings
    .bind("input", function(e) { // Bind our desired behavior
        // If the length is 3 or more characters, or the user pressed ENTER, search
        if(this.value.length >= 3 || e.keyCode == 13) {
            // Call the API search function
            dtable.search(this.value).draw();
        }
        // Ensure we clear the search if they backspace far enough
        if(this.value == "") {
            dtable.search("").draw();
        }
        return;
    });
} );*/

var  table = $('#example').dataTable({
    'bLengthChange': false,
    'searching': true,
    'paging':   true,  // Table pagination
    'ordering': true,  // Column ordering
    'info':     true,  // Bottom left status text
    'responsive': true, // https://datatables.net/extensions/responsive/examples/
    // Text translation options
    // Note the required keywords between underscores (e.g _MENU_)
    oLanguage: {
        // sSearch:      'Search all columns:',
        sLengthMenu:  '_MENU_ records per page',
        info:         'Showing page _PAGE_ of _PAGES_',
        zeroRecords:  'Nothing found - sorry',
        infoEmpty:    'No records available',
        infoFiltered: '(filtered from _MAX_ total records)'
    },
    // set columns options
    'aoColumns': [
    {'bVisible':true},
    {'bVisible':true},
    {'bVisible':true},
	{'bVisible':true}
    ],
	"columnDefs": [
        { 
            "targets": 'no-sort', //1st and last column
            "orderable": false, //set not orderable
        },
        ]
  });
  
  $(document).on( "click",'#active.cstm_view_status',function() {
		var p = $(this);
		p.html('---');
		p.css("color", "green");
		var id=$(this).prop('title');
		$.ajax({
		  type: "POST",
		  url: '<?php echo base_url('admin/metakey/inactive')?>',
		  data: 'meta_key_id='+id,
		  dataType:'json',
		  success: function(response){
			p.attr("id", "inactive");
			p.attr("class", "cstm_view_status btn btn-danger");
			p.html('<span class="glyphicon glyphicon-remove"></span>');	
			p.css('color','white');
			//window.location.reload('<?php echo base_url('admin/feedback'); ?>');	
		  }
		});
	});
	
	$(document).on( "click",'#inactive.cstm_view_status',function() {
		var pactive = $(this);
		pactive.html('---');
		pactive.css("color","red");
		var id=$(this).prop('title');
		$.ajax({
		  type: "POST",
		  url: '<?php echo base_url('admin/metakey/active')?>',
		  data: 'meta_key_id='+id,
		  dataType:'json',
		  success: function(response){
			pactive.attr("id","active");
			pactive.attr("class","cstm_view_status btn btn-success");			
			pactive.html('<span class="glyphicon glyphicon-ok"></span>');
			pactive.css('color','white');			
			//window.location.reload('<?php echo base_url('admin/feedback'); ?>');		
		  }
		});
	});
</script>
