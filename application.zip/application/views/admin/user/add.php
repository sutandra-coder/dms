<!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h3>
            Cms settings
            
          </h3>
          <!--<ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>-->
        </section>

        <!-- Main content -->
        <section class="content"> 
			<div class="row">
				<!-- general form elements -->
				<div class="col-md-12">
					  <div class="box box-primary">
						<div class="box-header with-border">
						  <h3 class="box-title"></h3>
						  <?php if($this->session->flashdata('error_msg')){?>
							<div class="alert alert-warning alert-dismissible hite">
								<button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
								<h4><i class="icon fa fa-warning"></i><?php echo $this->session->flashdata('error_msg'); ?></h4>
							</div>
						  <?php }?>
						  <?php if($this->session->flashdata('success_msg')){?>
							<div class="alert alert-success alert-dismissible hite">
								<button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
								<h4><i class="icon fa fa-warning"></i><?php echo $this->session->flashdata('success_msg'); ?></h4>
							</div>
						  <?php }?>
						</div>
						<!-- /.box-header -->
						<!-- form start -->
						<form role="form" class="mtbresize" method="post" action="<?php echo base_url('admin/cms/contenta');?>" enctype="multipart/form-data">
						  <div class="box-body">
							<!--<div class="form-group">
							  <label for="page_name">Page name</label>
							  <input type="text" class="form-control" id="page_name" name="page_name" value="<?php echo $cms['page_name'];?>" disabled>
							</div>-->
							<div class="form-group">
							  <label for="title">Title</label>
							  <input type="text" class="form-control" id="title" name="title" value="<?php echo set_value('title');?>" placeholder="title">
							  <?php echo form_error('title','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="description">Description</label>
							  <textarea id="description" name="description" rows="10" cols="80"><?php echo set_value('description');?></textarea>
							  <?php echo form_error('description','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="content">Content</label>
							  <textarea id="content" name="content" rows="10" cols="80"><?php echo set_value('content');?></textarea>
							  <?php echo form_error('content','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label>Status</label>
							  <select class="form-control" name="status" id="status">
								<option value="1">Active</option>
								<option value="0">Inactive</option>
							  </select>
							</div>
							<div class="form-group">
							  <label for="imgInp">Image</label>
							  <input id="imgInp" type="file" name="imgInp">
							  <img src="<?php echo base_url()?>public/images/cms/Dummy.jpg" style="width:120px;" id="blah">
							</div>
						  </div>
						  <!-- /.box-body -->
						  <div class="box-footer">
							<button type="submit" class="btn btn-sm btn-primary">Submit</button>
						  </div>
						</form>
					  </div>
				</div>
          <!-- /.box -->
          </div><!-- /.row -->	
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
<script src="https://cdn.ckeditor.com/4.5.7/standard/ckeditor.js"></script>
<script>
function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#blah').attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
    }
}

$("#imgInp").change(function(){
    readURL(this);
});
CKEDITOR.replace('description');
CKEDITOR.replace('content');
</script>