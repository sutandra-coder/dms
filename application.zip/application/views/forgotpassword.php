<div class="login-box">
  <div class="login-logo">
  <img src="<?php echo base_url()?>/public/images/logo_new.png" style="width:80px;">
    <!-- <a href="<?php echo base_url('admin');?>"><b>Admin</b>LTE</a> -->
	 <!--<a href="../../index2.html"><b>Admin</b>LTE</a>-->
  </div>
  <!-- /.login-logo -->
  <div class="login-box-body">
    <p class="login-box-msg">
	<?php if($this->session->flashdata('error_msg') && $this->session->flashdata('error_msg')!=''){ ?>
			<span style='color:red'><?php echo $this->session->flashdata('error_msg');?></span>
		<?php }else{?>
			<b>Account recovery</b>
		<?php }?>
	</p>

    <form action="#" method="post" id="new_form">
      <div class="form-group has-feedback">
        <label for="title">New password</label>
        <input type="password" class="form-control" placeholder="New password" name="newpassword1" id="newpassword1" required>
      </div>
      <div class="form-group has-feedback">
        <label for="title">Confirm password(again)</label>
        <input type="password" class="form-control" placeholder="New password" name="newpassword2" id="newpassword2" required>
      </div>
      <?php 
        $url=$this->uri->segment_array();
       //print_r($p);
        $record_num = end($url);
      ?>
      <input type="hidden" name="token" id="token" value="<?php echo $record_num;?>">
      <div class="row">
        <div class="col-xs-8">
          <!--<div class="checkbox icheck">
             <label>
              <input type="checkbox"> Remember Me
            </label>
          </div> -->
        </div>
        <!-- /.col -->
        <div class="col-xs-4">
          <button type="button" class="btn btn-primary btn-block btn-flat" id="submit">Submit</button>
        </div>
        <!-- /.col -->
      </div>
    </form>
    <!--<div class="social-auth-links text-center">
      <p>- OR -</p>
      <a href="#" class="btn btn-block btn-social btn-facebook btn-flat"><i class="fa fa-facebook"></i> Sign in using
        Facebook</a>
      <a href="#" class="btn btn-block btn-social btn-google btn-flat"><i class="fa fa-google-plus"></i> Sign in using
        Google+</a>
    </div>-->
    <!-- /.social-auth-links -->

    <!-- <a href="#">I forgot my password</a><br> -->
    <!-- <a href="register.html" class="text-center">Register a new membership</a> -->

  </div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->
<script>
  $('form').submit(false);
  $(document).prop('title', 'Account recovery');
  $('#submit').click(function(){//alert('eee')
   var newpassword1=$('#newpassword1').val();
   var newpassword2=$('#newpassword2').val();
   if(newpassword1 == '' || newpassword1==0){
    alert('New Password field is required');
    return false;
   }
   if(newpassword2 == '' || newpassword2==0){
    alert('Confirm Password field is required');
    return false;
   }
   if(newpassword1!=newpassword2){
    alert('Passwords are not matched!');
    return false;
   }
     $.ajax({
        type: "POST",
        url: "<?php echo base_url('settings/recover_account');?>",
        data: $('#new_form').serialize(),
        dataType:'json',
        success: function( response ) {
          alert(response.message);
          window.location.reload();
        }
      });
  });
</script>